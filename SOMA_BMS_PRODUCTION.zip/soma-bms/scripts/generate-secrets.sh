#!/bin/bash
echo "🔑 Secret Keys untuk file .env:"
echo ""
echo "SECRET_KEY=$(python3 -c 'import secrets; print(secrets.token_hex(32))')"
echo "POSTGRES_PASSWORD=$(python3 -c 'import secrets; print(secrets.token_urlsafe(24))')"
echo "REDIS_PASSWORD=$(python3 -c 'import secrets; print(secrets.token_urlsafe(16))')"
echo ""
echo "Salin nilai di atas ke file .env Anda!"
