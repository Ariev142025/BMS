#!/bin/bash
set -e
BACKUP_FILE="$1"
if [ -z "$BACKUP_FILE" ]; then echo "Usage: bash restore-db.sh <backup.sql.gz>"; exit 1; fi
echo "⚠️  Ini akan MENGHAPUS semua data!"; read -p "Ketik 'YA' untuk lanjut: " c
if [ "$c" != "YA" ]; then echo "Dibatalkan."; exit 0; fi
gunzip -c "$BACKUP_FILE" | docker exec -i soma_postgres psql -U ${POSTGRES_USER:-soma_user} ${POSTGRES_DB:-soma_bms}
echo "✅ Restore selesai"
