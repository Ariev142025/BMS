#!/bin/bash
set -e
BACKUP_DIR="./backups"
DATE=$(date +%Y%m%d_%H%M%S)
FILENAME="soma_bms_${DATE}.sql.gz"
KEEP_DAYS=7
mkdir -p "$BACKUP_DIR"
echo "📦 Backup → $FILENAME..."
docker exec soma_postgres pg_dump -U ${POSTGRES_USER:-soma_user} ${POSTGRES_DB:-soma_bms} | gzip > "$BACKUP_DIR/$FILENAME"
echo "✅ Selesai: $BACKUP_DIR/$FILENAME"
find "$BACKUP_DIR" -name "soma_bms_*.sql.gz" -mtime +$KEEP_DAYS -delete
echo "🗑️  Backup >${KEEP_DAYS} hari dihapus"
