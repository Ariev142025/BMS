# SOMA BMS — Smart Building Management System

**Platform SaaS multi-tenant** untuk manajemen gedung komersial Indonesia.

---

## 🚀 Quick Start

```bash
# 1. Clone & build
cd soma-bms
docker compose up -d --build

# 2. Tunggu ~60 detik sampai semua service sehat
docker compose ps   # semua harus "healthy"

# 3. Seed data demo
docker compose exec backend python -m app.seed

# 4. Buka browser
#   Dashboard Web  → http://localhost:3000
#   Mobile App     → http://localhost:3000/mobile/dashboard
#   API Docs       → http://localhost:8000/docs
```

---

## 👤 Akun Demo (password: `Demo123!`)

| Role              | Email                       | Mengarah ke         |
|-------------------|-----------------------------|---------------------|
| Super Admin       | superadmin@somabms.com      | Admin Dashboard     |
| Admin Gedung      | admin@gedung.com            | Admin Dashboard     |
| TRO (Resepsionis) | tro@gedung.com              | TRO Dashboard       |
| SPV Teknisi       | spv.teknisi@gedung.com      | Mobile Dashboard    |
| Teknisi 1 (HVAC)  | teknisi1@gedung.com         | Mobile Dashboard    |
| Teknisi 2 (Listrik)| teknisi2@gedung.com        | Mobile Dashboard    |
| SPV Housekeeping  | spv.hk@gedung.com           | Mobile Dashboard    |
| Housekeeping 1    | hk1@gedung.com              | Mobile Dashboard    |
| Housekeeping 2    | hk2@gedung.com              | Mobile Dashboard    |

---

## 🏗️ Arsitektur

```
Docker Compose
├── postgres:16       → Database utama (port 5432)
├── redis:7           → Cache & session (port 6379)
├── backend           → FastAPI Python 3.12 (port 8000)
└── frontend          → Next.js 14 TypeScript (port 3000)
```

### Backend (`/backend`)
- **FastAPI** + **SQLAlchemy async** + **asyncpg**
- Single file API (`app/main.py`) — 67 endpoints
- Scheduler background task (generate tasks + escalate overdue)
- **Isolasi data ketat**: setiap query difilter `company_id` + `building_id`

### Frontend (`/frontend`)
- **Next.js 14** + TypeScript + Tailwind CSS
- **Admin dashboard** — sidebar navigation, charts (recharts)
- **Mobile app** — bottom navigation, touch-friendly
- **TRO dashboard** — registrasi tamu, QR code, checkout

---

## 📊 Data Models (10 Tier)

```
Company (SaaS tenant)
  └── Building                   ← FK → companies.id
       ├── User                  ← FK → buildings.id
       ├── Asset                 ← FK → buildings.id
       ├── ChecklistTemplate     ← FK → buildings.id
       ├── ScheduleRule          ← FK → buildings.id
       │    └── TaskInstance     ← FK → buildings.id
       ├── WorkOrder             ← FK → buildings.id
       ├── Material              ← FK → buildings.id
       │    ├── MaterialTransaction
       │    └── MaterialRequest
       ├── Meter                 ← FK → buildings.id
       │    ├── MeterReading
       │    └── TariffConfig
       ├── Invoice               ← FK → buildings.id
       ├── Visitor               ← FK → buildings.id
       │    ├── Visit
       │    ├── AccessLog
       │    └── ParkingEvent
       └── Alarm                 ← FK → buildings.id
```

---

## 🔐 Keamanan & Isolasi Data

- **JWT** dengan `company_id`, `building_id`, `role` embedded
- `verify_building_access()` — memverifikasi gedung milik company + user punya akses
- Non-admin hanya bisa akses gedung yang di-assign (`user.building_id`)
- Setiap endpoint memfilter query dengan `company_id` minimum
- **Tidak ada data bocor** antar gedung atau antar tenant

---

## 🤖 Auto-Meter Recording

Saat teknisi menyelesaikan checklist yang mengandung step dengan `meter_number` + `meter_type`:
→ `MeterReading` otomatis dibuat  
→ Langsung terhubung ke sistem billing/invoice

---

## ⚙️ Background Scheduler

Berjalan setiap jam:
1. **Generate scheduled tasks** — membaca ScheduleRules, membuat TaskInstance per aset/user
2. **Escalate overdue tasks** — menandai task terlambat sebagai `OVERDUE`

---

## 🌐 API Endpoints Utama

```
POST /api/v1/auth/login          → Login, dapat JWT
GET  /api/v1/auth/me             → Info user aktif
GET  /api/v1/buildings           → Daftar gedung
GET  /api/v1/assets              → Daftar aset (filter gedung)
GET  /api/v1/tasks/my-tasks      → Tugas hari ini (mobile)
PUT  /api/v1/tasks/{id}/complete → Selesaikan checklist
POST /api/v1/work-orders         → Buat work order
GET  /api/v1/materials           → Stok material
POST /api/v1/billing/invoices/generate → Generate preview invoice
GET  /api/v1/dashboard/admin/stats     → Statistik admin
GET  /api/v1/dashboard/my-stats        → Statistik personal (mobile)
```

Dokumentasi lengkap: http://localhost:8000/docs

---

## 📱 Mobile App Pages

| URL                       | Akses                      |
|---------------------------|----------------------------|
| /mobile/dashboard         | Semua role lapangan        |
| /mobile/checklist         | Teknisi, HK                |
| /mobile/maintenance       | Teknisi                    |
| /mobile/work-orders       | Teknisi, HK, SPV           |
| /mobile/materials         | Teknisi, HK, SPV           |
| /mobile/alarms            | Semua role lapangan        |
| /mobile/monitoring        | SPV Teknisi, SPV HK        |
| /mobile/approvals         | SPV Teknisi, SPV HK        |
| /mobile/profile           | Semua role lapangan        |

---

Dibuat untuk **PT Teknologi Lepas Kerja / Newbie Trade Indonesia**  
SOMA BMS v1.0.0 — Jakarta 2026
