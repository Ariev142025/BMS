import { useEffect } from 'react'
import { useRouter } from 'next/router'
import { getCookie } from 'cookies-next'

export default function Index() {
  const router = useRouter()
  useEffect(() => {
    const token = getCookie('access_token')
    if (token) {
      try {
        const p = JSON.parse(atob((token as string).split('.')[1]))
        if (['teknisi','housekeeping','spv_teknisi','spv_housekeeping'].includes(p.role)) {
          router.push('/mobile/dashboard')
        } else if (p.role === 'tro') {
          router.push('/tro/dashboard')
        } else {
          router.push('/admin/dashboard')
        }
      } catch { router.push('/login') }
    } else { router.push('/login') }
  }, [])
  return (
    <div className="min-h-screen bg-navy flex items-center justify-center">
      <div className="text-center">
        <div className="w-16 h-16 bg-teal-600 rounded-2xl mx-auto mb-4 animate-pulse flex items-center justify-center">
          <span className="text-white font-bold text-2xl">S</span>
        </div>
        <p className="text-white text-sm">Memuat SOMA BMS...</p>
      </div>
    </div>
  )
}
