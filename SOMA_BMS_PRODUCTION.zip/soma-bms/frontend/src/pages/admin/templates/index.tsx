import Head from 'next/head'
import { useState, useEffect } from 'react'
import { useAuth } from '@/hooks/useAuth'
import { AdminLayout } from '@/components/layout/AdminLayout'
import { templatesApi } from '@/lib/api'

export default function TemplatesPage() {
  const { user, loading, logout } = useAuth(['building_admin','super_admin','company_admin'])
  const [templates, setTemplates] = useState<any[]>([])
  const [busy, setBusy] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [detail, setDetail] = useState<any>(null)
  const [form, setForm] = useState({
    name:'', category:'', sub_category:'', template_type:'checklist',
    estimated_duration_minutes:30, description:'',
  })

  useEffect(() => {
    if (!user) return
    templatesApi.list({ building_id: user.building_id })
      .then(r => setTemplates(r.data))
      .finally(() => setBusy(false))
  }, [user])

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user?.building_id) return
    try {
      const { data } = await templatesApi.create({ ...form, building_id: user.building_id, sections: [] })
      setTemplates(p => [data, ...p])
      setShowForm(false)
    } catch (e: any) { alert(e.response?.data?.detail || 'Gagal') }
  }

  const duplicate = async (id: string) => {
    try {
      const { data } = await templatesApi.duplicate(id)
      setTemplates(p => [data, ...p])
    } catch (e: any) { alert('Gagal menduplikasi') }
  }

  if (loading) return null
  if (!user) return null

  return (
    <>
      <Head><title>Template — SOMA BMS</title></Head>
      <AdminLayout user={user} onLogout={logout} title="Template Checklist & Maintenance">
        <div className="flex justify-between items-center mb-6">
          <p className="text-sm text-gray-500">{templates.length} template aktif</p>
          <button onClick={() => setShowForm(true)} className="btn-primary">+ Buat Template Baru</button>
        </div>

        {busy ? (
          <div className="text-center py-16 text-gray-400">⏳ Memuat...</div>
        ) : templates.length === 0 ? (
          <div className="card text-center py-16 text-gray-400"><p className="text-4xl mb-3">📋</p><p>Belum ada template. Jalankan seed data untuk template demo.</p></div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {templates.map(t => (
              <div key={t.id} className="card hover:shadow-md transition-shadow cursor-pointer group">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{t.template_type==='maintenance'?'🛠️':'✅'}</span>
                    <div>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${t.template_type==='maintenance'?'bg-amber-100 text-amber-700':'bg-blue-100 text-blue-700'}`}>
                        {t.template_type}
                      </span>
                    </div>
                  </div>
                  <span className="text-xs text-gray-400">v{t.version}</span>
                </div>

                <h3 className="font-semibold text-gray-800 mb-1">{t.name}</h3>
                <p className="text-xs text-gray-500 mb-3">{t.category}{t.sub_category ? ` · ${t.sub_category}` : ''}</p>

                <div className="flex items-center gap-3 text-xs text-gray-400 mb-4">
                  <span>📋 {t.section_count} seksi</span>
                  <span>📝 {t.step_count} langkah</span>
                  <span>⏱️ ~{t.estimated_duration_minutes} mnt</span>
                </div>

                {t.default_materials?.length > 0 && (
                  <p className="text-xs text-blue-600 mb-3 truncate">📦 {t.default_materials.map((m: any) => m.name).join(', ')}</p>
                )}

                <div className="flex gap-2 pt-2 border-t border-gray-50">
                  <button onClick={() => setDetail(t)}
                    className="flex-1 text-xs py-1.5 bg-gray-100 hover:bg-gray-200 rounded-lg text-gray-700">
                    👁️ Detail
                  </button>
                  <button onClick={() => duplicate(t.id)}
                    className="flex-1 text-xs py-1.5 bg-teal-50 hover:bg-teal-100 rounded-lg text-teal-700">
                    📄 Duplikat
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Detail Modal */}
        {detail && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[85vh] overflow-y-auto">
              <div className="px-6 py-4 border-b flex justify-between sticky top-0 bg-white z-10">
                <h3 className="font-bold text-gray-800">{detail.name}</h3>
                <button onClick={() => setDetail(null)} className="text-gray-400 text-xl">✕</button>
              </div>
              <div className="p-6">
                <div className="flex items-center gap-4 mb-4 text-sm text-gray-600">
                  <span>📂 {detail.category}</span>
                  <span>⏱️ {detail.estimated_duration_minutes} menit</span>
                  <span>v{detail.version}</span>
                </div>
                {detail.sections?.map((sec: any, si: number) => (
                  <div key={si} className="mb-4">
                    <h4 className="font-semibold text-sm text-teal-700 mb-2 flex items-center gap-2">
                      <span className="w-5 h-5 bg-teal-600 text-white rounded-full flex items-center justify-center text-xs">{si+1}</span>
                      {sec.title}
                    </h4>
                    <div className="space-y-1.5 ml-7">
                      {sec.steps?.map((step: any, xi: number) => (
                        <div key={xi} className="flex items-start gap-2 text-sm text-gray-700">
                          <span className="text-gray-300 text-xs mt-0.5">{xi+1}.</span>
                          <div className="flex-1">
                            <span>{step.instruction}</span>
                            <span className="ml-2 text-xs text-gray-400 italic">
                              [{step.input_type}{step.unit?` · ${step.unit}`:''}
                              {step.meter_number?` · meter:${step.meter_number}`:''}
                              {step.required?' · wajib':''}]
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
                {detail.default_materials?.length > 0 && (
                  <div className="bg-blue-50 rounded-xl p-3 mt-4">
                    <p className="text-xs font-semibold text-blue-700 mb-1">📦 Default Material:</p>
                    {detail.default_materials.map((m: any, i: number) => (
                      <p key={i} className="text-xs text-blue-800">• {m.name} — {m.default_qty} {m.unit}</p>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Create Form */}
        {showForm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl w-full max-w-md">
              <div className="px-6 py-4 border-b flex justify-between"><h3 className="font-bold">Buat Template Baru</h3><button onClick={() => setShowForm(false)} className="text-gray-400">✕</button></div>
              <form onSubmit={handleCreate} className="p-6 space-y-3">
                <input className="input-field" required placeholder="Nama Template *" value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))}/>
                <div className="grid grid-cols-2 gap-3">
                  <select className="input-field" value={form.template_type} onChange={e=>setForm(f=>({...f,template_type:e.target.value}))}>
                    <option value="checklist">Checklist</option>
                    <option value="maintenance">Maintenance</option>
                  </select>
                  <input className="input-field" required placeholder="Kategori *" value={form.category} onChange={e=>setForm(f=>({...f,category:e.target.value}))}/>
                </div>
                <input className="input-field" placeholder="Sub Kategori" value={form.sub_category} onChange={e=>setForm(f=>({...f,sub_category:e.target.value}))}/>
                <div>
                  <label className="block text-xs text-gray-600 mb-1">Estimasi Durasi (menit)</label>
                  <input type="number" className="input-field" min={5} value={form.estimated_duration_minutes} onChange={e=>setForm(f=>({...f,estimated_duration_minutes:+e.target.value}))}/>
                </div>
                <textarea className="input-field" rows={2} placeholder="Deskripsi (opsional)" value={form.description} onChange={e=>setForm(f=>({...f,description:e.target.value}))}/>
                <p className="text-xs text-gray-400">💡 Template dibuat kosong. Edit langkah-langkah melalui API atau fitur template editor.</p>
                <div className="flex gap-3"><button type="submit" className="btn-primary flex-1">Buat Template</button><button type="button" onClick={()=>setShowForm(false)} className="btn-secondary flex-1">Batal</button></div>
              </form>
            </div>
          </div>
        )}
      </AdminLayout>
    </>
  )
}
