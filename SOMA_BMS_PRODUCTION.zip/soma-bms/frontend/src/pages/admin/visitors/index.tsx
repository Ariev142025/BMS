import { useEffect } from 'react'
import { useRouter } from 'next/router'
export default function AdminVisitors() {
  const router = useRouter()
  useEffect(() => { router.push('/tro/dashboard') }, [])
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="text-center"><p className="text-4xl mb-2">🪪</p><p className="text-gray-500">Mengarahkan ke TRO Dashboard...</p></div>
    </div>
  )
}
