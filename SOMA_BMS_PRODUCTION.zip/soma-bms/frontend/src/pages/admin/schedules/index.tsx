import Head from 'next/head'
import { useState, useEffect } from 'react'
import { useAuth } from '@/hooks/useAuth'
import { AdminLayout } from '@/components/layout/AdminLayout'
import { schedulesApi, templatesApi } from '@/lib/api'

const freqLabel: Record<string,string> = { daily:'Harian 🔁', weekly:'Mingguan 📅', monthly:'Bulanan 🗓️', quarterly:'Kuartalan', yearly:'Tahunan' }
const roleLabel: Record<string,string> = { teknisi:'👷 Teknisi', housekeeping:'🧹 Housekeeping', spv_teknisi:'👔 SPV Teknisi' }

export default function SchedulesPage() {
  const { user, loading, logout } = useAuth(['building_admin','super_admin','company_admin'])
  const [schedules, setSchedules] = useState<any[]>([])
  const [templates, setTemplates] = useState<any[]>([])
  const [busy, setBusy] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({
    name:'', template_id:'', assigned_role:'teknisi',
    freq:'daily', time:'08:00', day:1,
  })

  const fetch_ = async () => {
    if (!user) return
    Promise.all([
      schedulesApi.list({ building_id: user.building_id }),
      templatesApi.list({ building_id: user.building_id }),
    ]).then(([s, t]) => { setSchedules(s.data); setTemplates(t.data) }).finally(() => setBusy(false))
  }
  useEffect(() => { if (user) fetch_() }, [user])

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user?.building_id || !form.template_id) return
    try {
      const pattern: any = { freq: form.freq, time: form.time }
      if (form.freq === 'weekly') pattern.days = ['monday']
      if (['monthly','quarterly'].includes(form.freq)) pattern.day = form.day
      await schedulesApi.create({
        name: form.name, template_id: form.template_id,
        building_id: user.building_id, assigned_role: form.assigned_role,
        recurrence_pattern: pattern,
      })
      fetch_()
      setShowForm(false)
    } catch (e: any) { alert(e.response?.data?.detail || 'Gagal') }
  }

  const toggle = async (id: string) => {
    await schedulesApi.toggle(id)
    fetch_()
  }

  if (loading) return null
  if (!user) return null

  return (
    <>
      <Head><title>Jadwal — SOMA BMS</title></Head>
      <AdminLayout user={user} onLogout={logout} title="Penjadwalan Otomatis">
        <div className="bg-teal-50 border border-teal-200 rounded-xl p-3 mb-5 text-sm text-teal-800">
          ⚙️ Scheduler berjalan setiap jam. Task otomatis dibuat berdasarkan jadwal dan ditugaskan ke teknisi/HK yang tersedia.
        </div>
        <div className="flex justify-between items-center mb-5">
          <p className="text-sm text-gray-500">{schedules.length} jadwal aktif</p>
          <button onClick={() => setShowForm(true)} className="btn-primary">+ Jadwal Baru</button>
        </div>

        {busy ? (
          <div className="text-center py-14 text-gray-400">⏳ Memuat...</div>
        ) : schedules.length === 0 ? (
          <div className="card text-center py-14 text-gray-400"><p className="text-4xl mb-2">📅</p><p>Belum ada jadwal.</p></div>
        ) : (
          <div className="space-y-3">
            {schedules.map(s => {
              const tpl = templates.find(t => t.id === s.template_id)
              const freq = s.recurrence_pattern?.freq || 'daily'
              return (
                <div key={s.id} className={`card flex items-center gap-4 ${!s.is_active ? 'opacity-60' : ''}`}>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-semibold text-gray-800">{s.name}</p>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${s.is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                        {s.is_active ? '● Aktif' : '○ Nonaktif'}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-gray-500">
                      <span>{freqLabel[freq]}</span>
                      <span>⏰ {s.recurrence_pattern?.time || '08:00'}</span>
                      <span>{roleLabel[s.assigned_role] || s.assigned_role}</span>
                      {tpl && <span className="text-teal-600">📋 {tpl.name}</span>}
                    </div>
                    {s.last_generated && (
                      <p className="text-xs text-gray-400 mt-0.5">
                        Terakhir generate: {new Date(s.last_generated).toLocaleString('id-ID')}
                      </p>
                    )}
                  </div>
                  <button onClick={() => toggle(s.id)}
                    className={`text-xs px-4 py-2 rounded-lg font-medium transition-colors ${s.is_active ? 'bg-red-50 text-red-600 hover:bg-red-100' : 'bg-green-50 text-green-600 hover:bg-green-100'}`}>
                    {s.is_active ? '⏸ Nonaktifkan' : '▶ Aktifkan'}
                  </button>
                </div>
              )
            })}
          </div>
        )}

        {showForm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl w-full max-w-md">
              <div className="px-6 py-4 border-b flex justify-between"><h3 className="font-bold">Buat Jadwal Baru</h3><button onClick={()=>setShowForm(false)} className="text-gray-400">✕</button></div>
              <form onSubmit={handleCreate} className="p-6 space-y-4">
                <input className="input-field" required placeholder="Nama jadwal" value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))}/>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Template Checklist *</label>
                  <select className="input-field" required value={form.template_id} onChange={e=>setForm(f=>({...f,template_id:e.target.value}))}>
                    <option value="">— Pilih template —</option>
                    {templates.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Frekuensi</label>
                    <select className="input-field" value={form.freq} onChange={e=>setForm(f=>({...f,freq:e.target.value}))}>
                      {['daily','weekly','monthly'].map(v=><option key={v} value={v}>{freqLabel[v]}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Jam Tugas</label>
                    <input type="time" className="input-field" value={form.time} onChange={e=>setForm(f=>({...f,time:e.target.value}))}/>
                  </div>
                </div>
                {['monthly','quarterly'].includes(form.freq) && (
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Tanggal dalam bulan (1–28)</label>
                    <input type="number" className="input-field" min={1} max={28} value={form.day} onChange={e=>setForm(f=>({...f,day:+e.target.value}))}/>
                  </div>
                )}
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Ditugaskan ke</label>
                  <select className="input-field" value={form.assigned_role} onChange={e=>setForm(f=>({...f,assigned_role:e.target.value}))}>
                    <option value="teknisi">Teknisi</option>
                    <option value="housekeeping">Housekeeping</option>
                    <option value="spv_teknisi">SPV Teknisi</option>
                  </select>
                </div>
                <div className="flex gap-3"><button type="submit" className="btn-primary flex-1">Buat Jadwal</button><button type="button" onClick={()=>setShowForm(false)} className="btn-secondary flex-1">Batal</button></div>
              </form>
            </div>
          </div>
        )}
      </AdminLayout>
    </>
  )
}
