import Head from 'next/head'
import { useState, useEffect } from 'react'
import { useAuth } from '@/hooks/useAuth'
import { AdminLayout } from '@/components/layout/AdminLayout'
import { alarmsApi } from '@/lib/api'

const sc: Record<string,string> = { emergency:'border-l-4 border-red-500 bg-red-50', critical:'border-l-4 border-orange-500 bg-orange-50', major:'border-l-4 border-yellow-500 bg-yellow-50', warning:'border-l-4 border-blue-500 bg-blue-50' }
const si: Record<string,string> = { emergency:'🔴', critical:'🟠', major:'🟡', warning:'🔵' }

export default function AlarmsPage() {
  const { user, loading, logout } = useAuth(['building_admin','super_admin','spv_teknisi','company_admin'])
  const [alarms, setAlarms] = useState<any[]>([])
  const [sev, setSev] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ alarm_type:'hvac_fault', severity:'warning', title:'', message:'', location:'', floor:'' })

  const fetch_ = async () => {
    if (!user) return
    alarmsApi.list({ severity: sev || undefined }).then(r => setAlarms(r.data))
  }
  useEffect(() => { if (user) fetch_() }, [user, sev])

  const createAlarm = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user?.building_id) return
    await alarmsApi.create({ ...form, building_id: user.building_id })
    setShowForm(false)
    fetch_()
  }

  if (loading) return null
  if (!user) return null

  return (
    <>
      <Head><title>Alarm — SOMA BMS</title></Head>
      <AdminLayout user={user} onLogout={logout} title="Monitoring Alarm">
        <div className="flex gap-3 mb-6 items-center flex-wrap">
          <select className="input-field max-w-xs" value={sev} onChange={e => setSev(e.target.value)}>
            <option value="">Semua Tingkat</option>
            {['emergency','critical','major','warning'].map(s => <option key={s} value={s}>{s}</option>)}
          </select>
          <button onClick={fetch_} className="btn-secondary">🔄 Refresh</button>
          <div className="ml-auto"><button onClick={() => setShowForm(true)} className="btn-primary">+ Alarm Manual</button></div>
        </div>

        {alarms.length === 0 ? (
          <div className="text-center py-20 card"><p className="text-4xl mb-3">✅</p><p className="text-gray-500">Tidak ada alarm aktif</p></div>
        ) : (
          <div className="space-y-3">
            {alarms.map(a => (
              <div key={a.id} className={`rounded-xl p-4 ${sc[a.severity]||'bg-gray-50'}`}>
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3">
                    <span className="text-xl">{si[a.severity]||'⚪'}</span>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-semibold text-gray-800">{a.title}</p>
                        <span className="badge-gray text-xs">{a.alarm_type}</span>
                        <span className="text-xs capitalize text-gray-500">{a.severity}</span>
                      </div>
                      {a.message && <p className="text-sm text-gray-600 mt-0.5">{a.message}</p>}
                      <p className="text-xs text-gray-400 mt-1">📍 {a.location||'—'}{a.floor?` · Lt.${a.floor}`:''} · {a.created_at?new Date(a.created_at).toLocaleString('id-ID'):''}</p>
                    </div>
                  </div>
                  <div className="flex gap-2 flex-shrink-0">
                    {!a.acked && <button onClick={() => alarmsApi.ack(a.id).then(fetch_)} className="text-xs px-3 py-1.5 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700">Acknowledge</button>}
                    {a.status !== 'resolved' && <button onClick={() => alarmsApi.resolve(a.id).then(fetch_)} className="text-xs px-3 py-1.5 bg-green-600 text-white rounded-lg hover:bg-green-700">✅ Selesai</button>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {showForm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl w-full max-w-md">
              <div className="px-6 py-4 border-b flex justify-between"><h3 className="font-bold">Tambah Alarm Manual</h3><button onClick={() => setShowForm(false)} className="text-gray-400">✕</button></div>
              <form onSubmit={createAlarm} className="p-6 space-y-3">
                <input className="input-field" required placeholder="Judul *" value={form.title} onChange={e=>setForm(f=>({...f,title:e.target.value}))}/>
                <div className="grid grid-cols-2 gap-3">
                  <select className="input-field" value={form.alarm_type} onChange={e=>setForm(f=>({...f,alarm_type:e.target.value}))}>
                    {['hvac_fault','fire_smoke','fire_heat','sprinkler','panel_fault','manual_call'].map(t=><option key={t} value={t}>{t}</option>)}
                  </select>
                  <select className="input-field" value={form.severity} onChange={e=>setForm(f=>({...f,severity:e.target.value}))}>
                    {['emergency','critical','major','warning'].map(s=><option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <input className="input-field" placeholder="Lokasi" value={form.location} onChange={e=>setForm(f=>({...f,location:e.target.value}))}/>
                  <input className="input-field" placeholder="Lantai" value={form.floor} onChange={e=>setForm(f=>({...f,floor:e.target.value}))}/>
                </div>
                <textarea className="input-field" rows={2} placeholder="Pesan detail" value={form.message} onChange={e=>setForm(f=>({...f,message:e.target.value}))}/>
                <div className="flex gap-3"><button type="submit" className="btn-primary flex-1">Kirim Alarm</button><button type="button" onClick={()=>setShowForm(false)} className="btn-secondary flex-1">Batal</button></div>
              </form>
            </div>
          </div>
        )}
      </AdminLayout>
    </>
  )
}
