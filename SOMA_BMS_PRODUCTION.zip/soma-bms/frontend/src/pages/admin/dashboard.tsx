import Head from 'next/head'
import { useState, useEffect } from 'react'
import { useAuth } from '@/hooks/useAuth'
import { AdminLayout } from '@/components/layout/AdminLayout'
import { dashboardApi, alarmsApi, workOrdersApi, buildingsApi } from '@/lib/api'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts'

export default function AdminDashboard() {
  const { user, loading, logout } = useAuth(['building_admin','super_admin','company_admin','spv_teknisi'])
  const [stats, setStats] = useState<any>(null)
  const [alarms, setAlarms] = useState<any[]>([])
  const [recentWO, setRecentWO] = useState<any[]>([])
  const [building, setBuilding] = useState<any>(null)

  useEffect(() => {
    if (!user) return
    Promise.all([
      dashboardApi.adminStats(user.building_id),
      alarmsApi.list(),
      workOrdersApi.list({ building_id: user.building_id }),
      buildingsApi.list(),
    ]).then(([s, a, w, b]) => {
      setStats(s.data)
      setAlarms(a.data.slice(0, 5))
      setRecentWO(w.data.slice(0, 6))
      const found = (b.data as any[]).find((bld: any) => bld.id === user.building_id)
      setBuilding(found || null)
    }).catch(console.error)
  }, [user])

  if (loading) return <div className="min-h-screen bg-navy flex items-center justify-center text-white">Memuat...</div>
  if (!user) return null

  const chartData = stats ? [
    { name: 'Total', v: stats.tasks.total_today, color: '#6366f1' },
    { name: 'Selesai', v: stats.tasks.completed, color: '#10b981' },
    { name: 'Terlambat', v: stats.tasks.overdue, color: '#ef4444' },
  ] : []

  const sevIcon: Record<string, string> = { emergency: '🔴', critical: '🟠', major: '🟡', warning: '🔵', info: '⚪' }
  const prioColor: Record<string, string> = { emergency: 'badge-red', high: 'badge-orange', medium: 'badge-yellow', low: 'badge-blue' }
  const statColor: Record<string, string> = { completed: 'badge-green', in_progress: 'badge-blue', assigned: 'badge-yellow', open: 'badge-gray', pending_approval: 'badge-orange' }
  const buildingName = building?.name || 'Gedung'

  return (
    <>
      <Head><title>Dasbor — SOMA BMS</title></Head>
      <AdminLayout user={user} onLogout={logout} title={`Dasbor — ${buildingName}`}>
        {/* Building header */}
        {building && (
          <div className="flex items-center gap-3 bg-teal-50 border border-teal-200 rounded-xl px-4 py-3 mb-5">
            <span className="text-2xl">🏢</span>
            <div>
              <p className="font-semibold text-teal-800">{building.name}</p>
              <p className="text-xs text-teal-600">{building.address} · {building.floors_count} lantai · {building.total_area_m2?.toLocaleString('id-ID')} m²</p>
            </div>
          </div>
        )}

        {/* KPI Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {[
            { icon: '🔧', label: 'WO Aktif', value: stats?.work_orders.open ?? '—', sub: `${stats?.work_orders.emergency ?? 0} Emergency`, border: 'border-orange-400' },
            { icon: '✅', label: 'Compliance PM', value: stats ? `${stats.tasks.compliance_percent}%` : '—', sub: `${stats?.tasks.completed ?? 0}/${stats?.tasks.total_today ?? 0} selesai`, border: 'border-green-400' },
            { icon: '🚨', label: 'Alarm Aktif', value: stats?.alarms.active ?? '—', sub: `${stats?.alarms.critical ?? 0} Kritis`, border: 'border-red-400' },
            { icon: '🪪', label: 'Tamu On-site', value: stats?.visitors.on_premise ?? '—', sub: `${stats?.material_requests.pending ?? 0} req. material`, border: 'border-blue-400' },
          ].map(k => (
            <div key={k.label} className={`card border-l-4 ${k.border}`}>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xl">{k.icon}</span>
                <span className="text-xs text-gray-500">{k.label}</span>
              </div>
              <p className="text-2xl font-bold text-gray-800">{k.value}</p>
              <p className="text-xs text-gray-400 mt-1">{k.sub}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          {/* Task Chart */}
          <div className="lg:col-span-2 card">
            <h3 className="font-semibold text-gray-800 mb-4">📊 Status Tugas Hari Ini</h3>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="v" name="Jumlah" radius={[4, 4, 0, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Summary */}
          <div className="card space-y-3">
            <h3 className="font-semibold text-gray-800">📋 Ringkasan</h3>
            {[
              { label: 'Total Aset', v: stats?.assets.total ?? 0, icon: '🏗️' },
              { label: 'WO Selesai Hari Ini', v: stats?.work_orders.completed_today ?? 0, icon: '✅' },
              { label: 'Material Pending', v: stats?.material_requests.pending ?? 0, icon: '📦' },
              { label: 'Task Terlambat', v: stats?.tasks.overdue ?? 0, icon: '⚠️' },
            ].map(r => (
              <div key={r.label} className="flex items-center justify-between">
                <span className="text-sm text-gray-600">{r.icon} {r.label}</span>
                <span className={`font-semibold ${r.v > 0 && r.icon === '⚠️' ? 'text-red-600' : 'text-gray-800'}`}>{r.v}</span>
              </div>
            ))}
            <div className="pt-2 border-t border-gray-100">
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-500">Compliance Rate</span>
                <span className="font-bold text-green-600">{stats?.tasks.compliance_percent ?? 0}%</span>
              </div>
              <div className="bg-gray-100 rounded-full h-2">
                <div className="bg-green-500 h-2 rounded-full" style={{ width: `${stats?.tasks.compliance_percent ?? 0}%` }} />
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Alarms */}
          <div className="card">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold text-gray-800">🚨 Alarm Aktif</h3>
              <a href="/admin/alarms" className="text-xs text-teal-600 hover:underline">Lihat Semua →</a>
            </div>
            {alarms.length === 0 ? (
              <div className="text-center py-8 text-gray-400"><p className="text-3xl mb-2">✅</p><p className="text-sm">Tidak ada alarm aktif</p></div>
            ) : (
              <div className="space-y-2">
                {alarms.map(a => (
                  <div key={a.id} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                    <span className="text-lg">{sevIcon[a.severity] || '⚪'}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-800 truncate">{a.title}</p>
                      <p className="text-xs text-gray-500">{a.location}{a.floor ? ` · Lt.${a.floor}` : ''}</p>
                    </div>
                    <span className={`text-xs capitalize ${a.severity === 'emergency' ? 'badge-red' : a.severity === 'critical' ? 'badge-orange' : 'badge-yellow'}`}>{a.severity}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Recent WO */}
          <div className="card">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold text-gray-800">🔧 Work Order Terbaru</h3>
              <a href="/admin/work-orders" className="text-xs text-teal-600 hover:underline">Lihat Semua →</a>
            </div>
            {recentWO.length === 0 ? (
              <div className="text-center py-8 text-gray-400"><p className="text-3xl mb-2">📋</p><p className="text-sm">Belum ada Work Order</p></div>
            ) : (
              <div className="space-y-2">
                {recentWO.map(w => (
                  <div key={w.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-800 truncate">{w.title}</p>
                      <p className="text-xs text-gray-400">{w.wo_number}{w.floor ? ` · Lt.${w.floor}` : ''}</p>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <span className={`text-xs capitalize ${prioColor[w.priority] || 'badge-gray'}`}>{w.priority}</span>
                      <span className={`text-xs capitalize ${statColor[w.status] || 'badge-gray'}`}>{w.status?.replace(/_/g, ' ')}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </AdminLayout>
    </>
  )
}
