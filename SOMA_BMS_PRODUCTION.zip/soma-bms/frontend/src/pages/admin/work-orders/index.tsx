import Head from 'next/head'
import { useState, useEffect } from 'react'
import { useAuth } from '@/hooks/useAuth'
import { AdminLayout } from '@/components/layout/AdminLayout'
import { workOrdersApi, usersApi } from '@/lib/api'

const prio: Record<string,string> = { emergency:'badge-red',high:'badge-orange',medium:'badge-yellow',low:'badge-blue' }
const stat: Record<string,string> = { completed:'badge-green',in_progress:'badge-blue',assigned:'badge-yellow',open:'badge-gray',rejected:'badge-red' }

export default function AdminWorkOrders() {
  const { user, loading, logout } = useAuth(['building_admin','super_admin','spv_teknisi','company_admin'])
  const [wos, setWOs] = useState<any[]>([])
  const [users, setUsers] = useState<any[]>([])
  const [busy, setBusy] = useState(true)
  const [fStatus, setFStatus] = useState('')
  const [fPrio, setFPrio] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ title:'', description:'', priority:'medium', wo_type:'corrective', category:'', floor:'', location:'', assigned_to_id:'' })

  useEffect(() => {
    if (!user) return
    Promise.all([
      workOrdersApi.list({ building_id: user.building_id }),
      usersApi.list({ role:'teknisi', building_id: user.building_id }),
    ]).then(([w,u_]) => { setWOs(w.data); setUsers(u_.data) }).finally(() => setBusy(false))
  }, [user])

  const filtered = wos.filter(w =>
    (!fStatus || w.status === fStatus) &&
    (!fPrio || w.priority === fPrio)
  )

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user?.building_id) return
    try {
      const { data } = await workOrdersApi.create({
        ...form, building_id: user.building_id,
        assigned_to_id: form.assigned_to_id || undefined,
        status: form.assigned_to_id ? 'assigned' : 'open',
      })
      setWOs(p => [data, ...p])
      setShowForm(false)
    } catch (e: any) { alert(e.response?.data?.detail||'Gagal') }
  }

  if (loading) return null
  if (!user) return null

  return (
    <>
      <Head><title>Work Order — SOMA BMS</title></Head>
      <AdminLayout user={user} onLogout={logout} title="Manajemen Work Order">
        <div className="flex flex-wrap gap-3 mb-4 items-center">
          <select className="input-field max-w-xs" value={fStatus} onChange={e=>setFStatus(e.target.value)}>
            <option value="">Semua Status</option>
            {['open','assigned','in_progress','pending_approval','completed','rejected','cancelled'].map(s=><option key={s} value={s}>{s}</option>)}
          </select>
          <select className="input-field max-w-xs" value={fPrio} onChange={e=>setFPrio(e.target.value)}>
            <option value="">Semua Prioritas</option>
            {['emergency','high','medium','low'].map(p=><option key={p} value={p}>{p}</option>)}
          </select>
          <span className="text-sm text-gray-500">{filtered.length} WO</span>
          <div className="ml-auto"><button onClick={() => setShowForm(true)} className="btn-primary">+ Buat Work Order</button></div>
        </div>

        <div className="card overflow-hidden p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b">
                <tr>{['No.WO','Judul','Prioritas','Status','Lantai','Teknisi','Tenggat','Dibuat'].map(h=>(
                  <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase whitespace-nowrap">{h}</th>
                ))}</tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {busy ? <tr><td colSpan={8} className="text-center py-10 text-gray-400">⏳ Memuat...</td></tr> :
                 filtered.length===0 ? <tr><td colSpan={8} className="text-center py-10 text-gray-400">Belum ada Work Order</td></tr> :
                 filtered.map(w => (
                  <tr key={w.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 font-mono text-xs text-gray-400">{w.wo_number}</td>
                    <td className="px-4 py-3 font-medium text-gray-800 max-w-xs truncate">{w.title}</td>
                    <td className="px-4 py-3"><span className={prio[w.priority]||'badge-gray'}>{w.priority}</span></td>
                    <td className="px-4 py-3"><span className={stat[w.status]||'badge-gray'}>{w.status}</span></td>
                    <td className="px-4 py-3 text-gray-500">Lt.{w.floor||'?'}</td>
                    <td className="px-4 py-3 text-gray-500 text-xs">{w.assigned_to_id?users.find(u_=>u_.id===w.assigned_to_id)?.full_name||'Teknisi':'—'}</td>
                    <td className="px-4 py-3 text-gray-400 text-xs">{w.due_date?new Date(w.due_date).toLocaleDateString('id-ID'):'—'}</td>
                    <td className="px-4 py-3 text-gray-400 text-xs">{w.created_at?new Date(w.created_at).toLocaleDateString('id-ID'):'—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {showForm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
              <div className="px-6 py-4 border-b flex justify-between items-center">
                <h3 className="font-bold">Buat Work Order</h3>
                <button onClick={()=>setShowForm(false)} className="text-gray-400 text-xl">✕</button>
              </div>
              <form onSubmit={handleCreate} className="p-6 space-y-4">
                <div><label className="block text-xs font-medium text-gray-700 mb-1">Judul WO *</label>
                  <input className="input-field" required value={form.title} onChange={e=>setForm(f=>({...f,title:e.target.value}))} placeholder="Perbaikan AC Lt.5 Tidak Dingin"/>
                </div>
                <div><label className="block text-xs font-medium text-gray-700 mb-1">Deskripsi</label>
                  <textarea className="input-field" rows={2} value={form.description} onChange={e=>setForm(f=>({...f,description:e.target.value}))}/>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div><label className="block text-xs font-medium text-gray-700 mb-1">Prioritas</label>
                    <select className="input-field" value={form.priority} onChange={e=>setForm(f=>({...f,priority:e.target.value}))}>
                      {['emergency','high','medium','low'].map(p=><option key={p} value={p}>{p}</option>)}
                    </select>
                  </div>
                  <div><label className="block text-xs font-medium text-gray-700 mb-1">Tipe</label>
                    <select className="input-field" value={form.wo_type} onChange={e=>setForm(f=>({...f,wo_type:e.target.value}))}>
                      {['corrective','preventive','emergency'].map(t=><option key={t} value={t}>{t}</option>)}
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div><label className="block text-xs font-medium text-gray-700 mb-1">Lantai</label>
                    <input className="input-field" value={form.floor} onChange={e=>setForm(f=>({...f,floor:e.target.value}))} placeholder="5"/>
                  </div>
                  <div><label className="block text-xs font-medium text-gray-700 mb-1">Lokasi</label>
                    <input className="input-field" value={form.location} onChange={e=>setForm(f=>({...f,location:e.target.value}))}/>
                  </div>
                </div>
                <div><label className="block text-xs font-medium text-gray-700 mb-1">Tugaskan ke Teknisi</label>
                  <select className="input-field" value={form.assigned_to_id} onChange={e=>setForm(f=>({...f,assigned_to_id:e.target.value}))}>
                    <option value="">— Belum ditugaskan —</option>
                    {users.map(u_=><option key={u_.id} value={u_.id}>{u_.full_name}</option>)}
                  </select>
                </div>
                <div className="flex gap-3"><button type="submit" className="btn-primary flex-1">Buat WO</button>
                  <button type="button" onClick={()=>setShowForm(false)} className="btn-secondary flex-1">Batal</button>
                </div>
              </form>
            </div>
          </div>
        )}
      </AdminLayout>
    </>
  )
}
