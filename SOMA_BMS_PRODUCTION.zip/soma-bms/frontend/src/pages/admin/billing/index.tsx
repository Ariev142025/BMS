import Head from 'next/head'
import { useAuth } from '@/hooks/useAuth'
import { AdminLayout } from '@/components/layout/AdminLayout'
import { useState, useEffect } from 'react'
import { billingApi } from '@/lib/api'

export default function BillingPage() {
  const { user, loading, logout } = useAuth(['building_admin','super_admin'])
  const [meters, setMeters] = useState<any[]>([])
  const [invoices, setInvoices] = useState<any[]>([])
  const [tariffs, setTariffs] = useState<any[]>([])
  const [tab, setTab] = useState('generate')
  const [form, setForm] = useState({ tenant_name:'', period_start:'', period_end:'' })
  const [preview, setPreview] = useState<any>(null)
  const [generating, setGenerating] = useState(false)

  useEffect(() => {
    if (!user) return
    Promise.all([
      billingApi.meters.list({ building_id: user.building_id }),
      billingApi.invoices.list({ building_id: user.building_id }),
      billingApi.tariffs.list({ building_id: user.building_id }),
    ]).then(([m,i,t]) => { setMeters(m.data); setInvoices(i.data); setTariffs(t.data) })
  }, [user])

  const generate = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user?.building_id) return
    setGenerating(true)
    try {
      const { data } = await billingApi.invoices.generate({
        building_id: user.building_id, tenant_name: form.tenant_name||null,
        period_start: form.period_start, period_end: form.period_end,
      })
      setPreview(data)
    } catch (e: any) { alert(e.response?.data?.detail||'Gagal') }
    finally { setGenerating(false) }
  }

  const issue = async () => {
    if (!preview || !user?.building_id) return
    try {
      await billingApi.invoices.issue({ ...preview, building_id: user.building_id })
      alert('✅ Invoice diterbitkan!')
      const { data } = await billingApi.invoices.list({ building_id: user.building_id })
      setInvoices(data); setPreview(null)
    } catch (e: any) { alert(e.response?.data?.detail||'Gagal') }
  }

  const rp = (v: number) => new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',minimumFractionDigits:0}).format(v)

  if (loading) return null
  if (!user) return null

  return (
    <>
      <Head><title>Billing — SOMA BMS</title></Head>
      <AdminLayout user={user} onLogout={logout} title="Utilitas & Billing">
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-6 text-sm text-blue-800">
          💡 Data meter diambil otomatis dari checklist rutin teknisi. Pastikan teknisi sudah mencatat angka meter sebelum generate invoice.
        </div>

        <div className="flex gap-2 mb-6 border-b">
          {[['generate','⚡ Generate Invoice'],['invoices','📄 Daftar Invoice'],['meters','🔌 Meter'],['tariffs','💰 Tarif']].map(([k,l])=>(
            <button key={k} onClick={()=>setTab(k)}
              className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px ${tab===k?'border-teal-600 text-teal-600':'border-transparent text-gray-500 hover:text-gray-700'}`}>
              {l}
            </button>
          ))}
        </div>

        {tab==='generate' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="card">
              <h3 className="font-semibold mb-4">Generate Invoice Tagihan</h3>
              <form onSubmit={generate} className="space-y-4">
                <div><label className="block text-xs font-medium text-gray-700 mb-1">Nama Tenant (kosong = semua)</label>
                  <input className="input-field" value={form.tenant_name} onChange={e=>setForm(f=>({...f,tenant_name:e.target.value}))} placeholder="Tenant 1 Lt.2"/>
                </div>
                <div><label className="block text-xs font-medium text-gray-700 mb-1">Tanggal Awal *</label>
                  <input type="datetime-local" className="input-field" required value={form.period_start} onChange={e=>setForm(f=>({...f,period_start:e.target.value}))}/>
                </div>
                <div><label className="block text-xs font-medium text-gray-700 mb-1">Tanggal Akhir *</label>
                  <input type="datetime-local" className="input-field" required value={form.period_end} onChange={e=>setForm(f=>({...f,period_end:e.target.value}))}/>
                </div>
                <button type="submit" disabled={generating} className="btn-primary w-full py-2.5">
                  {generating?'Menghitung...':'⚡ Generate Preview Invoice'}
                </button>
              </form>
            </div>

            {preview && (
              <div className="card border-2 border-teal-200">
                <div className="flex justify-between items-center mb-3">
                  <h3 className="font-bold">Preview Invoice</h3>
                  <span className="text-xs font-mono text-teal-600">{preview.invoice_number}</span>
                </div>
                <div className="text-xs text-gray-500 mb-3">
                  <p>Tenant: <strong className="text-gray-700">{preview.tenant_name||'Semua'}</strong></p>
                  <p>Periode: {preview.period_start?new Date(preview.period_start).toLocaleDateString('id-ID'):''} — {preview.period_end?new Date(preview.period_end).toLocaleDateString('id-ID'):''}</p>
                </div>
                <div className="space-y-2 mb-3">
                  {preview.line_items?.map((item: any, i: number) => (
                    <div key={i} className="bg-gray-50 p-2 rounded-lg">
                      <div className="flex justify-between">
                        <span className="text-xs font-medium capitalize">{item.meter_type} — {item.meter_number}</span>
                        <span className="text-xs font-semibold">{rp(item.amount)}</span>
                      </div>
                      <p className="text-xs text-gray-400">{item.reading_start} → {item.reading_end} ({item.consumption} {item.unit}) × Rp{item.rate_per_unit?.toLocaleString('id-ID')}</p>
                    </div>
                  ))}
                </div>
                <div className="border-t pt-3 space-y-1 text-sm">
                  <div className="flex justify-between text-gray-600"><span>Subtotal</span><span>{rp(preview.subtotal)}</span></div>
                  <div className="flex justify-between text-gray-600"><span>Admin Fee</span><span>{rp(preview.admin_fee)}</span></div>
                  <div className="flex justify-between text-gray-600"><span>PPN {preview.ppn_percent}%</span><span>{rp(preview.ppn_amount)}</span></div>
                  <div className="flex justify-between font-bold text-base border-t pt-2"><span>TOTAL</span><span className="text-teal-600">{rp(preview.total_amount)}</span></div>
                </div>
                <button onClick={issue} className="btn-primary w-full mt-4">📄 Terbitkan Invoice</button>
              </div>
            )}
          </div>
        )}

        {tab==='invoices' && (
          <div className="card overflow-hidden p-0">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b">
                <tr>{['No. Invoice','Tenant','Periode','Total','Status'].map(h=>(
                  <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase">{h}</th>
                ))}</tr>
              </thead>
              <tbody className="divide-y">
                {invoices.length===0?<tr><td colSpan={5} className="text-center py-8 text-gray-400">Belum ada invoice</td></tr>:
                 invoices.map(inv=>(
                  <tr key={inv.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 font-mono text-xs text-gray-500">{inv.invoice_number}</td>
                    <td className="px-4 py-3 font-medium">{inv.tenant_name||'—'}</td>
                    <td className="px-4 py-3 text-xs text-gray-400">{inv.period_start?new Date(inv.period_start).toLocaleDateString('id-ID'):''} — {inv.period_end?new Date(inv.period_end).toLocaleDateString('id-ID'):''}</td>
                    <td className="px-4 py-3 font-semibold text-teal-600">{rp(inv.total_amount)}</td>
                    <td className="px-4 py-3"><span className={inv.status==='paid'?'badge-green':inv.status==='issued'?'badge-blue':'badge-yellow'}>{inv.status}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {tab==='meters' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {meters.map(m=>(
              <div key={m.id} className="card">
                <div className="flex items-center gap-3 mb-2">
                  <span className="text-2xl">{m.meter_type==='electricity'?'⚡':'💧'}</span>
                  <div>
                    <p className="font-semibold">{m.meter_number}</p>
                    <p className="text-xs text-gray-400 capitalize">{m.meter_type} · {m.unit}</p>
                  </div>
                </div>
                <p className="text-sm text-gray-600">Lantai: {m.floor||'—'}</p>
                <p className="text-sm text-gray-600">Tenant: {m.tenant_name||'—'}</p>
              </div>
            ))}
            {meters.length===0 && <div className="col-span-3 text-center py-10 text-gray-400 card">Jalankan seed data untuk mengisi meter demo.</div>}
          </div>
        )}

        {tab==='tariffs' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {tariffs.map(t=>(
              <div key={t.id} className="card border-l-4 border-teal-400">
                <p className="font-bold capitalize text-lg mb-2">{t.meter_type==='electricity'?'⚡':'💧'} {t.meter_type}</p>
                <p className="text-sm">Tarif: <strong>Rp{t.rate_per_unit?.toLocaleString('id-ID')}/unit</strong></p>
                <p className="text-sm">Admin Fee: <strong>Rp{t.admin_fee?.toLocaleString('id-ID')}</strong></p>
                <p className="text-sm">PPN: <strong>{t.ppn_percent}%</strong></p>
              </div>
            ))}
            {tariffs.length===0 && <div className="col-span-2 text-center py-10 text-gray-400 card">Jalankan seed data untuk tarif demo.</div>}
          </div>
        )}
      </AdminLayout>
    </>
  )
}
