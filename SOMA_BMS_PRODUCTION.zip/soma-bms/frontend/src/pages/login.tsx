import { useState } from 'react'
import Head from 'next/head'
import { useRouter } from 'next/router'
import { setCookie } from 'cookies-next'
import { authApi } from '@/lib/api'

const DEMO_ACCOUNTS = [
  { label: 'Super Admin', email: 'superadmin@somabms.com', role: 'super_admin', hint: 'Kelola semua tenant SaaS', dest: '/superadmin' },
  { label: 'Admin Gedung', email: 'admin@gedung.com', role: 'building_admin', hint: 'Dashboard admin lengkap', dest: '/admin/dashboard' },
  { label: 'TRO (Resepsionis)', email: 'tro@gedung.com', role: 'tro', hint: 'Manajemen tamu & akses', dest: '/tro/dashboard' },
  { label: 'SPV Teknisi', email: 'spv.teknisi@gedung.com', role: 'spv_teknisi', hint: 'Monitor tim & approval', dest: '/mobile/dashboard' },
  { label: 'Teknisi 1 (HVAC)', email: 'teknisi1@gedung.com', role: 'teknisi', hint: 'Checklist & maintenance', dest: '/mobile/dashboard' },
  { label: 'Teknisi 2 (Listrik)', email: 'teknisi2@gedung.com', role: 'teknisi', hint: 'Checklist & maintenance', dest: '/mobile/dashboard' },
  { label: 'SPV Housekeeping', email: 'spv.hk@gedung.com', role: 'spv_housekeeping', hint: 'Monitor & approval HK', dest: '/mobile/dashboard' },
  { label: 'Housekeeping 1', email: 'hk1@gedung.com', role: 'housekeeping', hint: 'Checklist kebersihan', dest: '/mobile/dashboard' },
]

function getDashboardPath(role: string): string {
  if (['teknisi', 'housekeeping', 'spv_teknisi', 'spv_housekeeping'].includes(role)) return '/mobile/dashboard'
  if (role === 'tro') return '/tro/dashboard'
  if (role === 'super_admin') return '/superadmin'
  return '/admin/dashboard'
}

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      const { data } = await authApi.login(email.trim(), password)
      setCookie('access_token', data.access_token, { maxAge: 60 * 480 })
      setCookie('user_email', data.email, { maxAge: 60 * 480 })
      setCookie('user_name', data.full_name, { maxAge: 60 * 480 })
      router.push(getDashboardPath(data.role))
    } catch (e: any) {
      setError(e.response?.data?.detail || 'Email atau password salah')
    } finally {
      setLoading(false)
    }
  }

  const quickLogin = (acc: typeof DEMO_ACCOUNTS[0]) => {
    setEmail(acc.email)
    setPassword('Demo123!')
    setError('')
  }

  return (
    <>
      <Head><title>Login — SOMA BMS</title></Head>
      <div className="min-h-screen bg-navy flex items-center justify-center p-4">
        <div className="w-full max-w-md space-y-4">
          {/* Logo */}
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-teal-600 rounded-2xl mx-auto mb-4 flex items-center justify-center shadow-lg">
              <span className="text-white font-bold text-2xl">SM</span>
            </div>
            <h1 className="text-2xl font-bold text-white">SOMA BMS</h1>
            <p className="text-gray-400 text-sm mt-1">Smart Building Management System</p>
          </div>

          {/* Login form */}
          <div className="bg-white rounded-2xl p-6 shadow-xl">
            <h2 className="text-lg font-semibold text-gray-800 mb-4">Masuk ke Akun</h2>
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Email</label>
                <input type="email" className="input-field" required autoComplete="email"
                  placeholder="email@gedung.com" value={email}
                  onChange={e => setEmail(e.target.value)} />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Password</label>
                <input type="password" className="input-field" required autoComplete="current-password"
                  placeholder="••••••••" value={password}
                  onChange={e => setPassword(e.target.value)} />
              </div>
              {error && <p className="text-red-600 text-sm bg-red-50 px-3 py-2 rounded-lg">❌ {error}</p>}
              <button type="submit" disabled={loading} className="btn-primary w-full py-3 text-base">
                {loading ? '⏳ Masuk...' : 'Masuk'}
              </button>
            </form>
          </div>

          {/* Register link */}
          <div className="text-center">
            <p className="text-gray-400 text-sm">
              Belum punya akun?{' '}
              <a href="/register" className="text-teal-400 hover:text-teal-300 font-medium">Daftar gratis →</a>
            </p>
          </div>

          {/* Demo accounts */}
          <div className="bg-white/10 rounded-2xl p-4">
            <p className="text-xs font-semibold text-gray-300 mb-3 uppercase tracking-wide">Akun Demo (password: Demo123!)</p>
            <div className="space-y-1.5">
              {DEMO_ACCOUNTS.map(acc => (
                <button key={acc.email} onClick={() => quickLogin(acc)}
                  className="w-full flex items-center gap-3 text-left bg-white/10 hover:bg-white/20 rounded-xl px-3 py-2.5 transition-colors group">
                  <div className="flex-1">
                    <p className="text-xs font-semibold text-white">{acc.label}</p>
                    <p className="text-xs text-gray-400">{acc.hint}</p>
                  </div>
                  <span className="text-xs text-teal-400 group-hover:text-teal-300 whitespace-nowrap">
                    {acc.dest === '/admin/dashboard' ? '🖥️ Admin' : acc.dest === '/tro/dashboard' ? '🪪 TRO' : '📱 Mobile'}
                  </span>
                </button>
              ))}
            </div>
            <p className="text-xs text-gray-500 mt-3 text-center">Klik akun demo → tombol Masuk</p>
          </div>
        </div>
      </div>
    </>
  )
}
