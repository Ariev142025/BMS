import Head from 'next/head'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useAuth } from '@/hooks/useAuth'
import { MobileLayout } from '@/components/layout/MobileLayout'
import { dashboardApi, alarmsApi, buildingsApi, usersApi } from '@/lib/api'

export default function MobileDashboard() {
  const { user, loading, logout } = useAuth(['teknisi','spv_teknisi','housekeeping','spv_housekeeping','building_admin'])
  const [stats, setStats] = useState<any>(null)
  const [alarms, setAlarms] = useState<any[]>([])
  const [building, setBuilding] = useState<any>(null)

  useEffect(() => {
    if (!user) return
    Promise.all([
      dashboardApi.myStats(),
      alarmsApi.list(),
      buildingsApi.list(),
    ]).then(([s, a, b]) => {
      setStats(s.data)
      setAlarms(a.data.slice(0,3))
      const found = (b.data as any[]).find((bld:any) => bld.id === user.building_id)
      setBuilding(found || null)
    }).catch(console.error)
  }, [user])

  if (loading) return (
    <div className="min-h-screen bg-navy flex items-center justify-center">
      <div className="text-center text-white">
        <div className="w-10 h-10 border-4 border-teal-400 border-t-transparent rounded-full animate-spin mx-auto mb-3"/>
        <p className="text-sm">Memuat...</p>
      </div>
    </div>
  )
  if (!user) return null

  const today = new Date().toLocaleDateString('id-ID',{weekday:'long',day:'numeric',month:'long'})
  const isHK = user.role.includes('housekeeping')
  const isSPV = user.role.includes('spv')
  const buildingName = building?.name || 'Gedung'
  const roleLabel: Record<string,string> = {
    teknisi:'👷 Teknisi', spv_teknisi:'👔 SPV Teknisi',
    housekeeping:'🧹 Housekeeping', spv_housekeeping:'👔 SPV Housekeeping',
    building_admin:'🏢 Admin Gedung',
  }

  return (
    <>
      <Head><title>Dasbor — SOMA BMS</title></Head>
      <MobileLayout user={user} onLogout={logout} title="SOMA BMS">
        <div className="bg-gradient-to-br from-navy to-[#1E3A5F] text-white px-4 py-5">
          <p className="text-xs text-gray-300">{today}</p>
          <h2 className="text-xl font-bold mt-1">Halo, {stats?.user_name||user.full_name.split(' ')[0]}! 👋</h2>
          <p className="text-xs text-teal-light mt-0.5">{roleLabel[user.role]||user.role.replace(/_/g,' ')} · {buildingName}</p>
          <div className="mt-4 bg-white/10 rounded-full h-2">
            <div className="bg-teal-400 h-2 rounded-full transition-all" style={{width:`${stats?.progress_percent||0}%`}}/>
          </div>
          <div className="flex justify-between mt-1 text-xs text-gray-300">
            <span>Progress Hari Ini</span>
            <span className="font-semibold text-white">{stats?.progress_percent||0}%</span>
          </div>
        </div>

        <div className="px-4 py-4 space-y-4">
          <div className="grid grid-cols-3 gap-3">
            <div className="mobile-card text-center p-3">
              <p className="text-2xl font-bold text-teal-600">{stats?.tasks_today||0}</p>
              <p className="text-xs text-gray-500 mt-0.5">Tugas</p>
            </div>
            <div className="mobile-card text-center p-3">
              <p className="text-2xl font-bold text-green-600">{stats?.tasks_completed||0}</p>
              <p className="text-xs text-gray-500 mt-0.5">Selesai</p>
            </div>
            <div className="mobile-card text-center p-3">
              <p className={`text-2xl font-bold ${(stats?.wo_active||0)>0?'text-orange-600':'text-gray-400'}`}>{stats?.wo_active||0}</p>
              <p className="text-xs text-gray-500 mt-0.5">Work Order</p>
            </div>
          </div>

          {(stats?.alarms_active||0)>0 && (
            <div className="bg-red-50 border border-red-200 rounded-2xl p-4">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-semibold text-red-700">🚨 Alarm Aktif ({stats.alarms_active})</p>
                <Link href="/mobile/alarms" className="text-xs text-red-600">Lihat →</Link>
              </div>
              {alarms.map(a => (
                <div key={a.id} className="flex items-center gap-2 py-1">
                  <span>{a.severity==='emergency'?'🔴':a.severity==='critical'?'🟠':'🟡'}</span>
                  <p className="text-xs text-red-800 truncate">{a.title}</p>
                </div>
              ))}
            </div>
          )}

          <div>
            <h3 className="text-sm font-semibold text-gray-700 mb-3">Menu Utama</h3>
            <div className="grid grid-cols-2 gap-3">
              {!isSPV && <Link href="/mobile/checklist" className="mobile-card flex flex-col items-center py-4 text-center no-underline hover:shadow-md transition-shadow">
                <span className="text-3xl mb-2">{isHK?'🧹':'✅'}</span>
                <p className="text-sm font-semibold text-gray-800">Checklist</p>
                <p className="text-xs text-gray-500">{stats?.tasks_pending||0} pending</p>
              </Link>}
              {!isHK && !isSPV && <Link href="/mobile/maintenance" className="mobile-card flex flex-col items-center py-4 text-center no-underline hover:shadow-md transition-shadow">
                <span className="text-3xl mb-2">🛠️</span>
                <p className="text-sm font-semibold text-gray-800">Maintenance</p>
                <p className="text-xs text-gray-500">Perawatan rutin</p>
              </Link>}
              <Link href="/mobile/work-orders" className="mobile-card flex flex-col items-center py-4 text-center no-underline hover:shadow-md transition-shadow">
                <span className="text-3xl mb-2">🔧</span>
                <p className="text-sm font-semibold text-gray-800">Work Order</p>
                <p className="text-xs text-gray-500">{stats?.wo_active||0} aktif</p>
              </Link>
              {isSPV && <Link href="/mobile/monitoring" className="mobile-card flex flex-col items-center py-4 text-center no-underline hover:shadow-md transition-shadow">
                <span className="text-3xl mb-2">👁️</span>
                <p className="text-sm font-semibold text-gray-800">Monitor Tim</p>
                <p className="text-xs text-gray-500">Status anggota</p>
              </Link>}
              {isSPV && <Link href="/mobile/approvals" className="mobile-card flex flex-col items-center py-4 text-center no-underline hover:shadow-md transition-shadow">
                <span className="text-3xl mb-2">✅</span>
                <p className="text-sm font-semibold text-gray-800">Approval</p>
                <p className="text-xs text-gray-500">Persetujuan</p>
              </Link>}
              <Link href="/mobile/materials" className="mobile-card flex flex-col items-center py-4 text-center no-underline hover:shadow-md transition-shadow">
                <span className="text-3xl mb-2">📦</span>
                <p className="text-sm font-semibold text-gray-800">Material</p>
                <p className="text-xs text-gray-500">{stats?.mat_requests_pending||0} pending</p>
              </Link>
              <Link href="/mobile/alarms" className="mobile-card flex flex-col items-center py-4 text-center no-underline hover:shadow-md transition-shadow">
                <span className="text-3xl mb-2">🚨</span>
                <p className="text-sm font-semibold text-gray-800">Alarm</p>
                <p className="text-xs text-gray-500">{stats?.alarms_active||0} aktif</p>
              </Link>
            </div>
          </div>

          {building && (
            <div className="mobile-card bg-gradient-to-r from-teal-50 to-blue-50 border border-teal-100">
              <div className="flex items-center gap-3">
                <span className="text-2xl">🏢</span>
                <div>
                  <p className="text-sm font-semibold text-gray-800">{building.name}</p>
                  <p className="text-xs text-gray-500">{building.address||building.city}</p>
                </div>
                <span className="ml-auto badge-green">Aktif</span>
              </div>
            </div>
          )}
        </div>
      </MobileLayout>
    </>
  )
}
