import Head from 'next/head'
import { useState, useEffect } from 'react'
import { useAuth } from '@/hooks/useAuth'
import { MobileLayout } from '@/components/layout/MobileLayout'
import { tasksApi, usersApi } from '@/lib/api'

export default function MobileMonitoring() {
  const { user, loading, logout } = useAuth(['spv_teknisi','spv_housekeeping','building_admin'])
  const [teamTasks, setTeamTasks] = useState<any[]>([])
  const [members, setMembers] = useState<any[]>([])
  const [busy, setBusy] = useState(true)

  useEffect(() => {
    if (!user) return
    const role = user.role.includes('housekeeping') ? 'housekeeping' : 'teknisi'
    Promise.all([
      tasksApi.buildingTasks({ building_id: user.building_id }),
      usersApi.list({ role, building_id: user.building_id }),
    ]).then(([t, m]) => {
      setTeamTasks(t.data)
      setMembers(m.data)
    }).finally(() => setBusy(false))
  }, [user])

  if (loading) return null
  if (!user) return null

  const getStatusColor = (status: string) => {
    if (status === 'completed') return 'bg-green-100 text-green-700'
    if (status === 'in_progress') return 'bg-blue-100 text-blue-700'
    if (status === 'overdue') return 'bg-red-100 text-red-700'
    return 'bg-gray-100 text-gray-600'
  }

  return (
    <>
      <Head><title>Monitor Tim — SOMA BMS</title></Head>
      <MobileLayout user={user} onLogout={logout} title="Monitor Tim">
        <div className="px-4 py-4 space-y-4">
          {/* Team Overview */}
          <div className="grid grid-cols-3 gap-3">
            <div className="mobile-card text-center p-3">
              <p className="text-2xl font-bold text-teal-600">{members.length}</p>
              <p className="text-xs text-gray-500">Anggota Tim</p>
            </div>
            <div className="mobile-card text-center p-3">
              <p className="text-2xl font-bold text-green-600">
                {teamTasks.filter(t=>t.status==='completed').length}
              </p>
              <p className="text-xs text-gray-500">Selesai</p>
            </div>
            <div className="mobile-card text-center p-3">
              <p className="text-2xl font-bold text-red-500">
                {teamTasks.filter(t=>t.status==='overdue').length}
              </p>
              <p className="text-xs text-gray-500">Terlambat</p>
            </div>
          </div>

          {/* Members */}
          <h3 className="text-sm font-bold text-gray-700">👥 Status Anggota Tim</h3>
          {busy ? <div className="text-center py-6 text-gray-400">⏳ Memuat...</div> :
           members.map(member => {
            const memberTasks = teamTasks.filter(t => t.assigned_user_id === member.id)
            const done = memberTasks.filter(t=>t.status==='completed').length
            const total = memberTasks.length
            const pct = total > 0 ? Math.round(done/total*100) : 0

            return (
              <div key={member.id} className="mobile-card">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-full bg-teal-100 flex items-center justify-center text-teal-700 font-bold flex-shrink-0">
                    {member.full_name.charAt(0)}
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-sm text-gray-800">{member.full_name}</p>
                    <p className="text-xs text-gray-500">{member.skill_category || member.role}</p>
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${pct===100?'bg-green-100 text-green-700':pct>50?'bg-blue-100 text-blue-700':'bg-gray-100 text-gray-600'}`}>
                    {done}/{total}
                  </span>
                </div>
                <div className="bg-gray-100 rounded-full h-1.5">
                  <div className={`h-1.5 rounded-full ${pct===100?'bg-green-500':pct>50?'bg-teal-500':'bg-blue-500'}`} style={{width:`${pct}%`}}/>
                </div>

                {memberTasks.length > 0 && (
                  <div className="mt-2 space-y-1">
                    {memberTasks.map(t => (
                      <div key={t.id} className="flex items-center justify-between py-0.5">
                        <p className="text-xs text-gray-600 truncate flex-1">{t.template_snapshot?.name || 'Tugas'}</p>
                        <span className={`text-xs px-1.5 py-0.5 rounded ml-2 ${getStatusColor(t.status)}`}>{t.status}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </MobileLayout>
    </>
  )
}
