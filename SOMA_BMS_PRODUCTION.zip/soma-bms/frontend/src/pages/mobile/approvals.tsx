import Head from 'next/head'
import { useState, useEffect } from 'react'
import { useAuth } from '@/hooks/useAuth'
import { MobileLayout } from '@/components/layout/MobileLayout'
import { workOrdersApi, materialsApi } from '@/lib/api'

export default function MobileApprovals() {
  const { user, loading, logout } = useAuth(['spv_teknisi','spv_housekeeping','building_admin'])
  const [pendingWOs, setPendingWOs] = useState<any[]>([])
  const [pendingMats, setPendingMats] = useState<any[]>([])
  const [busy, setBusy] = useState(true)

  const fetchData = async () => {
    if (!user) return
    Promise.all([
      workOrdersApi.list({ status: 'pending_approval' }),
      materialsApi.requests.list({ status: 'pending' }),
    ]).then(([w, m]) => {
      setPendingWOs(w.data)
      setPendingMats(m.data)
    }).finally(() => setBusy(false))
  }

  useEffect(() => { if (user) fetchData() }, [user])

  const approveWO = async (id: string, approved: boolean) => {
    await workOrdersApi.approve(id, approved)
    fetchData()
  }

  const approveMat = async (id: string, approved: boolean) => {
    await materialsApi.requests.approve(id, approved)
    fetchData()
  }

  if (loading) return null
  if (!user) return null

  const totalPending = pendingWOs.length + pendingMats.length

  return (
    <>
      <Head><title>Approval — SOMA BMS</title></Head>
      <MobileLayout user={user} onLogout={logout} title="Approval">
        <div className="px-4 py-4 space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-sm text-gray-500">{totalPending} menunggu approval</p>
            <button onClick={fetchData} className="text-xs text-teal-600">🔄 Refresh</button>
          </div>

          {busy ? <div className="text-center py-12 text-gray-400">⏳ Memuat...</div> :
           totalPending === 0 ? (
            <div className="text-center py-12">
              <p className="text-4xl mb-2">✅</p>
              <p className="text-gray-500">Tidak ada yang menunggu approval</p>
            </div>
          ) : (
            <>
              {pendingWOs.length > 0 && (
                <div>
                  <h3 className="text-sm font-bold text-gray-700 mb-2">🔧 Work Order ({pendingWOs.length})</h3>
                  {pendingWOs.map(wo => (
                    <div key={wo.id} className="mobile-card border-orange-200">
                      <p className="font-semibold text-sm text-gray-800 mb-1">{wo.title}</p>
                      <p className="text-xs text-gray-400 mb-1">{wo.wo_number} · Lt.{wo.floor||'?'}</p>
                      {wo.materials_used?.length > 0 && (
                        <p className="text-xs text-blue-600 mb-2">
                          📦 Material: {wo.materials_used.map((m: any)=>`${m.name} (${m.qty})`).join(', ')}
                        </p>
                      )}
                      <div className="flex gap-2 mt-2">
                        <button onClick={() => approveWO(wo.id, true)} className="flex-1 py-2.5 bg-green-600 text-white rounded-xl text-sm font-semibold">✅ Approve</button>
                        <button onClick={() => approveWO(wo.id, false)} className="flex-1 py-2.5 bg-red-500 text-white rounded-xl text-sm font-semibold">❌ Tolak</button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {pendingMats.length > 0 && (
                <div>
                  <h3 className="text-sm font-bold text-gray-700 mb-2">📦 Request Material ({pendingMats.length})</h3>
                  {pendingMats.map(req => (
                    <div key={req.id} className="mobile-card border-blue-200">
                      <p className="font-semibold text-sm text-gray-800">{req.material_name}</p>
                      <p className="text-xs text-gray-500 mb-1">{req.quantity} {req.unit} · {req.reason||'—'}</p>
                      <div className="flex gap-2 mt-2">
                        <button onClick={() => approveMat(req.id, true)} className="flex-1 py-2.5 bg-green-600 text-white rounded-xl text-sm font-semibold">✅ Setuju</button>
                        <button onClick={() => approveMat(req.id, false)} className="flex-1 py-2.5 bg-red-500 text-white rounded-xl text-sm font-semibold">❌ Tolak</button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </MobileLayout>
    </>
  )
}
