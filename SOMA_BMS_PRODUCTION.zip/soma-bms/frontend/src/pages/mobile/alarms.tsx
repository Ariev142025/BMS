import Head from 'next/head'
import { useState, useEffect } from 'react'
import { useAuth } from '@/hooks/useAuth'
import { MobileLayout } from '@/components/layout/MobileLayout'
import { alarmsApi } from '@/lib/api'

const sevColor: Record<string,string> = { emergency:'bg-red-100 border-red-300',critical:'bg-orange-100 border-orange-300',major:'bg-yellow-100 border-yellow-300',warning:'bg-blue-100 border-blue-300' }
const sevIcon: Record<string,string> = { emergency:'🔴',critical:'🟠',major:'🟡',warning:'🔵' }

export default function MobileAlarms() {
  const { user, loading, logout } = useAuth(['teknisi','spv_teknisi','housekeeping','spv_housekeeping','building_admin'])
  const [alarms, setAlarms] = useState<any[]>([])
  const [busy, setBusy] = useState(true)

  const fetch = async () => {
    if (!user) return
    alarmsApi.list().then(r => setAlarms(r.data)).finally(() => setBusy(false))
  }
  useEffect(() => { if (user) fetch() }, [user])

  const ack = async (id: string) => {
    await alarmsApi.ack(id)
    fetch()
  }
  const resolve = async (id: string) => {
    await alarmsApi.resolve(id)
    fetch()
  }

  if (loading) return null
  if (!user) return null

  return (
    <>
      <Head><title>Alarm — SOMA BMS</title></Head>
      <MobileLayout user={user} onLogout={logout} title="Alarm Aktif">
        <div className="px-4 py-4 space-y-3">
          <div className="flex justify-between items-center">
            <p className="text-sm text-gray-500">{alarms.length} alarm aktif</p>
            <button onClick={fetch} className="text-xs text-teal-600 hover:underline">🔄 Refresh</button>
          </div>

          {busy ? <div className="text-center py-10 text-gray-400">⏳ Memuat...</div> :
           alarms.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-4xl mb-2">✅</p>
              <p className="font-medium text-gray-500">Tidak ada alarm aktif</p>
              <p className="text-xs text-gray-400 mt-1">Semua sistem berjalan normal</p>
            </div>
          ) : alarms.map(alarm => (
            <div key={alarm.id} className={`border-2 rounded-2xl p-4 ${sevColor[alarm.severity]||'bg-gray-100 border-gray-200'}`}>
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-xl">{sevIcon[alarm.severity]||'⚪'}</span>
                  <div>
                    <p className="font-bold text-sm text-gray-800">{alarm.title}</p>
                    <p className="text-xs text-gray-500">{alarm.alarm_type}</p>
                  </div>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${alarm.acked?'bg-yellow-100 text-yellow-700':'bg-red-100 text-red-700'}`}>
                  {alarm.acked?'Acked':'Baru'}
                </span>
              </div>

              {alarm.message && <p className="text-xs text-gray-700 mb-2">{alarm.message}</p>}

              <div className="flex items-center gap-3 text-xs text-gray-500 mb-3">
                {alarm.location && <span>📍 {alarm.location}</span>}
                {alarm.floor && <span>Lt.{alarm.floor}</span>}
                <span>🕐 {new Date(alarm.created_at).toLocaleString('id-ID',{hour:'2-digit',minute:'2-digit'})}</span>
              </div>

              <div className="flex gap-2">
                {!alarm.acked && (
                  <button onClick={() => ack(alarm.id)} className="flex-1 py-2 text-xs bg-yellow-500 text-white rounded-xl font-medium">
                    ⚡ Acknowledge
                  </button>
                )}
                <button onClick={() => resolve(alarm.id)} className="flex-1 py-2 text-xs bg-green-600 text-white rounded-xl font-medium">
                  ✅ Selesaikan
                </button>
              </div>
            </div>
          ))}
        </div>
      </MobileLayout>
    </>
  )
}
