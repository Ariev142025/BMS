import Head from 'next/head'
import { useState, useEffect } from 'react'
import { useAuth } from '@/hooks/useAuth'
import { superAdminApi } from '@/lib/api'
import { useRouter } from 'next/router'

const rp = (v: number) => `Rp${(v||0).toLocaleString('id-ID')}`

const STATUS_BADGE: Record<string, string> = {
  trial: 'bg-blue-100 text-blue-800', active: 'bg-green-100 text-green-800',
  past_due: 'bg-red-100 text-red-800', suspended: 'bg-gray-200 text-gray-600',
  cancelled: 'bg-red-100 text-red-500',
}

export default function SuperAdminDashboard() {
  const { user, loading, logout } = useAuth(['super_admin'])
  const router = useRouter()
  const [stats, setStats] = useState<any>(null)
  const [companies, setCompanies] = useState<any[]>([])
  const [search, setSearch] = useState('')
  const [filterPlan, setFilterPlan] = useState('')
  const [filterStatus, setFilterStatus] = useState('')
  const [busy, setBusy] = useState(true)
  const [selected, setSelected] = useState<any>(null)
  const [editSub, setEditSub] = useState({ plan: '', status: '', extend_days: 0 })
  const [saving, setSaving] = useState(false)
  const [tab, setTab] = useState<'overview'|'companies'>('overview')

  const fetchAll = async () => {
    if (!user) return
    try {
      const [s, c] = await Promise.all([superAdminApi.stats(), superAdminApi.companies()])
      setStats(s.data); setCompanies(c.data)
    } finally { setBusy(false) }
  }

  const openDetail = async (id: string) => {
    const { data } = await superAdminApi.getCompany(id)
    setSelected(data)
    setEditSub({ plan: data.subscription?.plan || 'starter', status: data.subscription?.status || 'trial', extend_days: 30 })
  }

  const saveSubscription = async () => {
    if (!selected) return
    setSaving(true)
    try {
      const payload: any = { plan: editSub.plan, status: editSub.status }
      if (editSub.extend_days > 0) payload.extend_days = editSub.extend_days
      await superAdminApi.updateSubscription(selected.id, payload)
      const { data } = await superAdminApi.getCompany(selected.id)
      setSelected(data)
      fetchAll()
      alert('✅ Subscription diperbarui')
    } catch (e: any) { alert(e.response?.data?.detail || 'Gagal') }
    finally { setSaving(false) }
  }

  const toggleCompany = async (id: string) => {
    await superAdminApi.toggleCompany(id)
    fetchAll()
    if (selected?.id === id) {
      const { data } = await superAdminApi.getCompany(id)
      setSelected(data)
    }
  }

  useEffect(() => { if (user) fetchAll() }, [user])

  const filtered = companies.filter(c =>
    (!search || c.name.toLowerCase().includes(search.toLowerCase()) || c.email?.toLowerCase().includes(search.toLowerCase())) &&
    (!filterPlan || c.subscription?.plan === filterPlan) &&
    (!filterStatus || c.subscription?.status === filterStatus)
  )

  if (loading || busy) return (
    <div className="min-h-screen bg-navy flex items-center justify-center text-white">Memuat Super Admin...</div>
  )
  if (!user) return null

  return (
    <>
      <Head><title>Super Admin — SOMA BMS</title></Head>
      <div className="flex h-screen bg-gray-50 overflow-hidden">
        {/* Sidebar */}
        <aside className="w-56 bg-navy text-white flex flex-col fixed h-full z-20 shadow-xl">
          <div className="p-4 border-b border-white/10">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-teal-600 rounded-lg flex items-center justify-center font-bold text-xs">SM</div>
              <div>
                <p className="font-bold text-sm">SOMA BMS</p>
                <p className="text-xs text-teal-400">Super Admin Panel</p>
              </div>
            </div>
          </div>
          <div className="px-3 py-2 border-b border-white/10">
            <p className="text-xs text-gray-300 font-medium truncate">{user.full_name}</p>
            <p className="text-xs text-red-400">⚡ super_admin</p>
          </div>
          <nav className="flex-1 py-2 px-2 space-y-0.5">
            {[
              { key: 'overview', icon: '📊', label: 'Overview' },
              { key: 'companies', icon: '🏢', label: 'Semua Company' },
            ].map(item => (
              <button key={item.key} onClick={() => setTab(item.key as any)}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-all ${tab === item.key ? 'bg-teal-600 text-white' : 'text-gray-300 hover:bg-white/5 hover:text-white'}`}>
                <span>{item.icon}</span><span>{item.label}</span>
              </button>
            ))}
          </nav>
          <div className="p-3 border-t border-white/10">
            <button onClick={logout} className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-gray-400 hover:text-white hover:bg-white/5">
              <span>🚪</span><span>Keluar</span>
            </button>
          </div>
        </aside>

        {/* Main */}
        <div className="flex-1 ml-56 flex flex-col overflow-hidden">
          <header className="bg-white border-b px-6 py-3 flex items-center justify-between sticky top-0 z-10 shadow-sm">
            <h1 className="font-semibold text-gray-800">
              {tab === 'overview' ? '📊 Platform Overview' : '🏢 Manajemen Company'}
            </h1>
            <div className="flex items-center gap-3">
              <span className="text-xs text-gray-400">{new Date().toLocaleDateString('id-ID',{weekday:'long',day:'numeric',month:'long',year:'numeric'})}</span>
              <div className="w-8 h-8 rounded-full bg-red-600 flex items-center justify-center text-white text-xs font-bold">SA</div>
            </div>
          </header>
          <main className="flex-1 overflow-y-auto p-6">

            {/* OVERVIEW TAB */}
            {tab === 'overview' && (
              <div className="space-y-6">
                {/* KPI row */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  {[
                    { icon:'🏢', label:'Total Company', value: stats?.companies.total ?? '—', color:'border-blue-400' },
                    { icon:'🏗️', label:'Total Gedung', value: stats?.buildings.total ?? '—', color:'border-teal-400' },
                    { icon:'👥', label:'Total Pengguna', value: stats?.users.total ?? '—', color:'border-purple-400' },
                    { icon:'💰', label:'MRR', value: rp(stats?.revenue.mrr || 0), color:'border-green-400' },
                  ].map(k => (
                    <div key={k.label} className={`card border-l-4 ${k.color}`}>
                      <div className="flex items-center gap-2 mb-1"><span className="text-xl">{k.icon}</span><span className="text-xs text-gray-500">{k.label}</span></div>
                      <p className="text-2xl font-bold text-gray-800">{k.value}</p>
                    </div>
                  ))}
                </div>

                {/* Subscription breakdown + Revenue */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="card">
                    <h3 className="font-semibold text-gray-800 mb-4">📊 Status Langganan</h3>
                    <div className="space-y-3">
                      {[
                        { label:'✅ Aktif', count: stats?.subscriptions.active || 0, color:'text-green-600' },
                        { label:'⏳ Trial', count: stats?.subscriptions.trial || 0, color:'text-blue-600' },
                        { label:'❌ Past Due', count: stats?.subscriptions.past_due || 0, color:'text-red-600' },
                      ].map(s => (
                        <div key={s.label} className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">{s.label}</span>
                          <span className={`text-lg font-bold ${s.color}`}>{s.count}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="card">
                    <h3 className="font-semibold text-gray-800 mb-4">💰 Revenue</h3>
                    <div className="space-y-3">
                      {[
                        { label:'MRR (Monthly Recurring)', value: stats?.revenue.mrr_display || 'Rp0' },
                        { label:'Bulan Ini', value: stats?.revenue.this_month_display || 'Rp0' },
                        { label:'All-time Total', value: stats?.revenue.total_all_time_display || 'Rp0' },
                      ].map(r => (
                        <div key={r.label} className="flex items-center justify-between">
                          <span className="text-sm text-gray-500">{r.label}</span>
                          <span className="font-bold text-gray-800">{r.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Recent companies */}
                <div className="card overflow-hidden p-0">
                  <div className="px-4 py-3 border-b flex items-center justify-between">
                    <h3 className="font-semibold text-gray-800">🏢 Company Terbaru</h3>
                    <button onClick={() => setTab('companies')} className="text-xs text-teal-600 hover:underline">Lihat Semua →</button>
                  </div>
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50 border-b">
                      <tr>{['Company','Paket','Status','Gedung','User','Daftar'].map(h=>(
                        <th key={h} className="text-left px-4 py-2 text-xs font-semibold text-gray-500 uppercase">{h}</th>
                      ))}</tr>
                    </thead>
                    <tbody className="divide-y">
                      {companies.slice(0,5).map(c => (
                        <tr key={c.id} className="hover:bg-gray-50 cursor-pointer" onClick={() => { openDetail(c.id); setTab('companies') }}>
                          <td className="px-4 py-3"><p className="font-medium text-gray-800">{c.name}</p><p className="text-xs text-gray-400">{c.email}</p></td>
                          <td className="px-4 py-3 capitalize text-xs text-gray-600">{c.subscription?.plan || '—'}</td>
                          <td className="px-4 py-3"><span className={`text-xs px-2 py-0.5 rounded-full ${STATUS_BADGE[c.subscription?.status] || 'bg-gray-100 text-gray-500'}`}>{c.subscription?.status || '—'}</span></td>
                          <td className="px-4 py-3 text-gray-500">{c.buildings}</td>
                          <td className="px-4 py-3 text-gray-500">{c.users}</td>
                          <td className="px-4 py-3 text-xs text-gray-400">{c.created_at ? new Date(c.created_at).toLocaleDateString('id-ID') : '—'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* COMPANIES TAB */}
            {tab === 'companies' && (
              <div className="flex gap-6">
                {/* List */}
                <div className="flex-1 min-w-0">
                  {/* Filters */}
                  <div className="flex flex-wrap gap-3 mb-4">
                    <input className="input-field max-w-xs" placeholder="🔍 Cari company / email..." value={search} onChange={e => setSearch(e.target.value)} />
                    <select className="input-field max-w-xs" value={filterPlan} onChange={e => setFilterPlan(e.target.value)}>
                      <option value="">Semua Paket</option>
                      {['starter','professional','enterprise'].map(p=><option key={p} value={p}>{p}</option>)}
                    </select>
                    <select className="input-field max-w-xs" value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
                      <option value="">Semua Status</option>
                      {['trial','active','past_due','suspended','cancelled'].map(s=><option key={s} value={s}>{s}</option>)}
                    </select>
                    <span className="text-sm text-gray-500 self-center">{filtered.length} company</span>
                  </div>

                  <div className="card overflow-hidden p-0">
                    <table className="w-full text-sm">
                      <thead className="bg-gray-50 border-b">
                        <tr>{['Company','Paket','Status','Gedung','User','Aktif','Aksi'].map(h=>(
                          <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase whitespace-nowrap">{h}</th>
                        ))}</tr>
                      </thead>
                      <tbody className="divide-y">
                        {busy ? <tr><td colSpan={7} className="text-center py-10 text-gray-400">⏳ Memuat...</td></tr>
                          : filtered.length === 0 ? <tr><td colSpan={7} className="text-center py-10 text-gray-400">Tidak ada company</td></tr>
                          : filtered.map(c => (
                          <tr key={c.id} className={`hover:bg-gray-50 ${selected?.id === c.id ? 'bg-teal-50' : ''}`}>
                            <td className="px-4 py-3">
                              <p className="font-medium text-gray-800">{c.name}</p>
                              <p className="text-xs text-gray-400">{c.email}</p>
                            </td>
                            <td className="px-4 py-3 capitalize text-xs text-gray-600">{c.subscription?.plan || '—'}</td>
                            <td className="px-4 py-3">
                              <span className={`text-xs px-2 py-0.5 rounded-full ${STATUS_BADGE[c.subscription?.status] || 'bg-gray-100 text-gray-500'}`}>
                                {c.subscription?.status || '—'}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-gray-500">{c.buildings}</td>
                            <td className="px-4 py-3 text-gray-500">{c.users}</td>
                            <td className="px-4 py-3"><span className={c.is_active ? 'badge-green' : 'badge-gray'}>{c.is_active ? 'Ya' : 'Non'}</span></td>
                            <td className="px-4 py-3">
                              <div className="flex gap-1">
                                <button onClick={() => openDetail(c.id)} className="text-xs px-2 py-1 bg-blue-50 text-blue-600 rounded hover:bg-blue-100">Detail</button>
                                <button onClick={() => toggleCompany(c.id)} className={`text-xs px-2 py-1 rounded ${c.is_active ? 'bg-red-50 text-red-600 hover:bg-red-100' : 'bg-green-50 text-green-600 hover:bg-green-100'}`}>
                                  {c.is_active ? 'Suspend' : 'Aktifkan'}
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Detail panel */}
                {selected && (
                  <div className="w-80 flex-shrink-0 space-y-4">
                    <div className="card">
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="font-semibold text-gray-800 truncate">{selected.name}</h3>
                        <button onClick={() => setSelected(null)} className="text-gray-400 hover:text-gray-600">✕</button>
                      </div>
                      <p className="text-xs text-gray-500">{selected.email}</p>
                      {selected.address && <p className="text-xs text-gray-400 mt-1">{selected.address}</p>}
                      <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                        <div className="bg-gray-50 rounded p-2 text-center"><p className="text-lg font-bold text-gray-800">{selected.buildings?.length}</p><p className="text-gray-400">Gedung</p></div>
                        <div className="bg-gray-50 rounded p-2 text-center"><p className="text-lg font-bold text-gray-800">{selected.users_count}</p><p className="text-gray-400">Pengguna</p></div>
                      </div>
                    </div>

                    {/* Edit subscription */}
                    <div className="card">
                      <h3 className="font-semibold text-gray-800 mb-3">⚙ Edit Subscription</h3>
                      <div className="space-y-3">
                        <div>
                          <label className="block text-xs font-medium text-gray-600 mb-1">Paket</label>
                          <select className="input-field" value={editSub.plan} onChange={e => setEditSub(s => ({...s, plan: e.target.value}))}>
                            {['starter','professional','enterprise'].map(p=><option key={p} value={p}>{p}</option>)}
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-gray-600 mb-1">Status</label>
                          <select className="input-field" value={editSub.status} onChange={e => setEditSub(s => ({...s, status: e.target.value}))}>
                            {['trial','active','past_due','suspended','cancelled'].map(s=><option key={s} value={s}>{s}</option>)}
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-gray-600 mb-1">Perpanjang (hari)</label>
                          <input type="number" className="input-field" min={0} value={editSub.extend_days}
                            onChange={e => setEditSub(s => ({...s, extend_days: parseInt(e.target.value)||0}))} />
                        </div>
                        <button onClick={saveSubscription} disabled={saving} className="btn-primary w-full text-sm">
                          {saving ? 'Menyimpan...' : 'Simpan Perubahan'}
                        </button>
                      </div>
                    </div>

                    {/* Payment history */}
                    {selected.recent_payments?.length > 0 && (
                      <div className="card">
                        <h3 className="font-semibold text-gray-800 mb-3">💳 Pembayaran Terakhir</h3>
                        <div className="space-y-2">
                          {selected.recent_payments.map((t: any) => (
                            <div key={t.id} className="flex items-center justify-between text-xs">
                              <span className="text-gray-600 capitalize">{t.plan}</span>
                              <span className="font-medium text-gray-800">{t.amount_display}</span>
                              <span className={`px-1.5 py-0.5 rounded ${t.status==='paid'?'bg-green-100 text-green-700':'bg-yellow-100 text-yellow-700'}`}>{t.status}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Role breakdown */}
                    {selected.users_by_role && (
                      <div className="card">
                        <h3 className="font-semibold text-gray-800 mb-3">👥 Pengguna per Role</h3>
                        <div className="space-y-1">
                          {Object.entries(selected.users_by_role as Record<string,number>)
                            .filter(([,v]) => v > 0)
                            .map(([role, count]) => (
                              <div key={role} className="flex items-center justify-between text-xs">
                                <span className="text-gray-600 capitalize">{role.replace(/_/g,' ')}</span>
                                <span className="font-medium text-gray-800">{count as number}</span>
                              </div>
                            ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </main>
        </div>
      </div>
    </>
  )
}
