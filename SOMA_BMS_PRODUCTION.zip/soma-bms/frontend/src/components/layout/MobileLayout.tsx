import Link from 'next/link'
import { useRouter } from 'next/router'
import { AuthUser } from '@/hooks/useAuth'

interface NavItem { href: string; icon: string; label: string }

function getNavItems(role: string): NavItem[] {
  const isSPV = role.includes('spv')
  const isHK = role.includes('housekeeping')

  if (isSPV) return [
    { href: '/mobile/dashboard', icon: '🏠', label: 'Beranda' },
    { href: '/mobile/monitoring', icon: '👁️', label: 'Monitor' },
    { href: '/mobile/approvals', icon: '✅', label: 'Approval' },
    { href: '/mobile/work-orders', icon: '🔧', label: 'WO' },
    { href: '/mobile/profile', icon: '👤', label: 'Profil' },
  ]

  if (isHK) return [
    { href: '/mobile/dashboard', icon: '🏠', label: 'Beranda' },
    { href: '/mobile/checklist', icon: '🧹', label: 'Checklist' },
    { href: '/mobile/work-orders', icon: '🔧', label: 'WO' },
    { href: '/mobile/materials', icon: '📦', label: 'Material' },
    { href: '/mobile/profile', icon: '👤', label: 'Profil' },
  ]

  // teknisi (default)
  return [
    { href: '/mobile/dashboard', icon: '🏠', label: 'Beranda' },
    { href: '/mobile/checklist', icon: '✅', label: 'Checklist' },
    { href: '/mobile/maintenance', icon: '🛠️', label: 'PM' },
    { href: '/mobile/work-orders', icon: '🔧', label: 'WO' },
    { href: '/mobile/profile', icon: '👤', label: 'Profil' },
  ]
}

export function MobileLayout({ children, user, onLogout, title }: {
  children: React.ReactNode; user: AuthUser; onLogout: () => void; title?: string
}) {
  const router = useRouter()
  const navItems = getNavItems(user.role)
  const bottomNav = navItems.slice(0, 5)

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col max-w-md mx-auto relative">
      {/* Content */}
      <div className="flex-1 overflow-y-auto pb-20">
        {children}
      </div>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md bg-white border-t border-gray-200 z-30 shadow-lg">
        <div className="grid grid-cols-5 h-16">
          {bottomNav.map(item => {
            const active = router.pathname === item.href
            return (
              <Link key={item.href} href={item.href}
                className={`flex flex-col items-center justify-center gap-0.5 text-xs transition-colors ${active ? 'text-teal-600' : 'text-gray-400 hover:text-gray-600'}`}>
                <span className={`text-xl ${active ? 'scale-110' : ''} transition-transform`}>{item.icon}</span>
                <span className={`text-[10px] font-medium ${active ? 'text-teal-600' : ''}`}>{item.label}</span>
              </Link>
            )
          })}
        </div>
      </nav>
    </div>
  )
}
