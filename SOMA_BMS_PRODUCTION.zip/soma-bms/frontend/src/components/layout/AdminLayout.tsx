import Link from 'next/link'
import { useRouter } from 'next/router'
import { useEffect, useState } from 'react'
import { AuthUser } from '@/hooks/useAuth'
import { buildingsApi } from '@/lib/api'

const NAV = [
  { href: '/admin/dashboard', icon: '📊', label: 'Dasbor' },
  { href: '/admin/assets', icon: '🏗️', label: 'Aset' },
  { href: '/admin/templates', icon: '📋', label: 'Template Checklist' },
  { href: '/admin/schedules', icon: '📅', label: 'Penjadwalan' },
  { href: '/admin/work-orders', icon: '🔧', label: 'Work Order' },
  { href: '/admin/materials', icon: '📦', label: 'Material & Stok' },
  { href: '/admin/billing', icon: '⚡', label: 'Utilitas & Billing' },
  { href: '/admin/users', icon: '👥', label: 'Pengguna & Akses' },
  { href: '/tro/dashboard', icon: '🪪', label: 'TRO / Tamu' },
  { href: '/admin/alarms', icon: '🚨', label: 'Alarm' },
  { href: '/admin/subscription', icon: '💳', label: 'Langganan' },
]

export function AdminLayout({ children, user, onLogout, title }: {
  children: React.ReactNode; user: AuthUser; onLogout: () => void; title?: string
}) {
  const router = useRouter()
  const [building, setBuilding] = useState<any>(null)

  useEffect(() => {
    if (!user?.building_id) return
    buildingsApi.list().then(r => {
      const found = (r.data as any[]).find((b: any) => b.id === user.building_id)
      setBuilding(found || null)
    }).catch(() => {})
  }, [user])

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-60 bg-navy text-white flex flex-col fixed h-full z-20 shadow-xl">
        <div className="p-4 border-b border-white/10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-teal rounded-lg flex items-center justify-center font-bold text-xs flex-shrink-0 text-white">SM</div>
            <div>
              <p className="font-bold text-sm leading-tight">SOMA BMS</p>
              <p className="text-xs text-gray-400 truncate">{building?.name || 'Building Management'}</p>
            </div>
          </div>
        </div>
        <div className="px-3 py-2 border-b border-white/10">
          <p className="text-xs text-gray-300 font-medium truncate">{user.full_name}</p>
          <p className="text-xs text-teal-light capitalize">{user.role.replace(/_/g, ' ')}</p>
        </div>
        <nav className="flex-1 overflow-y-auto py-2 px-2 space-y-0.5">
          {NAV.map(item => {
            const active = router.pathname.startsWith(item.href) || (item.href === '/tro/dashboard' && router.pathname.startsWith('/tro'))
            return (
              <Link key={item.href} href={item.href}
                className={`flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-all ${active ? 'bg-teal-600 text-white' : 'text-gray-300 hover:bg-white/5 hover:text-white'}`}>
                <span>{item.icon}</span><span>{item.label}</span>
              </Link>
            )
          })}
        </nav>
        <div className="p-3 border-t border-white/10 space-y-1">
          <Link href="/mobile/dashboard" className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-gray-400 hover:text-white hover:bg-white/5">
            <span>📱</span><span>Mobile App</span>
          </Link>
          <button onClick={onLogout} className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-gray-400 hover:text-white hover:bg-white/5">
            <span>🚪</span><span>Keluar</span>
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 ml-60 flex flex-col overflow-hidden">
        <header className="bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between sticky top-0 z-10 shadow-sm">
          <h1 className="font-semibold text-gray-800">{title || 'SOMA BMS'}</h1>
          <div className="flex items-center gap-3">
            <span className="text-xs text-gray-400 hidden sm:block">
              {new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </span>
            <div className="w-8 h-8 rounded-full bg-teal-600 flex items-center justify-center text-white text-xs font-bold">
              {(user.full_name || 'U').charAt(0).toUpperCase()}
            </div>
          </div>
        </header>
        <main className="flex-1 overflow-y-auto p-6">{children}</main>
      </div>
    </div>
  )
}
