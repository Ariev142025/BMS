"""SOMA BMS IoT Simulator — generates realistic sensor data & alarms"""
import asyncio
import random
import logging
from datetime import datetime
import httpx
import os

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("simulator")

API_URL = os.getenv("API_URL", "http://localhost:8000/api/v1")
COMPANY_ID = os.getenv("COMPANY_ID", "aaaaaaaa-0000-0000-0000-000000000001")
BUILDING_ID = os.getenv("BUILDING_ID", "bbbbbbbb-0000-0000-0000-000000000001")
token = None


async def login(client: httpx.AsyncClient):
    global token
    resp = await client.post(f"{API_URL}/auth/login", json={"email": "superadmin@somabms.com", "password": "Demo123!"})
    if resp.status_code == 200:
        token = resp.json()["access_token"]
        log.info("✅ Logged in as superadmin")
    else:
        log.warning("⚠️ Login failed, retrying...")


def headers():
    return {"Authorization": f"Bearer {token}"} if token else {}


async def simulate_alarm(client: httpx.AsyncClient):
    """Occasionally generate realistic alarms"""
    if random.random() > 0.1:  # 10% chance each cycle
        return
    alarm_scenarios = [
        {"alarm_type": "hvac_fault", "severity": "warning", "title": "AC Indoor Suhu Naik", "message": "Suhu ruang melebihi setpoint 2°C", "floor": "5", "location": "Lt.5 Tenant 1"},
        {"alarm_type": "panel_fault", "severity": "major", "title": "MCB Trip Sub-Panel Lt.3", "message": "Circuit breaker trip, beban melebihi kapasitas", "floor": "3", "location": "Ruang Panel Lt.3"},
        {"alarm_type": "fire_smoke", "severity": "critical", "title": "Sensor Asap Aktif Lt.8", "message": "Detektor asap terdeteksi aktivitas tidak normal", "floor": "8", "location": "Koridor Lt.8"},
        {"alarm_type": "hvac_fault", "severity": "info", "title": "Filter AC Perlu Dibersihkan", "message": "ΔT melebihi normal, kemungkinan filter kotor", "floor": "2", "location": "Lt.2 Tenant 1"},
    ]
    scenario = random.choice(alarm_scenarios)
    resp = await client.post(f"{API_URL}/alarms", json={**scenario, "building_id": BUILDING_ID, "source": "iot"}, headers=headers())
    if resp.status_code == 201:
        log.info(f"🚨 Alarm created: {scenario['title']}")


async def simulate_parking(client: httpx.AsyncClient):
    """Simulate parking gate webhook"""
    plates = ["B 1234 XYZ", "B 5678 ABC", "D 9012 PQR", "B 3456 DEF"]
    plate = random.choice(plates)
    resp = await client.post(f"{API_URL}/visitors/parking/webhook", json={
        "plate_number": plate,
        "gate_id": "GATE-IN-01",
        "ticket_number": f"TKT-{random.randint(10000,99999)}",
    })
    if resp.status_code == 200:
        log.info(f"🚗 Parking: {plate} masuk")


async def run():
    async with httpx.AsyncClient(timeout=10.0) as client:
        await asyncio.sleep(15)  # Wait for backend to be ready
        await login(client)
        cycle = 0
        while True:
            cycle += 1
            log.info(f"🔄 Simulator cycle #{cycle}")
            try:
                await simulate_alarm(client)
                if cycle % 3 == 0:
                    await simulate_parking(client)
                if cycle % 30 == 0:
                    await login(client)  # Refresh token
            except Exception as e:
                log.error(f"Simulator error: {e}")
            await asyncio.sleep(60)  # Every 60 seconds


if __name__ == "__main__":
    log.info("🤖 SOMA BMS IoT Simulator starting...")
    asyncio.run(run())
