# SOMA BMS — Panduan Deploy Lengkap

## Daftar Isi
1. [Kebutuhan Sistem](#kebutuhan)
2. [Deploy Localhost](#localhost)
3. [Deploy VPS Live](#vps)
4. [Konfigurasi Duitku](#duitku)
5. [SSL dengan Let's Encrypt](#ssl)
6. [Backup Otomatis](#backup)
7. [Troubleshooting](#troubleshooting)

---

## 1. Kebutuhan Sistem {#kebutuhan}

### Untuk Localhost (Pengembangan / Demo)
| Kebutuhan | Versi | Catatan |
|-----------|-------|---------|
| Docker Desktop | ≥ 24 | https://www.docker.com/products/docker-desktop |
| Docker Compose | ≥ 2.x | Sudah termasuk di Docker Desktop |
| RAM | ≥ 4 GB | Minimal untuk semua container |
| Disk | ≥ 5 GB | Untuk image Docker + data |

### Untuk VPS Live (Production)
| Kebutuhan | Spesifikasi | Catatan |
|-----------|-------------|---------|
| VPS Provider | DigitalOcean / Vultr / IDCloudHost / Biznet Gio | Indonesia → Biznet Gio/IDCloudHost lebih murah |
| RAM | ≥ 2 GB (4 GB recommended) | 2 GB minimum untuk Docker |
| CPU | 2 vCPU | Cukup untuk 50 concurrent user |
| Storage | ≥ 40 GB SSD | PostgreSQL data + uploads |
| OS | Ubuntu 22.04 LTS | Sudah diuji di Ubuntu |
| Domain | somabms.perusahaan.co.id | Untuk SSL Let's Encrypt |
| Port | 80, 443 harus terbuka | Di firewall VPS |

---

## 2. Deploy Localhost {#localhost}

### Langkah 1 — Clone / Ekstrak project
```bash
unzip SOMA_BMS_SAAS_FINAL.zip
cd soma-bms
```

### Langkah 2 — Buat file .env
```bash
cp .env.example .env
```

Edit `.env` dengan nilai minimal untuk localhost:
```env
POSTGRES_PASSWORD=ganti_password_kuat_ini
REDIS_PASSWORD=redis_pass_ini
SECRET_KEY=jalankan_generate_secrets_sh_dulu

# Duitku (opsional untuk testing tanpa bayar)
DUITKU_MERCHANT_CODE=DS14678
DUITKU_API_KEY=your-sandbox-api-key
DUITKU_BASE_URL=https://sandbox.duitku.com/webapi/api
DUITKU_CALLBACK_URL=http://localhost:8000/api/v1/saas/payment/callback
DUITKU_RETURN_URL=http://localhost:3000/admin/subscription?status=paid

FRONTEND_URL=http://localhost:3000
NEXT_PUBLIC_API_URL=http://localhost:8000/api/v1
```

### Langkah 3 — Generate SECRET_KEY
```bash
bash scripts/generate-secrets.sh
```
Salin output ke `.env`.

### Langkah 4 — Jalankan
```bash
docker compose up -d --build
```

Tunggu ±2–3 menit. Cek status:
```bash
docker compose ps
# Semua harus status "healthy"
```

### Langkah 5 — Seed data demo
```bash
docker compose exec backend python -m app.seed
```

### Langkah 6 — Akses
| URL | Fungsi |
|-----|--------|
| http://localhost:3000 | Dashboard Web + Mobile |
| http://localhost:8000/docs | API Documentation |
| http://localhost:3000/register | Registrasi company baru |
| http://localhost:3000/superadmin | Super Admin panel |

**Login demo** (password: `Demo123!`):
- `admin@gedung.com` → Admin Dashboard
- `tro@gedung.com` → TRO Dashboard
- `teknisi1@gedung.com` → Mobile App

---

## 3. Deploy VPS Live {#vps}

### Langkah 1 — Setup VPS baru (Ubuntu 22.04)

```bash
# Login ke VPS
ssh root@IP_VPS_ANDA

# Update sistem
apt update && apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

# Install Docker Compose plugin
apt install -y docker-compose-plugin

# Verifikasi
docker --version
docker compose version
```

### Langkah 2 — Setup Firewall
```bash
ufw allow 22      # SSH
ufw allow 80      # HTTP
ufw allow 443     # HTTPS
ufw deny 5432     # Blokir akses langsung ke PostgreSQL
ufw deny 6379     # Blokir akses langsung ke Redis
ufw deny 8000     # Blokir backend langsung (harus lewat nginx)
ufw deny 3000     # Blokir frontend langsung (harus lewat nginx)
ufw enable
```

### Langkah 3 — Upload project ke VPS
```bash
# Dari komputer lokal:
scp SOMA_BMS_SAAS_FINAL.zip root@IP_VPS:/opt/soma-bms.zip
ssh root@IP_VPS
cd /opt && unzip soma-bms.zip && cd soma-bms
```

### Langkah 4 — Konfigurasi .env untuk VPS
```bash
cp .env.example .env
nano .env
```

Isi `.env`:
```env
# Database
POSTGRES_DB=soma_bms
POSTGRES_USER=soma_user
POSTGRES_PASSWORD=BUAT_PASSWORD_ACAK_PANJANG

# Redis
REDIS_PASSWORD=BUAT_REDIS_PASSWORD

# JWT Secret (wajib ganti!)
SECRET_KEY=BUAT_64_KARAKTER_ACAK

# App URLs - ganti dengan domain Anda
FRONTEND_URL=https://somabms.perusahaan.co.id
NEXT_PUBLIC_API_URL=https://api.somabms.perusahaan.co.id/api/v1

# Duitku (gunakan URL production)
DUITKU_MERCHANT_CODE=ISI_DARI_DASHBOARD_DUITKU
DUITKU_API_KEY=ISI_DARI_DASHBOARD_DUITKU
DUITKU_BASE_URL=https://passport.duitku.com/webapi/api
DUITKU_CALLBACK_URL=https://api.somabms.perusahaan.co.id/api/v1/saas/payment/callback
DUITKU_RETURN_URL=https://somabms.perusahaan.co.id/admin/subscription?status=paid
```

### Langkah 5 — Edit nginx.conf ganti domain
```bash
sed -i 's/somabms.yourdomain.com/somabms.perusahaan.co.id/g' nginx/nginx.conf
sed -i 's/api.somabms.yourdomain.com/api.somabms.perusahaan.co.id/g' nginx/nginx.conf
```

### Langkah 6 — Aktifkan nginx di docker-compose.yml
Edit `docker-compose.yml`, **uncomment** blok nginx:
```yaml
  nginx:
    image: nginx:alpine
    container_name: soma_nginx
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf:ro
      - certbot_conf:/etc/letsencrypt:ro
      - certbot_www:/var/www/certbot:ro
    depends_on:
      - frontend
      - backend
    networks:
      - soma_internal
```

Dan **comment** port 8000 + 3000 di backend/frontend services:
```yaml
backend:
  # ports:          # ← comment ini
  #   - "8000:8000" # ← comment ini
  expose:
    - "8000"        # internal only

frontend:
  # ports:          # ← comment ini
  #   - "3000:3000" # ← comment ini
  expose:
    - "3000"        # internal only
```

### Langkah 7 — SSL Let's Encrypt (lihat seksi 5)

### Langkah 8 — Jalankan production
```bash
docker compose up -d --build
docker compose exec backend python -m app.seed
docker compose ps  # semua harus healthy
```

### Langkah 9 — Setup cron backup otomatis
```bash
crontab -e
# Tambahkan:
0 2 * * * cd /opt/soma-bms && bash scripts/backup-db.sh >> /var/log/soma-backup.log 2>&1
```

---

## 4. Konfigurasi Duitku {#duitku}

### Daftar akun Duitku
1. Buka https://sandbox.duitku.com → Register → Login
2. Dashboard → **Project** → **Add Project**
3. Catat **Merchant Code** dan **API Key**
4. Set **Callback URL**: `https://api.domain.com/api/v1/saas/payment/callback`
5. Set **Return URL**: `https://domain.com/admin/subscription?status=paid`

### Mode Sandbox vs Production
| | Sandbox | Production |
|-|---------|-----------|
| URL | `https://sandbox.duitku.com/webapi/api` | `https://passport.duitku.com/webapi/api` |
| Pembayaran | Simulasi saja | Uang nyata |
| Kegunaan | Testing lokal | Go-live |

### Testing Duitku di Localhost
Karena Duitku perlu callback ke URL publik, gunakan **ngrok** untuk testing lokal:
```bash
# Install ngrok: https://ngrok.com
ngrok http 8000

# Output: https://abc123.ngrok.io → localhost:8000
# Set di .env:
# DUITKU_CALLBACK_URL=https://abc123.ngrok.io/api/v1/saas/payment/callback
```

---

## 5. SSL dengan Let's Encrypt {#ssl}

### Langkah 1 — Pastikan domain sudah pointing ke IP VPS
```bash
# Cek DNS sudah benar:
nslookup somabms.perusahaan.co.id
# Harus return IP VPS Anda
```

### Langkah 2 — Jalankan nginx dulu (HTTP only sementara)
Edit `nginx/nginx.conf` — comment dulu blok server 443 (SSL), jalankan hanya port 80:
```bash
docker compose up -d nginx
```

### Langkah 3 — Generate SSL certificate
```bash
docker run --rm \
  -v $(pwd)/nginx/ssl:/etc/letsencrypt \
  -v $(pwd)/nginx/certbot-www:/var/www/certbot \
  -p 80:80 \
  certbot/certbot certonly \
  --standalone \
  --email email@perusahaan.co.id \
  --agree-tos \
  --no-eff-email \
  -d somabms.perusahaan.co.id \
  -d api.somabms.perusahaan.co.id
```

### Langkah 4 — Update nginx.conf SSL path
```bash
# Sesuaikan path certificate di nginx/nginx.conf:
# ssl_certificate /etc/nginx/ssl/live/somabms.perusahaan.co.id/fullchain.pem;
# ssl_certificate_key /etc/nginx/ssl/live/somabms.perusahaan.co.id/privkey.pem;
```

### Langkah 5 — Restart dengan SSL aktif
```bash
docker compose restart nginx
```

### Auto-renewal SSL
```bash
crontab -e
# Tambahkan:
0 3 1 * * docker run --rm -v $(pwd)/nginx/ssl:/etc/letsencrypt certbot/certbot renew --quiet && docker restart soma_nginx
```

---

## 6. Backup Otomatis {#backup}

```bash
# Backup manual:
bash scripts/backup-db.sh

# Restore:
bash scripts/restore-db.sh backups/soma_bms_20260501_020000.sql.gz

# Cron harian jam 02:00:
0 2 * * * cd /opt/soma-bms && bash scripts/backup-db.sh >> /var/log/soma-backup.log 2>&1
```

---

## 7. Troubleshooting {#troubleshooting}

### Container tidak mau start
```bash
docker compose logs backend --tail=50
docker compose logs postgres --tail=30
```

### Reset semua data (mulai dari awal)
```bash
docker compose down -v   # hapus container + volume
docker compose up -d --build
docker compose exec backend python -m app.seed
```

### Update kode tanpa hapus data
```bash
git pull  # atau upload file baru
docker compose build backend frontend
docker compose up -d backend frontend
```

### Cek health semua service
```bash
docker compose ps
curl http://localhost:8000/health
```

### Ganti SECRET_KEY (invalidate semua JWT)
```bash
# Edit .env → ganti SECRET_KEY → restart
docker compose restart backend
# Semua user harus login ulang
```

### Port 3000 sudah dipakai
```bash
lsof -i :3000  # cari proses yang pakai
# Atau ganti port di docker-compose.yml: "3001:3000"
```

---

## Monitoring (Opsional tapi Recommended)

### Uptime monitoring gratis
- **UptimeRobot** (https://uptimerobot.com) — monitor http://domain/health setiap 5 menit
- Alert via email/Telegram jika down

### Log management
```bash
# Lihat log real-time:
docker compose logs -f backend
docker compose logs -f nginx

# Log semua service:
docker compose logs --tail=100
```

---

## Estimasi Biaya VPS

| Provider | Spec | Harga/Bulan | Cocok untuk |
|----------|------|-------------|-------------|
| IDCloudHost | 2 vCPU / 2 GB | Rp 45.000 | Development |
| Biznet Gio | 2 vCPU / 4 GB | Rp 165.000 | Production < 20 gedung |
| DigitalOcean | 2 vCPU / 4 GB | $24 (~Rp380.000) | Production internasional |
| Vultr | 2 vCPU / 4 GB | $20 (~Rp315.000) | Alternatif DO |

**Rekomendasi untuk mulai**: IDCloudHost 4 GB RAM (~Rp 90.000/bln) — cukup untuk 5–10 company tenant.

