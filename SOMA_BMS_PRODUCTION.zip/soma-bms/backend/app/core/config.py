from pydantic_settings import BaseSettings
from typing import Optional
from functools import lru_cache


class Settings(BaseSettings):
    APP_NAME: str = "SOMA BMS"
    DEBUG: bool = True
    SECRET_KEY: str = "soma-bms-secret-2026-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 480
    DATABASE_URL: str = "postgresql+asyncpg://soma_user:soma_password@postgres:5432/soma_bms"
    REDIS_URL: str = "redis://redis:6379/0"
    FRONTEND_URL: str = "http://localhost:3000"

    class Config:
        env_file = ".env"
        extra = "ignore"


@lru_cache()
def get_settings() -> Settings:
    return Settings()
