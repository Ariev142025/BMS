"""
SOMA BMS — Complete Data Models
All models in correct dependency order for SQLAlchemy.
Multi-tenant: every record has company_id + building_id for strict isolation.
"""
import uuid
import enum
from datetime import datetime, date, time
from sqlalchemy import (
    Column, String, Boolean, Integer, Float, Text, JSON,
    DateTime, Date, Time, ForeignKey, Enum as SAEnum, UniqueConstraint, Index
)
from sqlalchemy.dialects.postgresql import UUID
from app.core.database import Base


# ─────────────────────────────────────────────────────────────
# ENUMS
# ─────────────────────────────────────────────────────────────

class UserRole(str, enum.Enum):
    SUPER_ADMIN = "super_admin"
    COMPANY_ADMIN = "company_admin"
    BUILDING_ADMIN = "building_admin"
    SPV_TEKNISI = "spv_teknisi"
    TEKNISI = "teknisi"
    SPV_HOUSEKEEPING = "spv_housekeeping"
    HOUSEKEEPING = "housekeeping"
    TRO = "tro"


class WOStatus(str, enum.Enum):
    OPEN = "open"
    ASSIGNED = "assigned"
    IN_PROGRESS = "in_progress"
    PENDING_APPROVAL = "pending_approval"
    COMPLETED = "completed"
    REJECTED = "rejected"
    CANCELLED = "cancelled"


class WOPriority(str, enum.Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    EMERGENCY = "emergency"


class TaskStatus(str, enum.Enum):
    ASSIGNED = "assigned"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    OVERDUE = "overdue"
    SKIPPED = "skipped"


class AlarmSeverity(str, enum.Enum):
    EMERGENCY = "emergency"
    CRITICAL = "critical"
    MAJOR = "major"
    WARNING = "warning"
    INFO = "info"


class AlarmStatus(str, enum.Enum):
    ACTIVE = "active"
    ACKED = "acked"
    RESOLVED = "resolved"


class VisitStatus(str, enum.Enum):
    SCHEDULED = "scheduled"
    ON_PREMISE = "on_premise"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class MeterType(str, enum.Enum):
    ELECTRICITY = "electricity"
    WATER = "water"
    GAS = "gas"


class TransactionType(str, enum.Enum):
    STOCK_IN = "stock_in"
    USAGE = "usage"
    RETURN = "return"
    ADJUSTMENT = "adjustment"


class InvoiceStatus(str, enum.Enum):
    DRAFT = "draft"
    ISSUED = "issued"
    PAID = "paid"
    CANCELLED = "cancelled"


# ─────────────────────────────────────────────────────────────
# TIER 0: COMPANIES (SaaS tenants)
# ─────────────────────────────────────────────────────────────

class Company(Base):
    __tablename__ = "companies"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    email = Column(String(255))
    phone = Column(String(50))
    address = Column(Text)
    subscription_plan = Column(String(50), default="essential")
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


# ─────────────────────────────────────────────────────────────
# TIER 1: BUILDINGS (owned by company)
# ─────────────────────────────────────────────────────────────

class Building(Base):
    __tablename__ = "buildings"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(255), nullable=False)
    address = Column(Text)
    city = Column(String(100), default="Jakarta")
    floors_count = Column(Integer, default=10)
    total_area_m2 = Column(Float)
    contact_name = Column(String(255))
    contact_phone = Column(String(50))
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (
        Index("ix_buildings_company_id", "company_id"),
    )


# ─────────────────────────────────────────────────────────────
# TIER 2: USERS (belong to company + optional building)
# ─────────────────────────────────────────────────────────────

class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    building_id = Column(UUID(as_uuid=True), ForeignKey("buildings.id", ondelete="SET NULL"), nullable=True, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(255), nullable=False)
    phone = Column(String(50))
    role = Column(SAEnum(UserRole), nullable=False)
    skill_category = Column(String(100))  # HVAC, Elektrikal, Plumbing...
    is_active = Column(Boolean, default=True)
    fcm_token = Column(String(500))  # Firebase push notification
    last_login = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Shift(Base):
    __tablename__ = "shifts"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=False)
    building_id = Column(UUID(as_uuid=True), ForeignKey("buildings.id"), nullable=False)
    name = Column(String(50), nullable=False)
    start_time = Column(Time, nullable=False)
    end_time = Column(Time, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class ShiftAssignment(Base):
    __tablename__ = "shift_assignments"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=False)
    building_id = Column(UUID(as_uuid=True), ForeignKey("buildings.id"), nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    shift_id = Column(UUID(as_uuid=True), ForeignKey("shifts.id", ondelete="CASCADE"), nullable=False)
    assignment_date = Column(Date, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint("user_id", "assignment_date", name="uq_shift_user_date"),
    )


# ─────────────────────────────────────────────────────────────
# TIER 3: ASSETS (belong to building)
# ─────────────────────────────────────────────────────────────

class Asset(Base):
    __tablename__ = "assets"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=False, index=True)
    building_id = Column(UUID(as_uuid=True), ForeignKey("buildings.id", ondelete="CASCADE"), nullable=False, index=True)
    asset_code = Column(String(100), index=True)
    category = Column(String(100), nullable=False, index=True)
    sub_category = Column(String(100))
    name = Column(String(255), nullable=False)
    floor = Column(String(50))
    location = Column(String(255))
    quantity = Column(Integer, default=1)
    brand = Column(String(100))
    model = Column(String(100))
    serial_number = Column(String(100))
    specifications = Column(JSON, default=dict)
    installation_date = Column(DateTime)
    warranty_expiry = Column(DateTime)
    expiry_date = Column(DateTime)  # for APAR/consumables
    condition = Column(String(50), default="good")  # good/fair/damaged
    notes = Column(Text)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (
        Index("ix_assets_company_building", "company_id", "building_id"),
    )


# ─────────────────────────────────────────────────────────────
# TIER 4: CHECKLIST TEMPLATES
# ─────────────────────────────────────────────────────────────

class ChecklistTemplate(Base):
    __tablename__ = "checklist_templates"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=False, index=True)
    building_id = Column(UUID(as_uuid=True), ForeignKey("buildings.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(255), nullable=False)
    template_type = Column(String(50), default="checklist")  # checklist / maintenance
    category = Column(String(100), nullable=False)
    sub_category = Column(String(100))
    estimated_duration_minutes = Column(Integer, default=30)
    # sections: [{"title": "...", "description": "...", "steps": [
    #   {"instruction": "...", "input_type": "checkbox|radio|numeric|text|photo",
    #    "options": [], "required": true, "require_photo": false,
    #    "unit": null, "min_value": null, "max_value": null,
    #    "meter_number": null, "meter_type": null}
    # ]}]
    sections = Column(JSON, default=list)
    # [{"name": "Filter MERV8", "unit": "pcs", "default_qty": 1}]
    default_materials = Column(JSON, default=list)
    version = Column(Integer, default=1)
    is_active = Column(Boolean, default=True)
    description = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


# ─────────────────────────────────────────────────────────────
# TIER 5: SCHEDULE RULES + TASK INSTANCES
# ─────────────────────────────────────────────────────────────

class ScheduleRule(Base):
    __tablename__ = "schedule_rules"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=False, index=True)
    building_id = Column(UUID(as_uuid=True), ForeignKey("buildings.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(255), nullable=False)
    template_id = Column(UUID(as_uuid=True), ForeignKey("checklist_templates.id"), nullable=False)
    asset_ids = Column(JSON, default=list)   # list of asset UUID strings
    area_ids = Column(JSON, default=list)    # for HK area assignments
    # {"freq": "daily|weekly|monthly|quarterly|yearly",
    #  "interval": 1, "day": 1, "days": ["monday","friday"],
    #  "month": 1, "time": "08:00"}
    recurrence_pattern = Column(JSON, nullable=False)
    assigned_role = Column(String(50), nullable=False)
    assigned_user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    is_active = Column(Boolean, default=True)
    start_date = Column(DateTime)
    end_date = Column(DateTime)
    last_generated = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class TaskInstance(Base):
    __tablename__ = "task_instances"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=False, index=True)
    building_id = Column(UUID(as_uuid=True), ForeignKey("buildings.id", ondelete="CASCADE"), nullable=False, index=True)
    schedule_rule_id = Column(UUID(as_uuid=True), ForeignKey("schedule_rules.id", ondelete="SET NULL"), nullable=True)
    template_id = Column(UUID(as_uuid=True), ForeignKey("checklist_templates.id"), nullable=False)
    template_snapshot = Column(JSON, default=dict)  # snapshot of template at time of creation
    asset_id = Column(UUID(as_uuid=True), ForeignKey("assets.id", ondelete="SET NULL"), nullable=True)
    assigned_user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    assigned_role = Column(String(50))
    due_date = Column(DateTime, nullable=False, index=True)
    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    status = Column(SAEnum(TaskStatus), default=TaskStatus.ASSIGNED, index=True)
    checklist_results = Column(JSON, default=list)
    # [{"step_index": 0, "section_index": 0, "value": "...", "photo_url": "..."}]
    materials_used = Column(JSON, default=list)
    # [{"name": "...", "qty": 1, "unit": "pcs"}]
    notes = Column(Text)
    is_escalated = Column(Boolean, default=False)
    escalated_wo_id = Column(UUID(as_uuid=True), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (
        Index("ix_tasks_user_date", "assigned_user_id", "due_date"),
        Index("ix_tasks_building_date", "building_id", "due_date"),
    )


# ─────────────────────────────────────────────────────────────
# TIER 6: WORK ORDERS
# ─────────────────────────────────────────────────────────────

class WorkOrder(Base):
    __tablename__ = "work_orders"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=False, index=True)
    building_id = Column(UUID(as_uuid=True), ForeignKey("buildings.id", ondelete="CASCADE"), nullable=False, index=True)
    wo_number = Column(String(50), unique=True, index=True)
    title = Column(String(255), nullable=False)
    description = Column(Text)
    wo_type = Column(String(50), default="corrective")  # corrective/preventive/emergency/escalation
    category = Column(String(100))
    priority = Column(SAEnum(WOPriority), default=WOPriority.MEDIUM, index=True)
    status = Column(SAEnum(WOStatus), default=WOStatus.OPEN, index=True)
    asset_id = Column(UUID(as_uuid=True), ForeignKey("assets.id", ondelete="SET NULL"), nullable=True)
    assigned_to_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    created_by_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    approved_by_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    floor = Column(String(50))
    location = Column(String(255))
    due_date = Column(DateTime)
    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    checklist_steps = Column(JSON, default=list)
    checklist_results = Column(JSON, default=list)
    materials_used = Column(JSON, default=list)
    photos = Column(JSON, default=list)
    source_type = Column(String(50))  # manual/alarm/task_overdue/tenant
    source_id = Column(UUID(as_uuid=True))
    approval_notes = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (
        Index("ix_wo_company_building", "company_id", "building_id"),
    )


# ─────────────────────────────────────────────────────────────
# TIER 7: MATERIALS
# ─────────────────────────────────────────────────────────────

class Material(Base):
    __tablename__ = "materials"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=False, index=True)
    building_id = Column(UUID(as_uuid=True), ForeignKey("buildings.id", ondelete="CASCADE"), nullable=False, index=True)
    code = Column(String(100), index=True)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    category = Column(String(100))
    unit = Column(String(50), nullable=False)
    current_stock = Column(Float, default=0)
    min_stock_threshold = Column(Float, default=5)
    location = Column(String(255))
    price_per_unit = Column(Float, default=0)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class MaterialTransaction(Base):
    __tablename__ = "material_transactions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=False)
    building_id = Column(UUID(as_uuid=True), ForeignKey("buildings.id"), nullable=False)
    material_id = Column(UUID(as_uuid=True), ForeignKey("materials.id", ondelete="CASCADE"), nullable=False, index=True)
    transaction_type = Column(SAEnum(TransactionType), nullable=False)
    quantity = Column(Float, nullable=False)
    reference_type = Column(String(50))   # task / work_order / manual
    reference_id = Column(UUID(as_uuid=True))
    performed_by_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    notes = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)


class MaterialRequest(Base):
    __tablename__ = "material_requests"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=False, index=True)
    building_id = Column(UUID(as_uuid=True), ForeignKey("buildings.id", ondelete="CASCADE"), nullable=False, index=True)
    requested_by_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    material_name = Column(String(255), nullable=False)
    quantity = Column(Float, nullable=False)
    unit = Column(String(50), nullable=False)
    reason = Column(Text)
    status = Column(String(30), default="pending", index=True)
    # pending / approved_by_spv / rejected / fulfilled
    approved_by_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    fulfilled_by_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    notes = Column(Text)
    reference_type = Column(String(50))
    reference_id = Column(UUID(as_uuid=True))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


# ─────────────────────────────────────────────────────────────
# TIER 8: METERS & BILLING
# ─────────────────────────────────────────────────────────────

class Meter(Base):
    __tablename__ = "meters"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=False, index=True)
    building_id = Column(UUID(as_uuid=True), ForeignKey("buildings.id", ondelete="CASCADE"), nullable=False, index=True)
    meter_number = Column(String(100), nullable=False)
    meter_type = Column(SAEnum(MeterType), nullable=False)
    unit = Column(String(20), nullable=False)   # kWh / m3
    multiplier = Column(Float, default=1.0)
    floor = Column(String(50))
    location = Column(String(255))
    tenant_name = Column(String(255))
    tenant_id = Column(UUID(as_uuid=True), nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint("building_id", "meter_number", name="uq_meter_building_number"),
    )


class MeterReading(Base):
    __tablename__ = "meter_readings"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=False)
    meter_id = Column(UUID(as_uuid=True), ForeignKey("meters.id", ondelete="CASCADE"), nullable=False, index=True)
    reading_value = Column(Float, nullable=False)
    reading_date = Column(DateTime, nullable=False, index=True)
    source = Column(String(50), default="manual")   # manual / checklist / iot
    recorded_by_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    task_instance_id = Column(UUID(as_uuid=True), ForeignKey("task_instances.id"), nullable=True)
    photo_url = Column(String(500))
    notes = Column(String(500))
    created_at = Column(DateTime, default=datetime.utcnow)


class TariffConfig(Base):
    __tablename__ = "tariff_configs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=False)
    building_id = Column(UUID(as_uuid=True), ForeignKey("buildings.id", ondelete="CASCADE"), nullable=False)
    meter_type = Column(SAEnum(MeterType), nullable=False)
    rate_per_unit = Column(Float, nullable=False)
    admin_fee = Column(Float, default=0)
    ppn_percent = Column(Float, default=11.0)
    is_active = Column(Boolean, default=True)
    effective_from = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)


class Invoice(Base):
    __tablename__ = "invoices"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=False, index=True)
    building_id = Column(UUID(as_uuid=True), ForeignKey("buildings.id"), nullable=False, index=True)
    invoice_number = Column(String(100), unique=True)
    tenant_name = Column(String(255))
    period_start = Column(DateTime, nullable=False)
    period_end = Column(DateTime, nullable=False)
    subtotal = Column(Float, default=0)
    admin_fee = Column(Float, default=0)
    ppn_amount = Column(Float, default=0)
    total_amount = Column(Float, default=0)
    status = Column(SAEnum(InvoiceStatus), default=InvoiceStatus.DRAFT)
    line_items = Column(JSON, default=list)
    notes = Column(Text)
    issued_at = Column(DateTime)
    paid_at = Column(DateTime)
    created_by_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(DateTime, default=datetime.utcnow)


# ─────────────────────────────────────────────────────────────
# TIER 9: VISITOR MANAGEMENT (TRO)
# ─────────────────────────────────────────────────────────────

class Visitor(Base):
    __tablename__ = "visitors"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=False)
    building_id = Column(UUID(as_uuid=True), ForeignKey("buildings.id", ondelete="CASCADE"), nullable=False, index=True)
    full_name = Column(String(255), nullable=False)
    id_type = Column(String(50), default="KTP")
    id_number = Column(String(100))
    phone = Column(String(50))
    email = Column(String(255))
    photo_url = Column(String(500))
    is_vip = Column(Boolean, default=False)
    plate_number = Column(String(50), index=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class Visit(Base):
    __tablename__ = "visits"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=False)
    building_id = Column(UUID(as_uuid=True), ForeignKey("buildings.id", ondelete="CASCADE"), nullable=False, index=True)
    visitor_id = Column(UUID(as_uuid=True), ForeignKey("visitors.id", ondelete="CASCADE"), nullable=False, index=True)
    host_name = Column(String(255))
    host_tenant = Column(String(255))
    host_floor = Column(String(50))
    purpose = Column(String(255))
    qr_code_uuid = Column(String(255), unique=True, index=True)
    status = Column(SAEnum(VisitStatus), default=VisitStatus.SCHEDULED, index=True)
    scheduled_start = Column(DateTime)
    scheduled_end = Column(DateTime)
    actual_checkin = Column(DateTime)
    actual_checkout = Column(DateTime)
    plate_number = Column(String(50), index=True)
    registered_by_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    notes = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)


class AccessLog(Base):
    __tablename__ = "access_logs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=False)
    building_id = Column(UUID(as_uuid=True), ForeignKey("buildings.id"), nullable=False)
    visit_id = Column(UUID(as_uuid=True), ForeignKey("visits.id"), nullable=True, index=True)
    device_id = Column(String(100))
    event = Column(String(30), nullable=False)  # granted/denied/exit
    reason = Column(String(100))
    timestamp = Column(DateTime, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class ParkingEvent(Base):
    __tablename__ = "parking_events"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=True)
    building_id = Column(UUID(as_uuid=True), ForeignKey("buildings.id"), nullable=True, index=True)
    visit_id = Column(UUID(as_uuid=True), ForeignKey("visits.id"), nullable=True)
    gate_id = Column(String(100))
    plate_number = Column(String(50), index=True)
    entry_time = Column(DateTime)
    exit_time = Column(DateTime)
    is_validated = Column(Boolean, default=False)
    validated_by_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    ticket_number = Column(String(100))
    fee = Column(Float)
    created_at = Column(DateTime, default=datetime.utcnow)


# ─────────────────────────────────────────────────────────────
# TIER 10: ALARMS
# ─────────────────────────────────────────────────────────────

class Alarm(Base):
    __tablename__ = "alarms"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=False, index=True)
    building_id = Column(UUID(as_uuid=True), ForeignKey("buildings.id", ondelete="CASCADE"), nullable=False, index=True)
    alarm_type = Column(String(100), nullable=False)
    severity = Column(SAEnum(AlarmSeverity), nullable=False, index=True)
    title = Column(String(255), nullable=False)
    message = Column(Text)
    location = Column(String(255))
    floor = Column(String(50))
    device_id = Column(String(100))
    asset_id = Column(UUID(as_uuid=True), ForeignKey("assets.id", ondelete="SET NULL"), nullable=True)
    status = Column(SAEnum(AlarmStatus), default=AlarmStatus.ACTIVE, index=True)
    acked = Column(Boolean, default=False)
    acked_by_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    acked_at = Column(DateTime)
    resolved_at = Column(DateTime)
    source = Column(String(50), default="manual")   # iot/manual/system
    related_wo_id = Column(UUID(as_uuid=True), ForeignKey("work_orders.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (
        Index("ix_alarms_company_building_status", "company_id", "building_id", "status"),
    )


# ─────────────────────────────────────────────────────────────
# SAAS: SUBSCRIPTION PLANS & PAYMENTS
# ─────────────────────────────────────────────────────────────

class SubscriptionStatus(str, enum.Enum):
    TRIAL = "trial"
    ACTIVE = "active"
    PAST_DUE = "past_due"
    SUSPENDED = "suspended"
    CANCELLED = "cancelled"


class PaymentStatus(str, enum.Enum):
    PENDING = "pending"
    PAID = "paid"
    FAILED = "failed"
    EXPIRED = "expired"
    REFUNDED = "refunded"


class Subscription(Base):
    __tablename__ = "subscriptions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id", ondelete="CASCADE"),
                        nullable=False, unique=True, index=True)
    plan = Column(String(50), nullable=False, default="starter")
    # starter / professional / enterprise
    status = Column(SAEnum(SubscriptionStatus), default=SubscriptionStatus.TRIAL)
    trial_ends_at = Column(DateTime)
    current_period_start = Column(DateTime)
    current_period_end = Column(DateTime)
    max_buildings = Column(Integer, default=1)
    max_users = Column(Integer, default=10)
    max_assets = Column(Integer, default=100)
    price_per_month = Column(Integer, default=0)  # IDR
    cancelled_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class PaymentTransaction(Base):
    __tablename__ = "payment_transactions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=False, index=True)
    subscription_id = Column(UUID(as_uuid=True), ForeignKey("subscriptions.id"), nullable=True)
    # Duitku fields
    merchant_order_id = Column(String(100), unique=True, index=True)
    duitku_reference = Column(String(100), index=True)
    payment_url = Column(String(500))
    payment_method = Column(String(50))  # VA_BCA, VA_BNI, QRIS, etc.
    amount = Column(Integer, nullable=False)  # IDR
    plan = Column(String(50))
    plan_months = Column(Integer, default=1)
    status = Column(SAEnum(PaymentStatus), default=PaymentStatus.PENDING, index=True)
    description = Column(String(255))
    paid_at = Column(DateTime)
    expired_at = Column(DateTime)
    duitku_raw = Column(JSON, default=dict)  # raw callback payload
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
