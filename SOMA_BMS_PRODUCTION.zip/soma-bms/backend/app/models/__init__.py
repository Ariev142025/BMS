"""Import all models so Alembic can discover them."""
from app.core.database import Base  # noqa: F401
from app.models.models import (  # noqa: F401
    Company, Building,
    User, Shift, ShiftAssignment,
    Asset,
    ChecklistTemplate,
    ScheduleRule, TaskInstance,
    WorkOrder,
    Material, MaterialTransaction, MaterialRequest,
    Meter, MeterReading, TariffConfig, Invoice,
    Visitor, Visit, AccessLog, ParkingEvent,
    Alarm,
    # Enums
    UserRole, WOStatus, WOPriority, TaskStatus,
    AlarmSeverity, AlarmStatus, VisitStatus,
    MeterType, TransactionType, InvoiceStatus,
)
from app.models.models import (  # noqa: F401
    Subscription, SubscriptionStatus,
    PaymentTransaction, PaymentStatus,
)
