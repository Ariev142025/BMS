"""
SOMA BMS — Complete Seed Data
Creates: Company → Buildings → Users → Assets → Templates → Schedules → Materials → Meters → Tariffs

Run: python -m app.seed
"""
import asyncio
import uuid
from datetime import datetime, date, time, timedelta

from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import engine, Base, AsyncSessionLocal
from app.core.security import get_password_hash
from app.models.models import (
    Company, Building, User, UserRole, Shift, ShiftAssignment,
    Asset, ChecklistTemplate, ScheduleRule,
    Material, Meter, MeterType, TariffConfig,
    Alarm, AlarmSeverity,
)

# Fixed UUIDs for reproducible seed data
COMPANY_ID = uuid.UUID("aaaaaaaa-0000-0000-0000-000000000001")
BUILDING_1_ID = uuid.UUID("bbbbbbbb-0000-0000-0000-000000000001")
BUILDING_2_ID = uuid.UUID("bbbbbbbb-0000-0000-0000-000000000002")

USER_IDS = {
    "super_admin":    uuid.UUID("cccccccc-0000-0000-0000-000000000001"),
    "company_admin":  uuid.UUID("cccccccc-0000-0000-0000-000000000002"),
    "building_admin": uuid.UUID("cccccccc-0000-0000-0000-000000000003"),
    "tro":            uuid.UUID("cccccccc-0000-0000-0000-000000000004"),
    "spv_teknisi":    uuid.UUID("cccccccc-0000-0000-0000-000000000005"),
    "teknisi1":       uuid.UUID("cccccccc-0000-0000-0000-000000000006"),
    "teknisi2":       uuid.UUID("cccccccc-0000-0000-0000-000000000007"),
    "spv_hk":         uuid.UUID("cccccccc-0000-0000-0000-000000000008"),
    "hk1":            uuid.UUID("cccccccc-0000-0000-0000-000000000009"),
    "hk2":            uuid.UUID("cccccccc-0000-0000-0000-000000000010"),
}


async def seed():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    print("✅ Tables created")

    async with AsyncSessionLocal() as db:
        try:
            # Idempotency: skip if already seeded
            from sqlalchemy import select
            existing = await db.execute(select(Company).where(Company.id == COMPANY_ID))
            if existing.scalar_one_or_none():
                print("⏭️  Data demo sudah ada. Seed dilewati.")
                print("   Hapus data dulu dengan DROP DATABASE jika ingin reset.")
                _print_credentials()
                return
            await _seed_all(db)
            await db.commit()
            print("\n🎉 Seed selesai! Semua data demo berhasil dibuat.")
            _print_credentials()
        except Exception as e:
            await db.rollback()
            print(f"❌ Seed error: {e}")
            raise


async def _seed_all(db: AsyncSession):
    # ── Company ──────────────────────────────────────────────
    company = Company(
        id=COMPANY_ID,
        name="PT Gedung Properti Indonesia",
        email="admin@properti.co.id",
        phone="021-12345678",
        address="Jl. Sudirman No. 1, Jakarta Selatan",
        subscription_plan="professional",
        is_active=True,
    )
    db.add(company)
    await db.flush()

    # ── Buildings ────────────────────────────────────────────
    building1 = Building(
        id=BUILDING_1_ID,
        company_id=COMPANY_ID,
        name="Gedung Lot 4 SCBD",
        address="SCBD Lot 4, Jl. Jenderal Sudirman, Jakarta",
        city="Jakarta",
        floors_count=20,
        total_area_m2=25000.0,
        contact_name="Ahmad Wijaya",
        contact_phone="0812-3456-7890",
        is_active=True,
    )
    building2 = Building(
        id=BUILDING_2_ID,
        company_id=COMPANY_ID,
        name="Gedung Kuningan City",
        address="Jl. Prof. DR. Satrio, Jakarta Selatan",
        city="Jakarta",
        floors_count=15,
        total_area_m2=18000.0,
        contact_name="Budi Santoso",
        contact_phone="0813-9876-5432",
        is_active=True,
    )
    db.add_all([building1, building2])
    await db.flush()

    # ── Users ────────────────────────────────────────────────
    users_data = [
        # (id_key, email, full_name, role, building_id, skill)
        ("super_admin",    "superadmin@somabms.com",      "Super Admin SOMA",           UserRole.SUPER_ADMIN,        None,           None),
        ("company_admin",  "companya@properti.co.id",     "Direktur Operasional",       UserRole.COMPANY_ADMIN,      None,           None),
        ("building_admin", "admin@gedung.com",             "Ahmad Wijaya (Admin)",       UserRole.BUILDING_ADMIN,     BUILDING_1_ID,  None),
        ("tro",            "tro@gedung.com",               "Siti Rahayu (TRO)",          UserRole.TRO,                BUILDING_1_ID,  None),
        ("spv_teknisi",    "spv.teknisi@gedung.com",       "Budi Santoso (SPV)",         UserRole.SPV_TEKNISI,        BUILDING_1_ID,  "HVAC,Elektrikal"),
        ("teknisi1",       "teknisi1@gedung.com",          "Andi Prasetyo (Teknisi)",    UserRole.TEKNISI,            BUILDING_1_ID,  "HVAC"),
        ("teknisi2",       "teknisi2@gedung.com",          "Rudi Hermawan (Teknisi)",    UserRole.TEKNISI,            BUILDING_1_ID,  "Elektrikal,Plumbing"),
        ("spv_hk",         "spv.hk@gedung.com",            "Ratna Dewi (SPV HK)",        UserRole.SPV_HOUSEKEEPING,   BUILDING_1_ID,  None),
        ("hk1",            "hk1@gedung.com",               "Sari Indah (HK)",            UserRole.HOUSEKEEPING,       BUILDING_1_ID,  None),
        ("hk2",            "hk2@gedung.com",               "Dewi Lestari (HK)",          UserRole.HOUSEKEEPING,       BUILDING_1_ID,  None),
    ]
    for key, email, name, role, bld, skill in users_data:
        user = User(
            id=USER_IDS[key],
            company_id=COMPANY_ID,
            building_id=bld,
            email=email,
            hashed_password=get_password_hash("Demo123!"),
            full_name=name,
            role=role,
            skill_category=skill,
            is_active=True,
        )
        db.add(user)

    # ── Shifts ───────────────────────────────────────────────
    shift_pagi = Shift(company_id=COMPANY_ID, building_id=BUILDING_1_ID, name="Shift Pagi", start_time=time(6, 0), end_time=time(14, 0))
    shift_siang = Shift(company_id=COMPANY_ID, building_id=BUILDING_1_ID, name="Shift Siang", start_time=time(14, 0), end_time=time(22, 0))
    db.add_all([shift_pagi, shift_siang])
    await db.flush()

    # Assign shifts for this week
    today = date.today()
    for i in range(7):
        d = today + timedelta(days=i - today.weekday())
        db.add(ShiftAssignment(
            company_id=COMPANY_ID, building_id=BUILDING_1_ID,
            user_id=USER_IDS["teknisi1"], shift_id=shift_pagi.id, assignment_date=d,
        ))
        db.add(ShiftAssignment(
            company_id=COMPANY_ID, building_id=BUILDING_1_ID,
            user_id=USER_IDS["hk1"], shift_id=shift_pagi.id, assignment_date=d,
        ))

    # ── Assets ───────────────────────────────────────────────
    assets_raw = [
        # (code, cat, sub, name, floor, loc, brand, model)
        ("AC-LT5-T1-01", "HVAC", "AC Indoor", "AC Indoor Lt.5 Tenant 1 Unit-1", "5", "Ruang Tenant 1 Lt.5", "MITSUBISHI", "FDU140KXE6F"),
        ("AC-LT5-T1-02", "HVAC", "AC Indoor", "AC Indoor Lt.5 Tenant 1 Unit-2", "5", "Ruang Tenant 1 Lt.5", "MITSUBISHI", "FDU140KXE6F"),
        ("AC-LT2-T1-01", "HVAC", "AC Indoor", "AC Indoor Lt.2 Tenant 1", "2", "Ruang Tenant 1 Lt.2", "MITSUBISHI", "FDUM90KXE6F"),
        ("AC-LT3-01",    "HVAC", "AC Indoor", "AC Indoor Lt.3 Koridor", "3", "Koridor Lt.3", "DAIKIN", "FDQ100C"),
        ("AC-OD-RF-01",  "HVAC", "AC Outdoor", "AC Outdoor Rooftop Unit-1", "RF", "Rooftop", "MITSUBISHI", "FDC400KXZE1"),
        ("EF-TOL-LT2-P", "HVAC", "Exhaust Fan", "Exhaust Fan Toilet Pria Lt.2", "2", "Toilet Pria Lt.2", "PANASONIC", "FV-20TH2"),
        ("EF-TOL-LT2-W", "HVAC", "Exhaust Fan", "Exhaust Fan Toilet Wanita Lt.2", "2", "Toilet Wanita Lt.2", "PANASONIC", "FV-20TH2"),
        ("GENSET-B1-01", "Elektrikal", "Genset", "Genset Cummins B1", "B1", "Ruang Genset", "CUMMINS", "GLTAA8.9-62"),
        ("PANEL-GF-01",  "Elektrikal", "Panel Listrik", "Main Panel GF", "GF", "Ruang Panel Utama GF", "SCHNEIDER", "XL3 400"),
        ("PANEL-LT2-01", "Elektrikal", "Panel Listrik", "Sub-Panel Lt.2", "2", "Ruang Panel Lt.2", "SCHNEIDER", "DM1"),
        ("PANEL-LT5-01", "Elektrikal", "Panel Listrik", "Sub-Panel Lt.5", "5", "Ruang Panel Lt.5", "SCHNEIDER", "DM1"),
        ("CCTV-LB-01",   "Elektrikal", "CCTV", "Kamera CCTV Lobi GF-1", "GF", "Lobi Utama GF", "HIKVISION", "DS-2CD2047G2"),
        ("CCTV-LB-02",   "Elektrikal", "CCTV", "Kamera CCTV Lobi GF-2", "GF", "Lobi Utama GF", "HIKVISION", "DS-2CD2047G2"),
        ("POMPA-B1-01",  "Plumbing", "Pompa Air", "Pompa Transfer Tower A", "B1", "Ruang Pompa B1", "EBARA", "FSHA2-32"),
        ("POMPA-B1-02",  "Plumbing", "Pompa Air", "Pompa Transfer Tower B", "B1", "Ruang Pompa B1", "EBARA", "FSHA2-32"),
        ("APAR-GF-01",   "Fire Fighting", "APAR", "APAR CO2 Lobi GF Pos 1", "GF", "Lobi Utama GF (Kiri)", "YAMATO", "CO2-5KG"),
        ("APAR-GF-02",   "Fire Fighting", "APAR", "APAR CO2 Lobi GF Pos 2", "GF", "Lobi Utama GF (Kanan)", "YAMATO", "CO2-5KG"),
        ("APAR-LT2-01",  "Fire Fighting", "APAR", "APAR CO2 Lt.2 Koridor", "2", "Koridor Lt.2", "YAMATO", "CO2-5KG"),
        ("APAR-LT5-01",  "Fire Fighting", "APAR", "APAR CO2 Lt.5 Koridor", "5", "Koridor Lt.5", "YAMATO", "CO2-5KG"),
        ("HYDRANT-GF-01","Fire Fighting", "Hydrant", "Hydrant Box Lobi GF", "GF", "Lobi GF Pos 1", "APPRON", "HB-25"),
        ("LIFT-01",      "Transportasi", "Lift", "Lift Passenger Unit-1", "ALL", "Shaft Utama", "OTIS", "Gen2"),
        ("LIFT-02",      "Transportasi", "Lift", "Lift Passenger Unit-2", "ALL", "Shaft Utama", "OTIS", "Gen2"),
    ]
    asset_map = {}
    for code, cat, sub, name, floor, loc, brand, model in assets_raw:
        a = Asset(
            company_id=COMPANY_ID, building_id=BUILDING_1_ID,
            asset_code=code, category=cat, sub_category=sub, name=name,
            floor=floor, location=loc, brand=brand, model=model,
            condition="good", installation_date=datetime(2018, 3, 15),
        )
        db.add(a)
        asset_map[code] = a
    await db.flush()

    # ── Templates ────────────────────────────────────────────
    # 1. PM AC Bulanan
    tpl_ac_bulanan = ChecklistTemplate(
        company_id=COMPANY_ID, building_id=BUILDING_1_ID,
        name="PM AC Indoor Bulanan", template_type="maintenance",
        category="HVAC", sub_category="AC Indoor",
        estimated_duration_minutes=30,
        sections=[
            {"title": "PERSIAPAN & KESELAMATAN", "steps": [
                {"instruction": "Matikan unit AC sebelum membuka panel", "input_type": "checkbox", "options": ["Sudah dimatikan"], "required": True, "require_photo": False},
                {"instruction": "Gunakan APD: sarung tangan + masker", "input_type": "checkbox", "options": ["APD sudah dipakai"], "required": True, "require_photo": True},
            ]},
            {"title": "PEMERIKSAAN FILTER UDARA", "steps": [
                {"instruction": "Buka panel dan ambil foto filter BEFORE", "input_type": "photo", "required": True, "require_photo": True},
                {"instruction": "Kondisi filter?", "input_type": "radio", "options": ["Bersih (lanjut step 6)", "Kotor - cuci", "Rusak - ganti"], "required": True},
                {"instruction": "Cuci filter dengan air bersih (jika kotor)", "input_type": "checkbox", "options": ["Filter sudah dicuci dan dikeringkan"], "required": False},
                {"instruction": "Foto filter AFTER pemasangan kembali", "input_type": "photo", "required": True},
            ]},
            {"title": "CEK DRAINASE & EVAPORATOR", "steps": [
                {"instruction": "Cek saluran drainase - tidak tersumbat", "input_type": "radio", "options": ["Lancar", "Tersumbat - sudah dibersihkan"], "required": True},
                {"instruction": "Kondisi evaporator coil", "input_type": "radio", "options": ["Bersih", "Berdebu ringan - disemprot", "Kotor berat - chemical wash"], "required": True, "require_photo": True},
            ]},
            {"title": "CEK OPERASIONAL", "steps": [
                {"instruction": "Nyalakan unit dan tunggu 3 menit", "input_type": "checkbox", "options": ["Unit menyala normal"], "required": True},
                {"instruction": "Ukur suhu supply (°C)", "input_type": "numeric", "unit": "°C", "min_value": 5.0, "max_value": 25.0, "required": True},
                {"instruction": "Ukur suhu return (°C)", "input_type": "numeric", "unit": "°C", "min_value": 20.0, "max_value": 35.0, "required": True},
                {"instruction": "Cek suara abnormal (bising, getaran)", "input_type": "radio", "options": ["Normal - tidak ada suara aneh", "Ada suara aneh (catat di notes)"], "required": True},
                {"instruction": "Bersihkan area sekitar unit", "input_type": "checkbox", "options": ["Area sudah dibersihkan"], "required": True, "require_photo": True},
            ]},
        ],
        default_materials=[
            {"name": "Filter Panel MERV8 24x24", "unit": "pcs", "default_qty": 2},
        ],
        version=1,
    )
    db.add(tpl_ac_bulanan)

    # 2. Checklist kWh Harian
    tpl_kwh = ChecklistTemplate(
        company_id=COMPANY_ID, building_id=BUILDING_1_ID,
        name="Checklist Pencatatan Meter Harian", template_type="checklist",
        category="Elektrikal", sub_category="Meter Utilitas",
        estimated_duration_minutes=15,
        sections=[
            {"title": "PENCATATAN METER LISTRIK", "steps": [
                {"instruction": "Foto angka meter listrik Tenant 1 Lt.2", "input_type": "photo", "required": True},
                {"instruction": "Catat angka meter listrik Tenant 1 Lt.2 (kWh)", "input_type": "numeric", "unit": "kWh", "required": True, "meter_number": "MTR-ELEC-T1-L2", "meter_type": "electricity"},
                {"instruction": "Foto angka meter listrik Tenant 1 Lt.5", "input_type": "photo", "required": True},
                {"instruction": "Catat angka meter listrik Tenant 1 Lt.5 (kWh)", "input_type": "numeric", "unit": "kWh", "required": True, "meter_number": "MTR-ELEC-T1-L5", "meter_type": "electricity"},
                {"instruction": "Foto angka meter air Tenant 1", "input_type": "photo", "required": True},
                {"instruction": "Catat angka meter air Tenant 1 (m³)", "input_type": "numeric", "unit": "m³", "required": True, "meter_number": "MTR-WATER-T1", "meter_type": "water"},
            ]},
        ],
        version=1,
    )
    db.add(tpl_kwh)

    # 3. Cek Genset Mingguan
    tpl_genset = ChecklistTemplate(
        company_id=COMPANY_ID, building_id=BUILDING_1_ID,
        name="PM Genset Weekly Start Test", template_type="maintenance",
        category="Elektrikal", sub_category="Genset",
        estimated_duration_minutes=45,
        sections=[
            {"title": "PEMERIKSAAN AWAL", "steps": [
                {"instruction": "Cek level solar (harus ≥ 50%)", "input_type": "radio", "options": ["≥50% OK", "<50% - ISI SOLAR SEGERA"], "required": True, "require_photo": True},
                {"instruction": "Cek level oli mesin (antara L dan H)", "input_type": "radio", "options": ["Normal antara L-H", "Di bawah L - tambah oli"], "required": True},
                {"instruction": "Cek level air radiator", "input_type": "radio", "options": ["Penuh OK", "Kurang - sudah ditambah"], "required": True},
                {"instruction": "Cek tegangan aki (target 12.5-13.2V)", "input_type": "numeric", "unit": "V", "min_value": 11.0, "max_value": 15.0, "required": True},
            ]},
            {"title": "START TEST & OPERASIONAL", "steps": [
                {"instruction": "Start engine genset", "input_type": "radio", "options": ["Engine menyala normal", "Gagal start - buat WO"], "required": True},
                {"instruction": "Biarkan idle 2 menit, catat tekanan oli (psi)", "input_type": "numeric", "unit": "psi", "min_value": 20.0, "max_value": 80.0, "required": True},
                {"instruction": "Cek frekuensi output (target 50 Hz)", "input_type": "numeric", "unit": "Hz", "min_value": 49.0, "max_value": 51.0, "required": True},
                {"instruction": "Cek voltase output (target 380V)", "input_type": "numeric", "unit": "V", "min_value": 370.0, "max_value": 400.0, "required": True},
                {"instruction": "Foto panel instrumen genset", "input_type": "photo", "required": True},
                {"instruction": "Matikan engine dan kembalikan posisi AUTO", "input_type": "checkbox", "options": ["Engine mati, posisi AUTO OK"], "required": True},
            ]},
            {"title": "KEBERSIHAN AREA", "steps": [
                {"instruction": "Cek kebocoran oli/solar di sekitar genset", "input_type": "radio", "options": ["Tidak ada kebocoran", "Ada kebocoran - buat WO"], "required": True, "require_photo": True},
                {"instruction": "Bersihkan area ruang genset", "input_type": "checkbox", "options": ["Area sudah dibersihkan"], "required": True},
            ]},
        ],
        version=1,
    )
    db.add(tpl_genset)

    # 4. Checklist Kebersihan Toilet Harian (HK)
    tpl_hk_toilet = ChecklistTemplate(
        company_id=COMPANY_ID, building_id=BUILDING_1_ID,
        name="Checklist Kebersihan Toilet Harian", template_type="checklist",
        category="Housekeeping", sub_category="Toilet",
        estimated_duration_minutes=20,
        sections=[
            {"title": "PEMBERSIHAN TOILET", "steps": [
                {"instruction": "Foto BEFORE kondisi toilet", "input_type": "photo", "required": True},
                {"instruction": "Sapu lantai dan buang sampah", "input_type": "checkbox", "options": ["Selesai"], "required": True},
                {"instruction": "Pel lantai dengan cairan disinfektan", "input_type": "checkbox", "options": ["Selesai"], "required": True},
                {"instruction": "Bersihkan cermin dan wastafel", "input_type": "checkbox", "options": ["Selesai"], "required": True},
                {"instruction": "Bersihkan kloset/urinal", "input_type": "checkbox", "options": ["Selesai"], "required": True},
                {"instruction": "Cek & isi ulang sabun cuci tangan", "input_type": "radio", "options": ["Sudah diisi", "Masih cukup (tidak perlu isi)"], "required": True},
                {"instruction": "Cek & isi ulang tisu toilet", "input_type": "radio", "options": ["Sudah diisi", "Masih cukup", "Stok habis - request material"], "required": True},
                {"instruction": "Kosongkan tempat sampah", "input_type": "checkbox", "options": ["Selesai"], "required": True},
                {"instruction": "Semprot pengharum ruangan", "input_type": "checkbox", "options": ["Selesai"], "required": False},
                {"instruction": "Foto AFTER kondisi toilet", "input_type": "photo", "required": True},
            ]},
        ],
        default_materials=[
            {"name": "Sabun Cair 500ml", "unit": "botol", "default_qty": 1},
            {"name": "Tisu Toilet Roll", "unit": "roll", "default_qty": 2},
        ],
        version=1,
    )
    db.add(tpl_hk_toilet)

    # 5. Cek APAR Bulanan
    tpl_apar = ChecklistTemplate(
        company_id=COMPANY_ID, building_id=BUILDING_1_ID,
        name="Inspeksi APAR Bulanan", template_type="checklist",
        category="Fire Fighting", sub_category="APAR",
        estimated_duration_minutes=10,
        sections=[
            {"title": "INSPEKSI APAR", "steps": [
                {"instruction": "Posisi APAR (harus pada bracket/gantungan)", "input_type": "radio", "options": ["Pada posisi", "Tidak pada posisi - perbaiki"], "required": True},
                {"instruction": "Indikator tekanan (jarum harus di area HIJAU)", "input_type": "radio", "options": ["Hijau (Normal)", "Merah/Kuning (Tidak normal) - buat WO"], "required": True, "require_photo": True},
                {"instruction": "Kondisi segel/pin pengaman", "input_type": "radio", "options": ["Segel utuh", "Segel rusak/hilang - buat WO"], "required": True},
                {"instruction": "Kondisi fisik tabung (tidak penyok/berkarat)", "input_type": "radio", "options": ["Kondisi baik", "Ada kerusakan - buat WO"], "required": True},
                {"instruction": "Tanggal expired (isi tanggal yang tertera)", "input_type": "text", "required": True},
                {"instruction": "Kondisi label/sticker instruksi", "input_type": "radio", "options": ["Label terbaca jelas", "Label rusak/tidak terbaca"], "required": True},
            ]},
        ],
        version=1,
    )
    db.add(tpl_apar)
    await db.flush()

    # ── Schedule Rules ───────────────────────────────────────
    rules = [
        ScheduleRule(
            company_id=COMPANY_ID, building_id=BUILDING_1_ID,
            name="Pencatatan Meter Harian (Teknisi)",
            template_id=tpl_kwh.id,
            asset_ids=[],
            recurrence_pattern={"freq": "daily", "time": "07:30"},
            assigned_role="teknisi",
            is_active=True,
        ),
        ScheduleRule(
            company_id=COMPANY_ID, building_id=BUILDING_1_ID,
            name="Kebersihan Toilet Pagi Harian (HK)",
            template_id=tpl_hk_toilet.id,
            asset_ids=[],
            recurrence_pattern={"freq": "daily", "time": "07:00"},
            assigned_role="housekeeping",
            is_active=True,
        ),
        ScheduleRule(
            company_id=COMPANY_ID, building_id=BUILDING_1_ID,
            name="PM AC Indoor Bulanan",
            template_id=tpl_ac_bulanan.id,
            asset_ids=[str(asset_map["AC-LT5-T1-01"].id), str(asset_map["AC-LT5-T1-02"].id), str(asset_map["AC-LT2-T1-01"].id)],
            recurrence_pattern={"freq": "monthly", "day": 1, "time": "09:00"},
            assigned_role="teknisi",
            is_active=True,
        ),
        ScheduleRule(
            company_id=COMPANY_ID, building_id=BUILDING_1_ID,
            name="Start Test Genset Mingguan",
            template_id=tpl_genset.id,
            asset_ids=[str(asset_map["GENSET-B1-01"].id)],
            recurrence_pattern={"freq": "weekly", "days": ["monday"], "time": "09:00"},
            assigned_role="teknisi",
            is_active=True,
        ),
        ScheduleRule(
            company_id=COMPANY_ID, building_id=BUILDING_1_ID,
            name="Inspeksi APAR Bulanan",
            template_id=tpl_apar.id,
            asset_ids=[str(a.id) for code, a in asset_map.items() if "APAR" in code],
            recurrence_pattern={"freq": "monthly", "day": 5, "time": "10:00"},
            assigned_role="teknisi",
            is_active=True,
        ),
    ]
    for r in rules:
        db.add(r)

    # ── Materials ────────────────────────────────────────────
    materials_data = [
        ("FILT-MERV8-2424", "Filter Panel MERV8 24x24", "Filter HVAC", "pcs", 20, 5, 85000),
        ("FILT-MERV8-2020", "Filter Panel MERV8 20x20", "Filter HVAC", "pcs", 15, 5, 65000),
        ("REF-R410A",       "Refrigeran R-410A",         "Refrigeran",  "kg",  10, 3, 350000),
        ("OLI-SAE15W40",    "Oli Mesin SAE 15W-40 (5L)", "Oli",         "liter",20, 5, 145000),
        ("FILT-OLI-CUMM",   "Filter Oli Cummins LF9009", "Filter",      "pcs",  8, 3, 250000),
        ("FILT-SOLAR",      "Filter Solar Fleetguard",   "Filter",      "pcs",  8, 3, 185000),
        ("SABUN-500ML",     "Sabun Cair 500ml",          "HK Supply",   "botol",40,15, 18500),
        ("TISU-TOILET",     "Tisu Toilet Roll",          "HK Supply",   "roll", 80,30, 4500),
        ("TISU-TISYU-BOX",  "Tisu Facial Box",           "HK Supply",   "box",  25,10, 22000),
        ("CAIRAN-LANTAI",   "Cairan Pel Lantai 1L",      "HK Supply",   "liter",15, 5, 35000),
        ("DISINFECT-1L",    "Cairan Disinfektan 1L",     "HK Supply",   "liter",10, 3, 55000),
        ("WIPER-GLASS",     "Cairan Pembersih Kaca 500ml","HK Supply",  "botol",10, 3, 28000),
        ("BOLA-LAMPU-LED",  "Lampu LED 18W",             "Elektrikal",  "pcs",  30,10, 45000),
        ("KABEL-NYA-2.5",   "Kabel NYA 2.5mm² (50m)",   "Elektrikal",  "roll",  5, 2, 285000),
    ]
    for code, name, cat, unit, stock, min_s, price in materials_data:
        db.add(Material(
            company_id=COMPANY_ID, building_id=BUILDING_1_ID,
            code=code, name=name, category=cat, unit=unit,
            current_stock=stock, min_stock_threshold=min_s, price_per_unit=price,
        ))

    # ── Meters ───────────────────────────────────────────────
    meters_data = [
        ("MTR-ELEC-T1-L2", MeterType.ELECTRICITY, "kWh", "2",  "Tenant 1 Lt.2"),
        ("MTR-ELEC-T1-L5", MeterType.ELECTRICITY, "kWh", "5",  "Tenant 1 Lt.5"),
        ("MTR-ELEC-T2-L3", MeterType.ELECTRICITY, "kWh", "3",  "Tenant 2 Lt.3"),
        ("MTR-WATER-T1",   MeterType.WATER,        "m3",  "B1", "Tenant 1 (semua lantai)"),
        ("MTR-WATER-T2",   MeterType.WATER,        "m3",  "B1", "Tenant 2 (semua lantai)"),
    ]
    for meter_num, mtype, unit, floor, tenant in meters_data:
        db.add(Meter(
            company_id=COMPANY_ID, building_id=BUILDING_1_ID,
            meter_number=meter_num, meter_type=mtype, unit=unit,
            floor=floor, tenant_name=tenant, multiplier=1.0,
        ))

    # ── Tariffs ──────────────────────────────────────────────
    db.add(TariffConfig(
        company_id=COMPANY_ID, building_id=BUILDING_1_ID,
        meter_type=MeterType.ELECTRICITY, rate_per_unit=1500.0,
        admin_fee=50000.0, ppn_percent=11.0, is_active=True,
    ))
    db.add(TariffConfig(
        company_id=COMPANY_ID, building_id=BUILDING_1_ID,
        meter_type=MeterType.WATER, rate_per_unit=6000.0,
        admin_fee=25000.0, ppn_percent=11.0, is_active=True,
    ))

    # ── Sample Alarms ────────────────────────────────────────
    db.add(Alarm(
        company_id=COMPANY_ID, building_id=BUILDING_1_ID,
        alarm_type="hvac_fault", severity=AlarmSeverity.WARNING,
        title="AC Indoor Lt.5 Unit-1 Filter Kotor",
        message="Parameter ΔT menurun, kemungkinan filter perlu dibersihkan",
        location="Lt.5 Ruang Tenant 1", floor="5",
        device_id="AC-LT5-T1-01", source="system",
        asset_id=asset_map["AC-LT5-T1-01"].id,
    ))
    db.add(Alarm(
        company_id=COMPANY_ID, building_id=BUILDING_1_ID,
        alarm_type="panel_fault", severity=AlarmSeverity.MAJOR,
        title="Sub-Panel Lt.5 Suhu Tinggi",
        message="Suhu terminal panel melebihi 60°C",
        location="Ruang Panel Lt.5", floor="5",
        source="iot",
        asset_id=asset_map["PANEL-LT5-01"].id,
    ))

    await db.flush()


def _print_credentials():
    print("\n" + "="*55)
    print("📋 SOMA BMS — Akun Demo (password: Demo123!)")
    print("="*55)
    creds = [
        ("Super Admin",        "superadmin@somabms.com"),
        ("Admin Gedung",       "admin@gedung.com"),
        ("TRO (Resepsionis)",  "tro@gedung.com"),
        ("SPV Teknisi",        "spv.teknisi@gedung.com"),
        ("Teknisi 1 (HVAC)",   "teknisi1@gedung.com"),
        ("Teknisi 2 (Listrik)","teknisi2@gedung.com"),
        ("SPV Housekeeping",   "spv.hk@gedung.com"),
        ("Housekeeping 1",     "hk1@gedung.com"),
        ("Housekeeping 2",     "hk2@gedung.com"),
    ]
    for role, email in creds:
        print(f"  {role:<25} {email}")
    print("="*55)
    print("\n🌐 Akses:")
    print("  Dashboard Web : http://localhost:3000")
    print("  Mobile App    : http://localhost:3000/mobile")
    print("  API Docs      : http://localhost:8000/docs")


if __name__ == "__main__":
    asyncio.run(seed())
