"""
SOMA BMS — SaaS Endpoints
- Public company registration
- Subscription management
- Duitku payment gateway
- Super admin panel
"""
import uuid
import hashlib
import httpx
import logging
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any

from fastapi import APIRouter, Depends, HTTPException, Request
from slowapi import Limiter
from slowapi.util import get_remote_address
limiter = Limiter(key_func=get_remote_address)
from pydantic import BaseModel, EmailStr
from sqlalchemy import select, func, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_password_hash, create_access_token
from app.models.models import (
    Company, Building, User, UserRole,
    Subscription, SubscriptionStatus,
    PaymentTransaction, PaymentStatus,
)
from app.api.deps import require_auth, require_role

logger = logging.getLogger(__name__)
router = APIRouter()

# ─────────────────────────────────────────────────────────────
# PLAN CATALOGUE
# ─────────────────────────────────────────────────────────────

PLANS: Dict[str, Dict] = {
    "starter": {
        "name": "Starter",
        "price_monthly": 299_000,
        "price_annual": 2_990_000,
        "max_buildings": 1,
        "max_users": 15,
        "max_assets": 150,
        "features": [
            "1 gedung",
            "15 pengguna",
            "150 aset",
            "Checklist & Work Order",
            "Mobile app teknisi/HK",
            "Laporan dasar",
        ],
        "highlight": False,
    },
    "professional": {
        "name": "Professional",
        "price_monthly": 799_000,
        "price_annual": 7_990_000,
        "max_buildings": 5,
        "max_users": 50,
        "max_assets": 1000,
        "features": [
            "5 gedung",
            "50 pengguna",
            "1.000 aset",
            "Semua fitur Starter",
            "Billing & invoice utilitas",
            "TRO & manajemen tamu",
            "Alarm & notifikasi",
            "Laporan lengkap",
        ],
        "highlight": True,
    },
    "enterprise": {
        "name": "Enterprise",
        "price_monthly": 1_999_000,
        "price_annual": 19_990_000,
        "max_buildings": 999,
        "max_users": 999,
        "max_assets": 99999,
        "features": [
            "Gedung tidak terbatas",
            "Pengguna tidak terbatas",
            "Aset tidak terbatas",
            "Semua fitur Professional",
            "API integrasi",
            "Custom branding",
            "Dedicated support",
            "SLA 99.9%",
        ],
        "highlight": False,
    },
}

TRIAL_DAYS = 14

# ─────────────────────────────────────────────────────────────
# DUITKU CONFIG (env-based, fallback to sandbox)
# ─────────────────────────────────────────────────────────────
import os
DUITKU_MERCHANT_CODE = os.getenv("DUITKU_MERCHANT_CODE", "DS14678")
DUITKU_API_KEY       = os.getenv("DUITKU_API_KEY",       "your-duitku-api-key")
DUITKU_BASE_URL      = os.getenv("DUITKU_BASE_URL",      "https://sandbox.duitku.com/webapi/api")
DUITKU_CALLBACK_URL  = os.getenv("DUITKU_CALLBACK_URL",  "http://localhost:8000/api/v1/saas/payment/callback")
DUITKU_RETURN_URL    = os.getenv("DUITKU_RETURN_URL",    "http://localhost:3000/admin/subscription?status=paid")


def _duitku_signature(merchant_code: str, amount: int, merchant_order_id: str, api_key: str) -> str:
    raw = f"{merchant_code}{amount}{merchant_order_id}{api_key}"
    return hashlib.md5(raw.encode()).hexdigest()


def _duitku_callback_signature(merchant_code: str, amount: int, merchant_order_id: str,
                                 api_key: str) -> str:
    raw = f"{merchant_code}{amount}{merchant_order_id}{api_key}"
    return hashlib.md5(raw.encode()).hexdigest()


# ─────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────

def u(val) -> Optional[str]:
    return str(val) if val else None


def rp(val: int) -> str:
    return f"Rp{val:,.0f}".replace(",", ".")


def sub_dict(s: Subscription) -> dict:
    plan_info = PLANS.get(s.plan, {})
    return {
        "id": u(s.id), "company_id": u(s.company_id),
        "plan": s.plan, "plan_name": plan_info.get("name", s.plan),
        "status": s.status.value if s.status else None,
        "trial_ends_at": s.trial_ends_at.isoformat() if s.trial_ends_at else None,
        "current_period_start": s.current_period_start.isoformat() if s.current_period_start else None,
        "current_period_end": s.current_period_end.isoformat() if s.current_period_end else None,
        "max_buildings": s.max_buildings, "max_users": s.max_users, "max_assets": s.max_assets,
        "price_per_month": s.price_per_month,
        "features": plan_info.get("features", []),
    }


async def _get_or_create_subscription(company_id: uuid.UUID, db: AsyncSession) -> Subscription:
    r = await db.execute(select(Subscription).where(Subscription.company_id == company_id))
    sub = r.scalar_one_or_none()
    if not sub:
        now = datetime.utcnow()
        plan_info = PLANS["starter"]
        sub = Subscription(
            company_id=company_id, plan="starter",
            status=SubscriptionStatus.TRIAL,
            trial_ends_at=now + timedelta(days=TRIAL_DAYS),
            current_period_start=now,
            current_period_end=now + timedelta(days=TRIAL_DAYS),
            max_buildings=plan_info["max_buildings"],
            max_users=plan_info["max_users"],
            max_assets=plan_info["max_assets"],
            price_per_month=plan_info["price_monthly"],
        )
        db.add(sub)
        await db.flush()
    return sub


# ─────────────────────────────────────────────────────────────
# PUBLIC: PLANS
# ─────────────────────────────────────────────────────────────

@router.get("/saas/plans", tags=["SaaS"])
async def get_plans():
    """Public endpoint — list semua paket langganan."""
    result = []
    for key, p in PLANS.items():
        result.append({
            "key": key,
            "name": p["name"],
            "price_monthly": p["price_monthly"],
            "price_annual": p["price_annual"],
            "price_monthly_display": rp(p["price_monthly"]),
            "price_annual_display": rp(p["price_annual"]),
            "max_buildings": p["max_buildings"],
            "max_users": p["max_users"],
            "max_assets": p["max_assets"],
            "features": p["features"],
            "highlight": p["highlight"],
            "trial_days": TRIAL_DAYS,
        })
    return result


# ─────────────────────────────────────────────────────────────
# PUBLIC: REGISTER COMPANY
# ─────────────────────────────────────────────────────────────

class RegisterCompanyReq(BaseModel):
    # Company info
    company_name: str
    company_email: str
    company_phone: Optional[str] = None
    company_address: Optional[str] = None
    city: str = "Jakarta"
    # Building info
    building_name: str
    building_address: Optional[str] = None
    building_floors: int = 10
    # Admin user
    admin_name: str
    admin_email: str
    admin_password: str
    # Plan
    plan: str = "starter"


@router.post("/saas/register", tags=["SaaS"], status_code=201)
async def register_company(data: RegisterCompanyReq, db: AsyncSession = Depends(get_db)):
    """
    Registrasi company baru + gedung pertama + akun building_admin.
    Otomatis masuk masa trial TRIAL_DAYS hari.
    """
    # Validate plan
    if data.plan not in PLANS:
        raise HTTPException(400, f"Plan tidak valid. Pilih: {list(PLANS.keys())}")
    # Check email not taken
    ex = await db.execute(select(User).where(User.email == data.admin_email.lower()))
    if ex.scalar_one_or_none():
        raise HTTPException(409, "Email admin sudah terdaftar. Gunakan email lain.")
    ex2 = await db.execute(select(Company).where(Company.email == data.company_email.lower()))
    if ex2.scalar_one_or_none():
        raise HTTPException(409, "Email perusahaan sudah terdaftar.")
    if len(data.admin_password) < 8:
        raise HTTPException(400, "Password minimal 8 karakter.")

    now = datetime.utcnow()
    plan_info = PLANS[data.plan]

    # 1. Create Company
    company = Company(
        name=data.company_name,
        email=data.company_email.lower(),
        phone=data.company_phone,
        address=data.company_address,
        subscription_plan=data.plan,
        is_active=True,
    )
    db.add(company)
    await db.flush()

    # 2. Create first Building
    building = Building(
        company_id=company.id,
        name=data.building_name,
        address=data.building_address or data.company_address,
        city=data.city,
        floors_count=data.building_floors,
        is_active=True,
    )
    db.add(building)
    await db.flush()

    # 3. Create building_admin user
    admin = User(
        company_id=company.id,
        building_id=building.id,
        email=data.admin_email.lower().strip(),
        hashed_password=get_password_hash(data.admin_password),
        full_name=data.admin_name,
        role=UserRole.BUILDING_ADMIN,
        is_active=True,
    )
    db.add(admin)
    await db.flush()

    # 4. Create Trial subscription
    trial_end = now + timedelta(days=TRIAL_DAYS)
    sub = Subscription(
        company_id=company.id,
        plan=data.plan,
        status=SubscriptionStatus.TRIAL,
        trial_ends_at=trial_end,
        current_period_start=now,
        current_period_end=trial_end,
        max_buildings=plan_info["max_buildings"],
        max_users=plan_info["max_users"],
        max_assets=plan_info["max_assets"],
        price_per_month=plan_info["price_monthly"],
    )
    db.add(sub)
    await db.flush()

    # 5. Auto-login token
    token = create_access_token({
        "sub": str(admin.id),
        "company_id": str(company.id),
        "building_id": str(building.id),
        "role": admin.role.value,
    })

    return {
        "message": f"Registrasi berhasil! Trial {TRIAL_DAYS} hari dimulai sekarang.",
        "company_id": str(company.id),
        "building_id": str(building.id),
        "admin_id": str(admin.id),
        "access_token": token,
        "token_type": "bearer",
        "role": admin.role.value,
        "trial_ends_at": trial_end.isoformat(),
        "plan": data.plan,
    }


# ─────────────────────────────────────────────────────────────
# SUBSCRIPTION: CURRENT STATUS
# ─────────────────────────────────────────────────────────────

@router.get("/saas/subscription", tags=["SaaS"])
async def get_subscription(
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    sub = await _get_or_create_subscription(current_user.company_id, db)
    # Check trial expiry
    if sub.status == SubscriptionStatus.TRIAL and sub.trial_ends_at and datetime.utcnow() > sub.trial_ends_at:
        sub.status = SubscriptionStatus.PAST_DUE
        await db.flush()
    return sub_dict(sub)


# ─────────────────────────────────────────────────────────────
# PAYMENT: CREATE TRANSACTION (Duitku)
# ─────────────────────────────────────────────────────────────

class CreatePaymentReq(BaseModel):
    plan: str
    billing_cycle: str = "monthly"  # monthly | annual
    payment_method: str = "VA_BCA"  # VA_BCA VA_BNI VA_MANDIRI QRIS


DUITKU_PAYMENT_METHODS = {
    "VA_BCA":     {"code": "BC", "name": "Virtual Account BCA"},
    "VA_BNI":     {"code": "I",  "name": "Virtual Account BNI"},
    "VA_BRI":     {"code": "BR", "name": "Virtual Account BRI"},
    "VA_MANDIRI": {"code": "M2", "name": "Virtual Account Mandiri"},
    "VA_PERMATA": {"code": "BT", "name": "Virtual Account Permata"},
    "QRIS":       {"code": "SP", "name": "QRIS"},
    "DANA":       {"code": "DA", "name": "DANA"},
    "OVO":        {"code": "OV", "name": "OVO"},
    "GOPAY":      {"code": "LF", "name": "GoPay / LinkAja"},
}


@router.post("/saas/payment/create", tags=["SaaS"])
async def create_payment(
    data: CreatePaymentReq,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    if data.plan not in PLANS:
        raise HTTPException(400, "Plan tidak valid")
    if data.payment_method not in DUITKU_PAYMENT_METHODS:
        raise HTTPException(400, f"Metode pembayaran tidak valid. Pilih: {list(DUITKU_PAYMENT_METHODS.keys())}")

    plan_info = PLANS[data.plan]
    is_annual = data.billing_cycle == "annual"
    amount = plan_info["price_annual"] if is_annual else plan_info["price_monthly"]
    plan_months = 12 if is_annual else 1

    merchant_order_id = f"SOMA-{str(current_user.company_id)[:8].upper()}-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"
    description = f"SOMA BMS {plan_info['name']} {'Tahunan' if is_annual else 'Bulanan'} - {current_user.email}"

    pm_code = DUITKU_PAYMENT_METHODS[data.payment_method]["code"]
    signature = _duitku_signature(DUITKU_MERCHANT_CODE, amount, merchant_order_id, DUITKU_API_KEY)

    payload = {
        "merchantCode": DUITKU_MERCHANT_CODE,
        "paymentAmount": amount,
        "merchantOrderId": merchant_order_id,
        "productDetails": description,
        "email": current_user.email,
        "additionalParam": str(current_user.company_id),
        "paymentMethod": pm_code,
        "merchantUserInfo": current_user.full_name,
        "customerVaName": current_user.full_name,
        "callbackUrl": DUITKU_CALLBACK_URL,
        "returnUrl": DUITKU_RETURN_URL,
        "expiryPeriod": 1440,  # 24 jam
        "signature": signature,
    }

    # Create pending transaction record first
    txn = PaymentTransaction(
        company_id=current_user.company_id,
        merchant_order_id=merchant_order_id,
        payment_method=data.payment_method,
        amount=amount,
        plan=data.plan,
        plan_months=plan_months,
        status=PaymentStatus.PENDING,
        description=description,
        expired_at=datetime.utcnow() + timedelta(hours=24),
    )
    db.add(txn)
    await db.flush()

    # Call Duitku API
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                f"{DUITKU_BASE_URL}/merchant/v2/inquiry",
                json=payload,
                headers={"Content-Type": "application/json"},
            )
        resp_data = resp.json()
        if resp.status_code == 200 and resp_data.get("statusCode") == "00":
            txn.payment_url = resp_data.get("paymentUrl")
            txn.duitku_reference = resp_data.get("reference")
            txn.duitku_raw = resp_data
            await db.flush()
            return {
                "transaction_id": str(txn.id),
                "merchant_order_id": merchant_order_id,
                "payment_url": txn.payment_url,
                "va_number": resp_data.get("vaNumber"),
                "amount": amount,
                "amount_display": rp(amount),
                "payment_method": DUITKU_PAYMENT_METHODS[data.payment_method]["name"],
                "plan": data.plan,
                "plan_name": plan_info["name"],
                "billing_cycle": data.billing_cycle,
                "expires_at": txn.expired_at.isoformat(),
                "status": "pending",
            }
        else:
            txn.status = PaymentStatus.FAILED
            txn.duitku_raw = resp_data
            await db.flush()
            raise HTTPException(502, f"Duitku error: {resp_data.get('statusMessage', 'Unknown error')}")
    except httpx.RequestError as e:
        txn.status = PaymentStatus.FAILED
        await db.flush()
        logger.error(f"Duitku request error: {e}")
        raise HTTPException(503, "Gagal terhubung ke payment gateway. Coba lagi.")


# ─────────────────────────────────────────────────────────────
# PAYMENT: DUITKU CALLBACK (webhook)
# ─────────────────────────────────────────────────────────────

@router.post("/saas/payment/callback", tags=["SaaS"])
async def duitku_callback(request: Request, db: AsyncSession = Depends(get_db)):
    """
    Duitku memanggil endpoint ini saat pembayaran berhasil/gagal.
    Verifikasi signature lalu aktivasi subscription.
    """
    try:
        body = await request.json()
    except Exception:
        body = dict(await request.form())

    merchant_code   = body.get("merchantCode", "")
    amount_str      = body.get("amount", "0")
    merchant_order  = body.get("merchantOrderId", "")
    result_code     = body.get("resultCode", "")
    received_sig    = body.get("signature", "")

    try:
        amount = int(float(amount_str))
    except ValueError:
        amount = 0

    # Verify signature
    expected_sig = _duitku_callback_signature(merchant_code, amount, merchant_order, DUITKU_API_KEY)
    if received_sig != expected_sig:
        logger.warning(f"Duitku callback signature mismatch for order {merchant_order}")
        raise HTTPException(400, "Invalid signature")

    # Find transaction
    r = await db.execute(
        select(PaymentTransaction).where(PaymentTransaction.merchant_order_id == merchant_order)
    )
    txn = r.scalar_one_or_none()
    if not txn:
        logger.error(f"Transaction not found: {merchant_order}")
        return {"status": "ignored"}

    txn.duitku_raw = body
    txn.duitku_reference = body.get("reference", txn.duitku_reference)

    if result_code == "00":
        # Payment successful
        txn.status = PaymentStatus.PAID
        txn.paid_at = datetime.utcnow()
        # Activate/upgrade subscription
        sub = await _get_or_create_subscription(txn.company_id, db)
        plan_info = PLANS.get(txn.plan, PLANS["starter"])
        now = datetime.utcnow()
        period_start = now
        if sub.current_period_end and sub.current_period_end > now:
            period_start = sub.current_period_end  # extend existing period
        period_end = period_start + timedelta(days=30 * txn.plan_months)
        sub.plan = txn.plan
        sub.status = SubscriptionStatus.ACTIVE
        sub.current_period_start = now
        sub.current_period_end = period_end
        sub.max_buildings = plan_info["max_buildings"]
        sub.max_users = plan_info["max_users"]
        sub.max_assets = plan_info["max_assets"]
        sub.price_per_month = plan_info["price_monthly"]
        txn.subscription_id = sub.id
        # Update company plan
        r2 = await db.execute(select(Company).where(Company.id == txn.company_id))
        company = r2.scalar_one_or_none()
        if company:
            company.subscription_plan = txn.plan
        logger.info(f"Payment successful for company {txn.company_id}: {txn.plan} activated")
    else:
        txn.status = PaymentStatus.FAILED

    await db.commit()
    return {"status": "OK"}


# ─────────────────────────────────────────────────────────────
# PAYMENT: CHECK STATUS
# ─────────────────────────────────────────────────────────────

@router.get("/saas/payment/{transaction_id}", tags=["SaaS"])
async def get_payment_status(
    transaction_id: uuid.UUID,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(PaymentTransaction).where(
        PaymentTransaction.id == transaction_id,
        PaymentTransaction.company_id == current_user.company_id,
    ))
    txn = r.scalar_one_or_none()
    if not txn:
        raise HTTPException(404, "Transaksi tidak ditemukan")
    return {
        "id": str(txn.id),
        "merchant_order_id": txn.merchant_order_id,
        "amount": txn.amount,
        "amount_display": rp(txn.amount),
        "plan": txn.plan,
        "billing_cycle": "annual" if txn.plan_months == 12 else "monthly",
        "payment_method": txn.payment_method,
        "payment_url": txn.payment_url,
        "status": txn.status.value,
        "paid_at": txn.paid_at.isoformat() if txn.paid_at else None,
        "expires_at": txn.expired_at.isoformat() if txn.expired_at else None,
    }


@router.get("/saas/payment-history", tags=["SaaS"])
async def payment_history(
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(
        select(PaymentTransaction)
        .where(PaymentTransaction.company_id == current_user.company_id)
        .order_by(PaymentTransaction.created_at.desc())
        .limit(20)
    )
    txns = r.scalars().all()
    return [{
        "id": str(t.id),
        "merchant_order_id": t.merchant_order_id,
        "amount_display": rp(t.amount),
        "plan": t.plan,
        "payment_method": t.payment_method,
        "status": t.status.value,
        "paid_at": t.paid_at.isoformat() if t.paid_at else None,
        "created_at": t.created_at.isoformat(),
    } for t in txns]


# ─────────────────────────────────────────────────────────────
# SUPER ADMIN PANEL
# ─────────────────────────────────────────────────────────────

@router.get("/superadmin/stats", tags=["SuperAdmin"])
async def superadmin_stats(
    current_user: User = Depends(require_role(UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    total_companies = await db.scalar(select(func.count(Company.id)).where(Company.is_active == True)) or 0
    total_buildings = await db.scalar(select(func.count(Building.id))) or 0
    total_users     = await db.scalar(select(func.count(User.id)).where(User.is_active == True)) or 0
    active_subs     = await db.scalar(select(func.count(Subscription.id)).where(Subscription.status == SubscriptionStatus.ACTIVE)) or 0
    trial_subs      = await db.scalar(select(func.count(Subscription.id)).where(Subscription.status == SubscriptionStatus.TRIAL)) or 0
    past_due_subs   = await db.scalar(select(func.count(Subscription.id)).where(Subscription.status == SubscriptionStatus.PAST_DUE)) or 0
    paid_txn_total  = await db.scalar(select(func.sum(PaymentTransaction.amount)).where(PaymentTransaction.status == PaymentStatus.PAID)) or 0
    paid_this_month = await db.scalar(
        select(func.sum(PaymentTransaction.amount)).where(
            PaymentTransaction.status == PaymentStatus.PAID,
            PaymentTransaction.paid_at >= datetime.utcnow().replace(day=1, hour=0, minute=0, second=0),
        )
    ) or 0

    # MRR estimate
    r = await db.execute(select(Subscription).where(Subscription.status == SubscriptionStatus.ACTIVE))
    active_list = r.scalars().all()
    mrr = sum(s.price_per_month for s in active_list)

    return {
        "companies": {"total": total_companies},
        "buildings": {"total": total_buildings},
        "users": {"total": total_users},
        "subscriptions": {
            "active": active_subs,
            "trial": trial_subs,
            "past_due": past_due_subs,
        },
        "revenue": {
            "total_all_time": paid_txn_total,
            "total_all_time_display": rp(paid_txn_total),
            "this_month": paid_this_month,
            "this_month_display": rp(paid_this_month),
            "mrr": mrr,
            "mrr_display": rp(mrr),
        },
    }


@router.get("/superadmin/companies", tags=["SuperAdmin"])
async def superadmin_list_companies(
    search: Optional[str] = None,
    plan: Optional[str] = None,
    status: Optional[str] = None,
    current_user: User = Depends(require_role(UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    q = select(Company).order_by(Company.created_at.desc())
    if search:
        from sqlalchemy import or_
        q = q.where(or_(Company.name.ilike(f"%{search}%"), Company.email.ilike(f"%{search}%")))
    r = await db.execute(q)
    companies = r.scalars().all()

    result = []
    for c in companies:
        sub_r = await db.execute(select(Subscription).where(Subscription.company_id == c.id))
        sub = sub_r.scalar_one_or_none()
        bld_count = await db.scalar(select(func.count(Building.id)).where(Building.company_id == c.id)) or 0
        usr_count = await db.scalar(select(func.count(User.id)).where(User.company_id == c.id, User.is_active == True)) or 0

        if plan and (not sub or sub.plan != plan):
            continue
        if status and (not sub or sub.status.value != status):
            continue

        result.append({
            "id": str(c.id),
            "name": c.name,
            "email": c.email,
            "phone": c.phone,
            "is_active": c.is_active,
            "buildings": bld_count,
            "users": usr_count,
            "created_at": c.created_at.isoformat(),
            "subscription": sub_dict(sub) if sub else None,
        })
    return result


@router.get("/superadmin/companies/{company_id}", tags=["SuperAdmin"])
async def superadmin_get_company(
    company_id: uuid.UUID,
    current_user: User = Depends(require_role(UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(Company).where(Company.id == company_id))
    company = r.scalar_one_or_none()
    if not company:
        raise HTTPException(404, "Company tidak ditemukan")
    sub_r = await db.execute(select(Subscription).where(Subscription.company_id == company_id))
    sub = sub_r.scalar_one_or_none()
    buildings_r = await db.execute(select(Building).where(Building.company_id == company_id))
    buildings = buildings_r.scalars().all()
    users_r = await db.execute(select(User).where(User.company_id == company_id, User.is_active == True))
    users = users_r.scalars().all()
    txns_r = await db.execute(
        select(PaymentTransaction).where(PaymentTransaction.company_id == company_id)
        .order_by(PaymentTransaction.created_at.desc()).limit(10)
    )
    txns = txns_r.scalars().all()
    return {
        "id": str(company.id), "name": company.name, "email": company.email,
        "phone": company.phone, "address": company.address, "is_active": company.is_active,
        "created_at": company.created_at.isoformat(),
        "subscription": sub_dict(sub) if sub else None,
        "buildings": [{"id": str(b.id), "name": b.name, "city": b.city} for b in buildings],
        "users_count": len(users),
        "users_by_role": {role.value: sum(1 for u in users if u.role == role) for role in UserRole},
        "recent_payments": [{
            "id": str(t.id), "amount_display": rp(t.amount),
            "plan": t.plan, "status": t.status.value,
            "created_at": t.created_at.isoformat(),
        } for t in txns],
    }


class UpdateSubscriptionReq(BaseModel):
    plan: Optional[str] = None
    status: Optional[str] = None
    extend_days: Optional[int] = None


@router.put("/superadmin/companies/{company_id}/subscription", tags=["SuperAdmin"])
async def superadmin_update_subscription(
    company_id: uuid.UUID,
    data: UpdateSubscriptionReq,
    current_user: User = Depends(require_role(UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    sub = await _get_or_create_subscription(company_id, db)
    if data.plan and data.plan in PLANS:
        plan_info = PLANS[data.plan]
        sub.plan = data.plan
        sub.max_buildings = plan_info["max_buildings"]
        sub.max_users = plan_info["max_users"]
        sub.max_assets = plan_info["max_assets"]
        sub.price_per_month = plan_info["price_monthly"]
        r = await db.execute(select(Company).where(Company.id == company_id))
        c = r.scalar_one_or_none()
        if c:
            c.subscription_plan = data.plan
    if data.status:
        sub.status = SubscriptionStatus(data.status)
    if data.extend_days:
        base = sub.current_period_end or datetime.utcnow()
        if base < datetime.utcnow():
            base = datetime.utcnow()
        sub.current_period_end = base + timedelta(days=data.extend_days)
        sub.status = SubscriptionStatus.ACTIVE
    await db.flush()
    return {"message": "Subscription diperbarui", "subscription": sub_dict(sub)}


@router.put("/superadmin/companies/{company_id}/toggle", tags=["SuperAdmin"])
async def superadmin_toggle_company(
    company_id: uuid.UUID,
    current_user: User = Depends(require_role(UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(Company).where(Company.id == company_id))
    c = r.scalar_one_or_none()
    if not c:
        raise HTTPException(404, "Company tidak ditemukan")
    c.is_active = not c.is_active
    await db.flush()
    return {"is_active": c.is_active, "message": f"Company {'diaktifkan' if c.is_active else 'dinonaktifkan'}"}
