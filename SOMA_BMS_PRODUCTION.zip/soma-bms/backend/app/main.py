"""SOMA BMS — FastAPI Application"""
import asyncio
import logging
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, date

from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, EmailStr
from sqlalchemy import select, func, and_, or_
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Optional, List, Any, Dict
from enum import Enum as PyEnum

from app.core.config import get_settings
from app.core.database import engine, Base, get_db, AsyncSessionLocal
from app.core.security import verify_password, get_password_hash, create_access_token, decode_token
from app.models.models import (
    Company, Building, User, UserRole, Shift, ShiftAssignment,
    Asset, ChecklistTemplate, ScheduleRule, TaskInstance, TaskStatus,
    WorkOrder, WOStatus, WOPriority,
    Material, MaterialTransaction, MaterialRequest, TransactionType,
    Meter, MeterReading, MeterType, TariffConfig, Invoice, InvoiceStatus,
    Visitor, Visit, VisitStatus, AccessLog, ParkingEvent,
    Alarm, AlarmSeverity, AlarmStatus,
)
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from app.api.deps import (
    get_current_user, require_auth, require_role,
    verify_building_access, get_building_id_for_user
)

settings = get_settings()
logger = logging.getLogger(__name__)
security_scheme = HTTPBearer(auto_error=False)


# ─────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────

def u(val) -> Optional[str]:
    return str(val) if val else None


def dt(val) -> Optional[str]:
    return val.isoformat() if val else None


def gen_wo_number() -> str:
    from datetime import datetime as _dt
    return f"WO-{_dt.utcnow().strftime('%Y%m%d')}-{str(uuid.uuid4())[:6].upper()}"


def gen_inv_number(period_start: datetime) -> str:
    return f"INV-{period_start.strftime('%Y%m')}-{str(uuid.uuid4())[:6].upper()}"


async def get_building_or_404(db, building_id, company_id):
    r = await db.execute(
        select(Building).where(Building.id == building_id, Building.company_id == company_id, Building.is_active == True)
    )
    b = r.scalar_one_or_none()
    if not b:
        raise HTTPException(404, "Gedung tidak ditemukan")
    return b


# ─────────────────────────────────────────────────────────────
# SCHEDULER BACKGROUND TASKS
# ─────────────────────────────────────────────────────────────

async def run_scheduler():
    while True:
        try:
            await generate_scheduled_tasks()
            await escalate_overdue_tasks()
        except Exception as e:
            logger.error(f"Scheduler error: {e}")
        await asyncio.sleep(3600)  # run every hour


async def generate_scheduled_tasks():
    async with AsyncSessionLocal() as db:
        try:
            now = datetime.utcnow()
            result = await db.execute(select(ScheduleRule).where(ScheduleRule.is_active == True))
            rules = result.scalars().all()

            for rule in rules:
                if not _should_run_today(rule, now):
                    continue
                if rule.last_generated and rule.last_generated.date() == now.date():
                    continue

                tpl = await db.get(ChecklistTemplate, rule.template_id)
                if not tpl:
                    continue

                users_q = await db.execute(
                    select(User).where(
                        User.company_id == rule.company_id,
                        User.building_id == rule.building_id,
                        User.role == rule.assigned_role,
                        User.is_active == True,
                    )
                )
                eligible = users_q.scalars().all()
                if not eligible:
                    continue

                task_time_str = rule.recurrence_pattern.get("time", "08:00")
                th, tm = map(int, task_time_str.split(":"))
                due_dt = datetime.combine(now.date(), datetime.min.time()).replace(hour=th, minute=tm)

                asset_ids = rule.asset_ids or [None]
                for i, asset_id in enumerate(asset_ids):
                    user = eligible[i % len(eligible)]
                    # Check not duplicate
                    ex = await db.execute(
                        select(TaskInstance).where(
                            TaskInstance.schedule_rule_id == rule.id,
                            TaskInstance.due_date == due_dt,
                            TaskInstance.asset_id == (uuid.UUID(asset_id) if asset_id else None),
                        )
                    )
                    if ex.scalar_one_or_none():
                        continue
                    task = TaskInstance(
                        company_id=rule.company_id,
                        building_id=rule.building_id,
                        schedule_rule_id=rule.id,
                        template_id=tpl.id,
                        template_snapshot={
                            "name": tpl.name,
                            "template_type": tpl.template_type,
                            "category": tpl.category,
                            "sections": tpl.sections,
                            "default_materials": tpl.default_materials,
                        },
                        asset_id=uuid.UUID(asset_id) if asset_id else None,
                        assigned_user_id=user.id,
                        assigned_role=rule.assigned_role,
                        due_date=due_dt,
                        status=TaskStatus.ASSIGNED,
                    )
                    db.add(task)

                rule.last_generated = now

            await db.commit()
        except Exception as e:
            await db.rollback()
            logger.error(f"Task generation error: {e}")


async def escalate_overdue_tasks():
    async with AsyncSessionLocal() as db:
        try:
            now = datetime.utcnow()
            result = await db.execute(
                select(TaskInstance).where(
                    TaskInstance.due_date < now,
                    TaskInstance.status.in_([TaskStatus.ASSIGNED, TaskStatus.IN_PROGRESS]),
                )
            )
            tasks = result.scalars().all()
            for t in tasks:
                t.status = TaskStatus.OVERDUE
                t.is_escalated = True
            if tasks:
                await db.commit()
                logger.info(f"Marked {len(tasks)} tasks as overdue")
        except Exception as e:
            await db.rollback()
            logger.error(f"Escalation error: {e}")


def _should_run_today(rule: ScheduleRule, now: datetime) -> bool:
    if rule.start_date and now < rule.start_date:
        return False
    if rule.end_date and now > rule.end_date:
        return False
    freq = rule.recurrence_pattern.get("freq", "daily")
    if freq == "daily":
        return True
    elif freq == "weekly":
        days = [d.lower() for d in rule.recurrence_pattern.get("days", [])]
        return now.strftime("%A").lower() in days
    elif freq in ("monthly", "quarterly"):
        return now.day == rule.recurrence_pattern.get("day", 1)
    elif freq == "yearly":
        return now.month == rule.recurrence_pattern.get("month", 1) and now.day == rule.recurrence_pattern.get("day", 1)
    return True


# ─────────────────────────────────────────────────────────────
# APP SETUP
# ─────────────────────────────────────────────────────────────

limiter = Limiter(key_func=get_remote_address)

@asynccontextmanager
async def lifespan(app: FastAPI):
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("✅ DB tables ready")
    task = asyncio.create_task(run_scheduler())
    yield
    task.cancel()


app = FastAPI(
    title="SOMA BMS API",
    description="Smart Building Management System — Multi-tenant SaaS",
    version="1.0.0",
    docs_url="/docs",
    lifespan=lifespan,
)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

from app.saas import router as saas_router
app.include_router(saas_router, prefix="/api/v1")


@app.get("/health")
async def health():
    return {"status": "ok", "app": "SOMA BMS", "version": "1.0.0"}


# ─────────────────────────────────────────────────────────────
# AUTH
# ─────────────────────────────────────────────────────────────

class LoginReq(BaseModel):
    email: str
    password: str

class ChangePassReq(BaseModel):
    current_password: str
    new_password: str


@app.post("/api/v1/auth/login", tags=["Auth"])
@limiter.limit("10/minute")
async def login(request: Request, data: LoginReq, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(User).where(User.email == data.email.lower().strip(), User.is_active == True)
    )
    user = result.scalar_one_or_none()
    if not user or not verify_password(data.password, user.hashed_password):
        raise HTTPException(401, "Email atau password salah")
    user.last_login = datetime.utcnow()
    await db.flush()
    token = create_access_token({
        "sub": str(user.id),
        "company_id": str(user.company_id),
        "building_id": u(user.building_id),
        "role": user.role.value,
    })
    return {
        "access_token": token, "token_type": "bearer",
        "user_id": u(user.id), "email": user.email,
        "full_name": user.full_name, "role": user.role.value,
        "company_id": u(user.company_id),
        "building_id": u(user.building_id),
    }


@app.get("/api/v1/auth/me", tags=["Auth"])
async def me(current_user: User = Depends(require_auth)):
    return {
        "id": u(current_user.id), "email": current_user.email,
        "full_name": current_user.full_name, "role": current_user.role.value,
        "company_id": u(current_user.company_id),
        "building_id": u(current_user.building_id),
        "phone": current_user.phone, "skill_category": current_user.skill_category,
    }


@app.put("/api/v1/auth/change-password", tags=["Auth"])
async def change_password(
    data: ChangePassReq,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    if not verify_password(data.current_password, current_user.hashed_password):
        raise HTTPException(400, "Password lama tidak sesuai")
    current_user.hashed_password = get_password_hash(data.new_password)
    await db.flush()
    return {"message": "Password berhasil diubah"}


# ─────────────────────────────────────────────────────────────
# BUILDINGS
# ─────────────────────────────────────────────────────────────

class BuildingCreate(BaseModel):
    name: str
    address: Optional[str] = None
    city: str = "Jakarta"
    floors_count: int = 10
    total_area_m2: Optional[float] = None
    contact_name: Optional[str] = None
    contact_phone: Optional[str] = None


def bld_dict(b: Building):
    return {
        "id": u(b.id), "company_id": u(b.company_id),
        "name": b.name, "address": b.address, "city": b.city,
        "floors_count": b.floors_count, "total_area_m2": b.total_area_m2,
        "contact_name": b.contact_name, "contact_phone": b.contact_phone,
        "is_active": b.is_active, "created_at": dt(b.created_at),
    }


@app.get("/api/v1/buildings", tags=["Buildings"])
async def list_buildings(
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    q = select(Building).where(Building.company_id == current_user.company_id, Building.is_active == True)
    if current_user.role not in [UserRole.SUPER_ADMIN, UserRole.COMPANY_ADMIN] and current_user.building_id:
        q = q.where(Building.id == current_user.building_id)
    r = await db.execute(q.order_by(Building.name))
    return [bld_dict(b) for b in r.scalars().all()]


@app.post("/api/v1/buildings", tags=["Buildings"], status_code=201)
async def create_building(
    data: BuildingCreate,
    current_user: User = Depends(require_role(UserRole.SUPER_ADMIN, UserRole.COMPANY_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    b = Building(company_id=current_user.company_id, **data.model_dump())
    db.add(b)
    await db.flush()
    return bld_dict(b)


# ─────────────────────────────────────────────────────────────
# USERS
# ─────────────────────────────────────────────────────────────

class UserCreate(BaseModel):
    email: str
    password: str
    full_name: str
    role: UserRole
    building_id: Optional[uuid.UUID] = None
    phone: Optional[str] = None
    skill_category: Optional[str] = None

class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    phone: Optional[str] = None
    skill_category: Optional[str] = None
    building_id: Optional[uuid.UUID] = None
    is_active: Optional[bool] = None


def user_dict(u_: User):
    return {
        "id": u(u_.id), "email": u_.email, "full_name": u_.full_name,
        "role": u_.role.value, "company_id": u(u_.company_id),
        "building_id": u(u_.building_id), "phone": u_.phone,
        "skill_category": u_.skill_category, "is_active": u_.is_active,
        "last_login": dt(u_.last_login), "created_at": dt(u_.created_at),
    }


@app.post("/api/v1/users", tags=["Users"], status_code=201)
async def create_user(
    data: UserCreate,
    current_user: User = Depends(require_role(UserRole.BUILDING_ADMIN, UserRole.SUPER_ADMIN, UserRole.COMPANY_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    ex = await db.execute(select(User).where(User.email == data.email.lower()))
    if ex.scalar_one_or_none():
        raise HTTPException(400, "Email sudah terdaftar")
    # Ensure building_id belongs to this company
    bld_id = data.building_id or current_user.building_id
    if bld_id:
        await get_building_or_404(db, bld_id, current_user.company_id)
    user = User(
        company_id=current_user.company_id,
        email=data.email.lower().strip(),
        hashed_password=get_password_hash(data.password),
        full_name=data.full_name, role=data.role,
        building_id=bld_id, phone=data.phone,
        skill_category=data.skill_category,
    )
    db.add(user)
    await db.flush()
    return user_dict(user)


@app.get("/api/v1/users", tags=["Users"])
async def list_users(
    role: Optional[str] = None,
    building_id: Optional[uuid.UUID] = None,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    q = select(User).where(User.company_id == current_user.company_id)
    effective_bld = building_id or get_building_id_for_user(current_user)
    if effective_bld:
        q = q.where(User.building_id == effective_bld)
    if role:
        try:
            q = q.where(User.role == UserRole(role))
        except ValueError:
            pass
    r = await db.execute(q.order_by(User.full_name))
    return [user_dict(u_) for u_ in r.scalars().all()]


@app.get("/api/v1/users/{user_id}", tags=["Users"])
async def get_user(
    user_id: uuid.UUID,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(User).where(User.id == user_id, User.company_id == current_user.company_id))
    user = r.scalar_one_or_none()
    if not user:
        raise HTTPException(404, "User tidak ditemukan")
    return user_dict(user)


@app.put("/api/v1/users/{user_id}", tags=["Users"])
async def update_user(
    user_id: uuid.UUID,
    data: UserUpdate,
    current_user: User = Depends(require_role(UserRole.BUILDING_ADMIN, UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(User).where(User.id == user_id, User.company_id == current_user.company_id))
    user = r.scalar_one_or_none()
    if not user:
        raise HTTPException(404, "User tidak ditemukan")
    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(user, k, v)
    await db.flush()
    return user_dict(user)


@app.delete("/api/v1/users/{user_id}", tags=["Users"])
async def deactivate_user(
    user_id: uuid.UUID,
    current_user: User = Depends(require_role(UserRole.BUILDING_ADMIN, UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(User).where(User.id == user_id, User.company_id == current_user.company_id))
    user = r.scalar_one_or_none()
    if not user:
        raise HTTPException(404, "User tidak ditemukan")
    if str(user.id) == str(current_user.id):
        raise HTTPException(400, "Tidak bisa menonaktifkan akun sendiri")
    user.is_active = False
    await db.flush()
    return {"message": "User berhasil dinonaktifkan"}


# Shifts
class ShiftCreate(BaseModel):
    building_id: uuid.UUID
    name: str
    start_time: str  # "06:00"
    end_time: str

class ShiftAssignCreate(BaseModel):
    user_id: uuid.UUID
    shift_id: uuid.UUID
    assignment_date: date

@app.post("/api/v1/shifts", tags=["Shifts"], status_code=201)
async def create_shift(
    data: ShiftCreate,
    current_user: User = Depends(require_role(UserRole.BUILDING_ADMIN, UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    await get_building_or_404(db, data.building_id, current_user.company_id)
    from datetime import time as _time
    h1, m1 = map(int, data.start_time.split(":"))
    h2, m2 = map(int, data.end_time.split(":"))
    s = Shift(
        company_id=current_user.company_id, building_id=data.building_id,
        name=data.name, start_time=_time(h1, m1), end_time=_time(h2, m2),
    )
    db.add(s)
    await db.flush()
    return {"id": u(s.id), "name": s.name, "start_time": data.start_time, "end_time": data.end_time}


@app.get("/api/v1/shifts", tags=["Shifts"])
async def list_shifts(
    building_id: Optional[uuid.UUID] = None,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    bld = building_id or current_user.building_id
    q = select(Shift).where(Shift.company_id == current_user.company_id)
    if bld:
        q = q.where(Shift.building_id == bld)
    r = await db.execute(q)
    return [{"id": u(s.id), "name": s.name, "start_time": str(s.start_time)[:5], "end_time": str(s.end_time)[:5]} for s in r.scalars().all()]


@app.post("/api/v1/shifts/assign", tags=["Shifts"], status_code=201)
async def assign_shift(
    data: ShiftAssignCreate,
    current_user: User = Depends(require_role(UserRole.BUILDING_ADMIN, UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    # Verify user belongs to same company
    u_res = await db.execute(select(User).where(User.id == data.user_id, User.company_id == current_user.company_id))
    target_user = u_res.scalar_one_or_none()
    if not target_user:
        raise HTTPException(404, "User tidak ditemukan")
    s_res = await db.execute(select(Shift).where(Shift.id == data.shift_id, Shift.company_id == current_user.company_id))
    shift = s_res.scalar_one_or_none()
    if not shift:
        raise HTTPException(404, "Shift tidak ditemukan")
    assign = ShiftAssignment(
        company_id=current_user.company_id, building_id=shift.building_id,
        user_id=data.user_id, shift_id=data.shift_id, assignment_date=data.assignment_date,
    )
    db.add(assign)
    await db.flush()
    return {"id": u(assign.id), "message": "Shift berhasil ditugaskan"}


@app.get("/api/v1/shifts/assignments", tags=["Shifts"])
async def list_assignments(
    user_id: Optional[uuid.UUID] = None,
    building_id: Optional[uuid.UUID] = None,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    bld = building_id or current_user.building_id
    q = select(ShiftAssignment).where(ShiftAssignment.company_id == current_user.company_id)
    if user_id:
        q = q.where(ShiftAssignment.user_id == user_id)
    elif current_user.role in [UserRole.TEKNISI, UserRole.HOUSEKEEPING]:
        q = q.where(ShiftAssignment.user_id == current_user.id)
    if bld:
        q = q.where(ShiftAssignment.building_id == bld)
    r = await db.execute(q.order_by(ShiftAssignment.assignment_date))
    return [{"id": u(a.id), "user_id": u(a.user_id), "shift_id": u(a.shift_id), "date": str(a.assignment_date)} for a in r.scalars().all()]


# ─────────────────────────────────────────────────────────────
# ASSETS
# ─────────────────────────────────────────────────────────────

class AssetCreate(BaseModel):
    building_id: uuid.UUID
    category: str
    sub_category: Optional[str] = None
    name: str
    asset_code: Optional[str] = None
    floor: Optional[str] = None
    location: Optional[str] = None
    quantity: int = 1
    brand: Optional[str] = None
    model: Optional[str] = None
    serial_number: Optional[str] = None
    specifications: Optional[Dict[str, Any]] = None
    installation_date: Optional[datetime] = None
    expiry_date: Optional[datetime] = None
    warranty_expiry: Optional[datetime] = None
    condition: str = "good"
    notes: Optional[str] = None

class AssetUpdate(BaseModel):
    name: Optional[str] = None
    condition: Optional[str] = None
    notes: Optional[str] = None
    floor: Optional[str] = None
    location: Optional[str] = None
    brand: Optional[str] = None
    model: Optional[str] = None
    specifications: Optional[Dict[str, Any]] = None
    installation_date: Optional[datetime] = None
    expiry_date: Optional[datetime] = None
    is_active: Optional[bool] = None


def asset_dict(a: Asset):
    return {
        "id": u(a.id), "building_id": u(a.building_id), "company_id": u(a.company_id),
        "asset_code": a.asset_code, "category": a.category, "sub_category": a.sub_category,
        "name": a.name, "floor": a.floor, "location": a.location, "quantity": a.quantity,
        "brand": a.brand, "model": a.model, "serial_number": a.serial_number,
        "specifications": a.specifications or {},
        "installation_date": dt(a.installation_date),
        "expiry_date": dt(a.expiry_date),
        "warranty_expiry": dt(a.warranty_expiry),
        "condition": a.condition, "notes": a.notes, "is_active": a.is_active,
        "created_at": dt(a.created_at),
    }


@app.post("/api/v1/assets", tags=["Assets"], status_code=201)
async def create_asset(
    data: AssetCreate,
    current_user: User = Depends(require_role(UserRole.BUILDING_ADMIN, UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    await get_building_or_404(db, data.building_id, current_user.company_id)
    a = Asset(company_id=current_user.company_id, **data.model_dump())
    db.add(a)
    await db.flush()
    return asset_dict(a)


@app.get("/api/v1/assets", tags=["Assets"])
async def list_assets(
    building_id: Optional[uuid.UUID] = None,
    category: Optional[str] = None,
    floor: Optional[str] = None,
    search: Optional[str] = None,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    bld = building_id or get_building_id_for_user(current_user)
    q = select(Asset).where(Asset.company_id == current_user.company_id, Asset.is_active == True)
    if bld:
        q = q.where(Asset.building_id == bld)
    if category:
        q = q.where(Asset.category == category)
    if floor:
        q = q.where(Asset.floor == floor)
    if search:
        q = q.where(or_(
            Asset.name.ilike(f"%{search}%"),
            Asset.brand.ilike(f"%{search}%"),
            Asset.asset_code.ilike(f"%{search}%"),
        ))
    r = await db.execute(q.order_by(Asset.category, Asset.name))
    return [asset_dict(a) for a in r.scalars().all()]


@app.get("/api/v1/assets/categories", tags=["Assets"])
async def asset_categories(
    building_id: Optional[uuid.UUID] = None,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    bld = building_id or get_building_id_for_user(current_user)
    q = select(Asset.category, Asset.sub_category).where(
        Asset.company_id == current_user.company_id, Asset.is_active == True
    )
    if bld:
        q = q.where(Asset.building_id == bld)
    r = await db.execute(q.distinct())
    cats: Dict[str, List] = {}
    for cat, sub in r.all():
        if cat not in cats:
            cats[cat] = []
        if sub and sub not in cats[cat]:
            cats[cat].append(sub)
    return cats


@app.get("/api/v1/assets/{asset_id}", tags=["Assets"])
async def get_asset(
    asset_id: uuid.UUID,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(Asset).where(Asset.id == asset_id, Asset.company_id == current_user.company_id))
    a = r.scalar_one_or_none()
    if not a:
        raise HTTPException(404, "Aset tidak ditemukan")
    # Building isolation check
    bld_filter = get_building_id_for_user(current_user)
    if bld_filter and str(a.building_id) != str(bld_filter):
        raise HTTPException(403, "Akses ditolak")
    return asset_dict(a)


@app.put("/api/v1/assets/{asset_id}", tags=["Assets"])
async def update_asset(
    asset_id: uuid.UUID,
    data: AssetUpdate,
    current_user: User = Depends(require_role(UserRole.BUILDING_ADMIN, UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(Asset).where(Asset.id == asset_id, Asset.company_id == current_user.company_id))
    a = r.scalar_one_or_none()
    if not a:
        raise HTTPException(404, "Aset tidak ditemukan")
    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(a, k, v)
    await db.flush()
    return asset_dict(a)


@app.delete("/api/v1/assets/{asset_id}", tags=["Assets"])
async def delete_asset(
    asset_id: uuid.UUID,
    current_user: User = Depends(require_role(UserRole.BUILDING_ADMIN, UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(Asset).where(Asset.id == asset_id, Asset.company_id == current_user.company_id))
    a = r.scalar_one_or_none()
    if not a:
        raise HTTPException(404, "Aset tidak ditemukan")
    a.is_active = False
    await db.flush()
    return {"message": "Aset berhasil dihapus"}


# ─────────────────────────────────────────────────────────────
# TEMPLATES
# ─────────────────────────────────────────────────────────────

class TemplateCreate(BaseModel):
    building_id: uuid.UUID
    name: str
    template_type: str = "checklist"
    category: str
    sub_category: Optional[str] = None
    estimated_duration_minutes: int = 30
    sections: List[Dict[str, Any]] = []
    default_materials: List[Dict[str, Any]] = []
    description: Optional[str] = None

class TemplateUpdate(BaseModel):
    name: Optional[str] = None
    sections: Optional[List[Dict[str, Any]]] = None
    estimated_duration_minutes: Optional[int] = None
    default_materials: Optional[List[Dict[str, Any]]] = None
    is_active: Optional[bool] = None
    description: Optional[str] = None


def tpl_dict(t: ChecklistTemplate):
    return {
        "id": u(t.id), "building_id": u(t.building_id), "company_id": u(t.company_id),
        "name": t.name, "template_type": t.template_type,
        "category": t.category, "sub_category": t.sub_category,
        "estimated_duration_minutes": t.estimated_duration_minutes,
        "sections": t.sections or [], "default_materials": t.default_materials or [],
        "version": t.version, "is_active": t.is_active, "description": t.description,
        "created_at": dt(t.created_at),
        "step_count": sum(len(s.get("steps", [])) for s in (t.sections or [])),
        "section_count": len(t.sections or []),
    }


@app.post("/api/v1/templates", tags=["Templates"], status_code=201)
async def create_template(
    data: TemplateCreate,
    current_user: User = Depends(require_role(UserRole.BUILDING_ADMIN, UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    await get_building_or_404(db, data.building_id, current_user.company_id)
    t = ChecklistTemplate(company_id=current_user.company_id, **data.model_dump())
    db.add(t)
    await db.flush()
    return tpl_dict(t)


@app.get("/api/v1/templates", tags=["Templates"])
async def list_templates(
    building_id: Optional[uuid.UUID] = None,
    category: Optional[str] = None,
    template_type: Optional[str] = None,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    bld = building_id or get_building_id_for_user(current_user)
    q = select(ChecklistTemplate).where(
        ChecklistTemplate.company_id == current_user.company_id,
        ChecklistTemplate.is_active == True,
    )
    if bld:
        q = q.where(ChecklistTemplate.building_id == bld)
    if category:
        q = q.where(ChecklistTemplate.category == category)
    if template_type:
        q = q.where(ChecklistTemplate.template_type == template_type)
    r = await db.execute(q.order_by(ChecklistTemplate.name))
    return [tpl_dict(t) for t in r.scalars().all()]


@app.get("/api/v1/templates/{tpl_id}", tags=["Templates"])
async def get_template(
    tpl_id: uuid.UUID,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(ChecklistTemplate).where(
        ChecklistTemplate.id == tpl_id, ChecklistTemplate.company_id == current_user.company_id
    ))
    t = r.scalar_one_or_none()
    if not t:
        raise HTTPException(404, "Template tidak ditemukan")
    return tpl_dict(t)


@app.put("/api/v1/templates/{tpl_id}", tags=["Templates"])
async def update_template(
    tpl_id: uuid.UUID,
    data: TemplateUpdate,
    current_user: User = Depends(require_role(UserRole.BUILDING_ADMIN, UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(ChecklistTemplate).where(
        ChecklistTemplate.id == tpl_id, ChecklistTemplate.company_id == current_user.company_id
    ))
    t = r.scalar_one_or_none()
    if not t:
        raise HTTPException(404, "Template tidak ditemukan")
    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(t, k, v)
    t.version += 1
    await db.flush()
    return tpl_dict(t)


@app.post("/api/v1/templates/{tpl_id}/duplicate", tags=["Templates"], status_code=201)
async def duplicate_template(
    tpl_id: uuid.UUID,
    current_user: User = Depends(require_role(UserRole.BUILDING_ADMIN, UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(ChecklistTemplate).where(
        ChecklistTemplate.id == tpl_id, ChecklistTemplate.company_id == current_user.company_id
    ))
    orig = r.scalar_one_or_none()
    if not orig:
        raise HTTPException(404, "Template tidak ditemukan")
    new_t = ChecklistTemplate(
        company_id=orig.company_id, building_id=orig.building_id,
        name=f"{orig.name} (Salinan)", template_type=orig.template_type,
        category=orig.category, sub_category=orig.sub_category,
        estimated_duration_minutes=orig.estimated_duration_minutes,
        sections=orig.sections, default_materials=orig.default_materials,
        version=1,
    )
    db.add(new_t)
    await db.flush()
    return tpl_dict(new_t)


# ─────────────────────────────────────────────────────────────
# SCHEDULE RULES
# ─────────────────────────────────────────────────────────────

class ScheduleCreate(BaseModel):
    building_id: uuid.UUID
    name: str
    template_id: uuid.UUID
    asset_ids: List[uuid.UUID] = []
    recurrence_pattern: Dict[str, Any]
    assigned_role: str
    assigned_user_id: Optional[uuid.UUID] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None


@app.post("/api/v1/schedules", tags=["Schedules"], status_code=201)
async def create_schedule(
    data: ScheduleCreate,
    current_user: User = Depends(require_role(UserRole.BUILDING_ADMIN, UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    await get_building_or_404(db, data.building_id, current_user.company_id)
    rule = ScheduleRule(
        company_id=current_user.company_id,
        building_id=data.building_id,
        name=data.name,
        template_id=data.template_id,
        asset_ids=[str(a) for a in data.asset_ids],
        recurrence_pattern=data.recurrence_pattern,
        assigned_role=data.assigned_role,
        assigned_user_id=data.assigned_user_id,
        start_date=data.start_date,
        end_date=data.end_date,
    )
    db.add(rule)
    await db.flush()
    return {"id": u(rule.id), "name": rule.name, "message": "Jadwal berhasil dibuat"}


@app.get("/api/v1/schedules", tags=["Schedules"])
async def list_schedules(
    building_id: Optional[uuid.UUID] = None,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    bld = building_id or get_building_id_for_user(current_user)
    q = select(ScheduleRule).where(ScheduleRule.company_id == current_user.company_id)
    if bld:
        q = q.where(ScheduleRule.building_id == bld)
    r = await db.execute(q.order_by(ScheduleRule.name))
    return [{"id": u(sr.id), "name": sr.name, "template_id": u(sr.template_id),
             "recurrence_pattern": sr.recurrence_pattern, "assigned_role": sr.assigned_role,
             "is_active": sr.is_active, "last_generated": dt(sr.last_generated)} for sr in r.scalars().all()]


@app.put("/api/v1/schedules/{rule_id}/toggle", tags=["Schedules"])
async def toggle_schedule(
    rule_id: uuid.UUID,
    current_user: User = Depends(require_role(UserRole.BUILDING_ADMIN, UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(ScheduleRule).where(
        ScheduleRule.id == rule_id, ScheduleRule.company_id == current_user.company_id
    ))
    rule = r.scalar_one_or_none()
    if not rule:
        raise HTTPException(404, "Jadwal tidak ditemukan")
    rule.is_active = not rule.is_active
    await db.flush()
    return {"is_active": rule.is_active, "message": f"Jadwal {'diaktifkan' if rule.is_active else 'dinonaktifkan'}"}


# ─────────────────────────────────────────────────────────────
# TASKS
# ─────────────────────────────────────────────────────────────

class TaskCompleteReq(BaseModel):
    results: List[Dict[str, Any]]
    materials_used: Optional[List[Dict[str, Any]]] = []
    notes: Optional[str] = None


def task_dict(t: TaskInstance, include_template: bool = False):
    d = {
        "id": u(t.id), "company_id": u(t.company_id), "building_id": u(t.building_id),
        "schedule_rule_id": u(t.schedule_rule_id),
        "template_id": u(t.template_id),
        "asset_id": u(t.asset_id),
        "assigned_user_id": u(t.assigned_user_id),
        "assigned_role": t.assigned_role,
        "due_date": dt(t.due_date),
        "started_at": dt(t.started_at),
        "completed_at": dt(t.completed_at),
        "status": t.status.value if t.status else None,
        "checklist_results": t.checklist_results or [],
        "materials_used": t.materials_used or [],
        "notes": t.notes,
        "is_escalated": t.is_escalated,
        "created_at": dt(t.created_at),
    }
    if include_template:
        d["template_snapshot"] = t.template_snapshot or {}
    return d


@app.get("/api/v1/tasks/my-tasks", tags=["Tasks"])
async def my_tasks(
    task_date: Optional[date] = None,
    status: Optional[str] = None,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    target = task_date or date.today()
    start = datetime.combine(target, datetime.min.time())
    end = start + timedelta(days=1)
    q = select(TaskInstance).where(
        TaskInstance.company_id == current_user.company_id,
        TaskInstance.assigned_user_id == current_user.id,
        TaskInstance.due_date >= start,
        TaskInstance.due_date < end,
    )
    if status:
        q = q.where(TaskInstance.status == TaskStatus(status))
    r = await db.execute(q.order_by(TaskInstance.due_date))
    return [task_dict(t, include_template=True) for t in r.scalars().all()]


@app.get("/api/v1/tasks/building-tasks", tags=["Tasks"])
async def building_tasks(
    building_id: Optional[uuid.UUID] = None,
    task_date: Optional[date] = None,
    status: Optional[str] = None,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    bld = building_id or get_building_id_for_user(current_user)
    target = task_date or date.today()
    start = datetime.combine(target, datetime.min.time())
    end = start + timedelta(days=1)
    q = select(TaskInstance).where(
        TaskInstance.company_id == current_user.company_id,
        TaskInstance.due_date >= start,
        TaskInstance.due_date < end,
    )
    if bld:
        q = q.where(TaskInstance.building_id == bld)
    if status:
        q = q.where(TaskInstance.status == TaskStatus(status))
    r = await db.execute(q.order_by(TaskInstance.due_date))
    return [task_dict(t) for t in r.scalars().all()]


@app.get("/api/v1/tasks/{task_id}", tags=["Tasks"])
async def get_task(
    task_id: uuid.UUID,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(TaskInstance).where(
        TaskInstance.id == task_id, TaskInstance.company_id == current_user.company_id
    ))
    t = r.scalar_one_or_none()
    if not t:
        raise HTTPException(404, "Task tidak ditemukan")
    return task_dict(t, include_template=True)


@app.put("/api/v1/tasks/{task_id}/start", tags=["Tasks"])
async def start_task(
    task_id: uuid.UUID,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(TaskInstance).where(
        TaskInstance.id == task_id,
        TaskInstance.company_id == current_user.company_id,
        TaskInstance.assigned_user_id == current_user.id,
    ))
    t = r.scalar_one_or_none()
    if not t:
        raise HTTPException(404, "Task tidak ditemukan atau bukan milik Anda")
    if t.status == TaskStatus.COMPLETED:
        raise HTTPException(400, "Task sudah selesai")
    t.status = TaskStatus.IN_PROGRESS
    t.started_at = datetime.utcnow()
    await db.flush()
    return {"message": "Task dimulai", "status": t.status.value}


@app.put("/api/v1/tasks/{task_id}/complete", tags=["Tasks"])
async def complete_task(
    task_id: uuid.UUID,
    data: TaskCompleteReq,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(TaskInstance).where(
        TaskInstance.id == task_id,
        TaskInstance.company_id == current_user.company_id,
        TaskInstance.assigned_user_id == current_user.id,
    ))
    t = r.scalar_one_or_none()
    if not t:
        raise HTTPException(404, "Task tidak ditemukan atau bukan milik Anda")
    t.checklist_results = data.results
    t.materials_used = data.materials_used or []
    t.notes = data.notes
    t.status = TaskStatus.COMPLETED
    t.completed_at = datetime.utcnow()
    # Auto-record meter readings from checklist
    await _auto_record_meters(t, data.results, current_user, db)
    await db.flush()
    return task_dict(t)


async def _auto_record_meters(task: TaskInstance, results: list, user: User, db: AsyncSession):
    snapshot = task.template_snapshot or {}
    sections = snapshot.get("sections", [])
    steps = [s for sec in sections for s in sec.get("steps", [])]
    for i, res in enumerate(results):
        if i >= len(steps):
            break
        step = steps[i]
        meter_number = step.get("meter_number")
        meter_type_str = step.get("meter_type")
        if not meter_number or not meter_type_str:
            continue
        val = res.get("value")
        if val is None:
            continue
        try:
            reading_value = float(val)
        except (ValueError, TypeError):
            continue
        try:
            mtype = MeterType(meter_type_str)
        except ValueError:
            continue
        # Find or create meter
        mr = await db.execute(
            select(Meter).where(Meter.building_id == task.building_id, Meter.meter_number == meter_number)
        )
        meter = mr.scalar_one_or_none()
        if not meter:
            meter = Meter(
                company_id=task.company_id, building_id=task.building_id,
                meter_number=meter_number, meter_type=mtype,
                unit="kWh" if mtype == MeterType.ELECTRICITY else "m3",
                multiplier=1.0,
            )
            db.add(meter)
            await db.flush()
        reading = MeterReading(
            company_id=task.company_id, meter_id=meter.id,
            reading_value=reading_value,
            reading_date=task.completed_at or datetime.utcnow(),
            source="checklist", recorded_by_id=user.id,
            task_instance_id=task.id,
        )
        db.add(reading)


# ─────────────────────────────────────────────────────────────
# WORK ORDERS
# ─────────────────────────────────────────────────────────────

class WOCreate(BaseModel):
    building_id: uuid.UUID
    title: str
    description: Optional[str] = None
    wo_type: str = "corrective"
    category: Optional[str] = None
    priority: WOPriority = WOPriority.MEDIUM
    asset_id: Optional[uuid.UUID] = None
    assigned_to_id: Optional[uuid.UUID] = None
    floor: Optional[str] = None
    location: Optional[str] = None
    due_date: Optional[datetime] = None
    checklist_steps: Optional[List[Dict[str, Any]]] = []

class WOUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    priority: Optional[WOPriority] = None
    status: Optional[WOStatus] = None
    assigned_to_id: Optional[uuid.UUID] = None
    due_date: Optional[datetime] = None
    checklist_results: Optional[List[Dict[str, Any]]] = None
    materials_used: Optional[List[Dict[str, Any]]] = None
    photos: Optional[List[str]] = None
    approval_notes: Optional[str] = None


def wo_dict(w: WorkOrder):
    return {
        "id": u(w.id), "company_id": u(w.company_id), "building_id": u(w.building_id),
        "wo_number": w.wo_number, "title": w.title, "description": w.description,
        "wo_type": w.wo_type, "category": w.category,
        "priority": w.priority.value if w.priority else None,
        "status": w.status.value if w.status else None,
        "asset_id": u(w.asset_id),
        "assigned_to_id": u(w.assigned_to_id),
        "created_by_id": u(w.created_by_id),
        "approved_by_id": u(w.approved_by_id),
        "floor": w.floor, "location": w.location,
        "due_date": dt(w.due_date), "started_at": dt(w.started_at),
        "completed_at": dt(w.completed_at),
        "checklist_steps": w.checklist_steps or [],
        "checklist_results": w.checklist_results or [],
        "materials_used": w.materials_used or [],
        "photos": w.photos or [],
        "source_type": w.source_type,
        "approval_notes": w.approval_notes,
        "created_at": dt(w.created_at),
    }


@app.post("/api/v1/work-orders", tags=["Work Orders"], status_code=201)
async def create_wo(
    data: WOCreate,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    await get_building_or_404(db, data.building_id, current_user.company_id)
    wo = WorkOrder(
        company_id=current_user.company_id,
        wo_number=gen_wo_number(),
        created_by_id=current_user.id,
        status=WOStatus.ASSIGNED if data.assigned_to_id else WOStatus.OPEN,
        **data.model_dump(),
    )
    db.add(wo)
    await db.flush()
    return wo_dict(wo)


@app.get("/api/v1/work-orders", tags=["Work Orders"])
async def list_wos(
    building_id: Optional[uuid.UUID] = None,
    status: Optional[str] = None,
    priority: Optional[str] = None,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    bld = building_id or get_building_id_for_user(current_user)
    q = select(WorkOrder).where(WorkOrder.company_id == current_user.company_id)
    if bld:
        q = q.where(WorkOrder.building_id == bld)
    if status:
        q = q.where(WorkOrder.status == WOStatus(status))
    if priority:
        q = q.where(WorkOrder.priority == WOPriority(priority))
    r = await db.execute(q.order_by(WorkOrder.created_at.desc()))
    return [wo_dict(w) for w in r.scalars().all()]


@app.get("/api/v1/work-orders/my-wo", tags=["Work Orders"])
async def my_wos(
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    q = select(WorkOrder).where(
        WorkOrder.company_id == current_user.company_id,
        WorkOrder.assigned_to_id == current_user.id,
        WorkOrder.status.in_([WOStatus.OPEN, WOStatus.ASSIGNED, WOStatus.IN_PROGRESS]),
    )
    r = await db.execute(q.order_by(WorkOrder.priority, WorkOrder.created_at.desc()))
    return [wo_dict(w) for w in r.scalars().all()]


@app.get("/api/v1/work-orders/{wo_id}", tags=["Work Orders"])
async def get_wo(
    wo_id: uuid.UUID,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(WorkOrder).where(WorkOrder.id == wo_id, WorkOrder.company_id == current_user.company_id))
    w = r.scalar_one_or_none()
    if not w:
        raise HTTPException(404, "Work Order tidak ditemukan")
    return wo_dict(w)


@app.put("/api/v1/work-orders/{wo_id}", tags=["Work Orders"])
async def update_wo(
    wo_id: uuid.UUID,
    data: WOUpdate,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(WorkOrder).where(WorkOrder.id == wo_id, WorkOrder.company_id == current_user.company_id))
    w = r.scalar_one_or_none()
    if not w:
        raise HTTPException(404, "WO tidak ditemukan")
    upd = data.model_dump(exclude_unset=True)
    new_status = upd.get("status")
    if new_status == WOStatus.IN_PROGRESS and not w.started_at:
        w.started_at = datetime.utcnow()
    elif new_status == WOStatus.COMPLETED:
        w.completed_at = datetime.utcnow()
    for k, v in upd.items():
        setattr(w, k, v)
    await db.flush()
    return wo_dict(w)


@app.put("/api/v1/work-orders/{wo_id}/approve", tags=["Work Orders"])
async def approve_wo(
    wo_id: uuid.UUID,
    approved: bool = True,
    notes: Optional[str] = None,
    current_user: User = Depends(require_role(UserRole.SPV_TEKNISI, UserRole.BUILDING_ADMIN, UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(WorkOrder).where(WorkOrder.id == wo_id, WorkOrder.company_id == current_user.company_id))
    w = r.scalar_one_or_none()
    if not w:
        raise HTTPException(404, "WO tidak ditemukan")
    w.approved_by_id = current_user.id
    w.status = WOStatus.COMPLETED if approved else WOStatus.REJECTED
    w.approval_notes = notes
    if approved:
        w.completed_at = datetime.utcnow()
    await db.flush()
    return {"message": "WO berhasil diproses", "status": w.status.value}


# ─────────────────────────────────────────────────────────────
# MATERIALS
# ─────────────────────────────────────────────────────────────

class MaterialCreate(BaseModel):
    building_id: uuid.UUID
    name: str
    code: Optional[str] = None
    category: Optional[str] = None
    unit: str
    current_stock: float = 0
    min_stock_threshold: float = 5
    price_per_unit: float = 0
    location: Optional[str] = None

class MaterialTxnCreate(BaseModel):
    material_id: uuid.UUID
    transaction_type: TransactionType
    quantity: float
    reference_type: Optional[str] = None
    reference_id: Optional[uuid.UUID] = None
    notes: Optional[str] = None

class MaterialReqCreate(BaseModel):
    building_id: uuid.UUID
    material_name: str
    quantity: float
    unit: str
    reason: Optional[str] = None
    reference_type: Optional[str] = None
    reference_id: Optional[uuid.UUID] = None


def mat_dict(m: Material):
    return {
        "id": u(m.id), "building_id": u(m.building_id), "code": m.code,
        "name": m.name, "category": m.category, "unit": m.unit,
        "current_stock": m.current_stock, "min_stock_threshold": m.min_stock_threshold,
        "price_per_unit": m.price_per_unit, "location": m.location,
        "is_low_stock": m.current_stock <= m.min_stock_threshold,
        "is_active": m.is_active,
    }


@app.post("/api/v1/materials", tags=["Materials"], status_code=201)
async def create_material(
    data: MaterialCreate,
    current_user: User = Depends(require_role(UserRole.BUILDING_ADMIN, UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    await get_building_or_404(db, data.building_id, current_user.company_id)
    m = Material(company_id=current_user.company_id, **data.model_dump())
    db.add(m)
    await db.flush()
    return mat_dict(m)


@app.get("/api/v1/materials", tags=["Materials"])
async def list_materials(
    building_id: Optional[uuid.UUID] = None,
    low_stock_only: bool = False,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    bld = building_id or get_building_id_for_user(current_user)
    q = select(Material).where(Material.company_id == current_user.company_id, Material.is_active == True)
    if bld:
        q = q.where(Material.building_id == bld)
    if low_stock_only:
        q = q.where(Material.current_stock <= Material.min_stock_threshold)
    r = await db.execute(q.order_by(Material.category, Material.name))
    return [mat_dict(m) for m in r.scalars().all()]


@app.post("/api/v1/materials/transactions", tags=["Materials"], status_code=201)
async def material_transaction(
    data: MaterialTxnCreate,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(Material).where(
        Material.id == data.material_id, Material.company_id == current_user.company_id
    ))
    mat = r.scalar_one_or_none()
    if not mat:
        raise HTTPException(404, "Material tidak ditemukan")
    # Building isolation
    bld_filter = get_building_id_for_user(current_user)
    if bld_filter and str(mat.building_id) != str(bld_filter):
        raise HTTPException(403, "Akses ditolak")

    if data.transaction_type in [TransactionType.USAGE, "stock_out"]:
        if mat.current_stock < data.quantity:
            raise HTTPException(400, f"Stok tidak cukup. Tersedia: {mat.current_stock} {mat.unit}")
        mat.current_stock -= data.quantity
    elif data.transaction_type in [TransactionType.STOCK_IN, TransactionType.RETURN]:
        mat.current_stock += data.quantity
    elif data.transaction_type == TransactionType.ADJUSTMENT:
        mat.current_stock = data.quantity

    txn = MaterialTransaction(
        company_id=current_user.company_id, building_id=mat.building_id,
        material_id=data.material_id, transaction_type=data.transaction_type,
        quantity=data.quantity, reference_type=data.reference_type,
        reference_id=data.reference_id, performed_by_id=current_user.id,
        notes=data.notes,
    )
    db.add(txn)
    await db.flush()
    return {"message": "Transaksi berhasil", "new_stock": mat.current_stock}


@app.post("/api/v1/materials/requests", tags=["Materials"], status_code=201)
async def create_material_request(
    data: MaterialReqCreate,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    await get_building_or_404(db, data.building_id, current_user.company_id)
    req = MaterialRequest(
        company_id=current_user.company_id,
        requested_by_id=current_user.id,
        **data.model_dump(),
    )
    db.add(req)
    await db.flush()
    return {"id": u(req.id), "message": "Request material berhasil dibuat"}


@app.get("/api/v1/materials/requests", tags=["Materials"])
async def list_material_requests(
    building_id: Optional[uuid.UUID] = None,
    status: Optional[str] = None,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    bld = building_id or get_building_id_for_user(current_user)
    q = select(MaterialRequest).where(MaterialRequest.company_id == current_user.company_id)
    if bld:
        q = q.where(MaterialRequest.building_id == bld)
    if status:
        q = q.where(MaterialRequest.status == status)
    # Regular staff only see their own requests
    if current_user.role in [UserRole.TEKNISI, UserRole.HOUSEKEEPING]:
        q = q.where(MaterialRequest.requested_by_id == current_user.id)
    r = await db.execute(q.order_by(MaterialRequest.created_at.desc()))
    reqs = r.scalars().all()
    return [{"id": u(req.id), "material_name": req.material_name, "quantity": req.quantity,
             "unit": req.unit, "reason": req.reason, "status": req.status,
             "requested_by_id": u(req.requested_by_id),
             "approved_by_id": u(req.approved_by_id),
             "created_at": dt(req.created_at)} for req in reqs]


@app.put("/api/v1/materials/requests/{req_id}/approve", tags=["Materials"])
async def approve_material_request(
    req_id: uuid.UUID,
    approved: bool = True,
    notes: Optional[str] = None,
    current_user: User = Depends(require_role(
        UserRole.SPV_TEKNISI, UserRole.SPV_HOUSEKEEPING, UserRole.BUILDING_ADMIN, UserRole.SUPER_ADMIN
    )),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(MaterialRequest).where(
        MaterialRequest.id == req_id, MaterialRequest.company_id == current_user.company_id
    ))
    req = r.scalar_one_or_none()
    if not req:
        raise HTTPException(404, "Request tidak ditemukan")
    req.status = "approved_by_spv" if approved else "rejected"
    req.approved_by_id = current_user.id
    if notes:
        req.notes = notes
    await db.flush()
    return {"message": "Request diproses", "status": req.status}


# ─────────────────────────────────────────────────────────────
# BILLING & METERS
# ─────────────────────────────────────────────────────────────

class MeterCreate(BaseModel):
    building_id: uuid.UUID
    meter_number: str
    meter_type: MeterType
    unit: str
    multiplier: float = 1.0
    floor: Optional[str] = None
    location: Optional[str] = None
    tenant_name: Optional[str] = None

class MeterReadingCreate(BaseModel):
    meter_id: uuid.UUID
    reading_value: float
    reading_date: Optional[datetime] = None
    notes: Optional[str] = None

class TariffCreate(BaseModel):
    building_id: uuid.UUID
    meter_type: MeterType
    rate_per_unit: float
    admin_fee: float = 0
    ppn_percent: float = 11.0

class GenerateInvoiceReq(BaseModel):
    building_id: uuid.UUID
    tenant_name: Optional[str] = None
    period_start: datetime
    period_end: datetime


@app.post("/api/v1/billing/meters", tags=["Billing"], status_code=201)
async def create_meter(
    data: MeterCreate,
    current_user: User = Depends(require_role(UserRole.BUILDING_ADMIN, UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    await get_building_or_404(db, data.building_id, current_user.company_id)
    m = Meter(company_id=current_user.company_id, **data.model_dump())
    db.add(m)
    await db.flush()
    return {"id": u(m.id), "meter_number": m.meter_number}


@app.get("/api/v1/billing/meters", tags=["Billing"])
async def list_meters(
    building_id: Optional[uuid.UUID] = None,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    bld = building_id or get_building_id_for_user(current_user)
    q = select(Meter).where(Meter.company_id == current_user.company_id, Meter.is_active == True)
    if bld:
        q = q.where(Meter.building_id == bld)
    r = await db.execute(q.order_by(Meter.meter_type, Meter.meter_number))
    return [{"id": u(m.id), "meter_number": m.meter_number, "meter_type": m.meter_type.value,
             "unit": m.unit, "floor": m.floor, "tenant_name": m.tenant_name, "multiplier": m.multiplier} for m in r.scalars().all()]


@app.post("/api/v1/billing/readings", tags=["Billing"], status_code=201)
async def add_reading(
    data: MeterReadingCreate,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    mr = await db.execute(select(Meter).where(Meter.id == data.meter_id, Meter.company_id == current_user.company_id))
    meter = mr.scalar_one_or_none()
    if not meter:
        raise HTTPException(404, "Meter tidak ditemukan")
    reading = MeterReading(
        company_id=current_user.company_id, meter_id=data.meter_id,
        reading_value=data.reading_value,
        reading_date=data.reading_date or datetime.utcnow(),
        source="manual", recorded_by_id=current_user.id, notes=data.notes,
    )
    db.add(reading)
    await db.flush()
    return {"id": u(reading.id), "message": "Pembacaan meter berhasil dicatat"}


@app.get("/api/v1/billing/readings/{meter_id}", tags=["Billing"])
async def meter_readings(
    meter_id: uuid.UUID,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    mr = await db.execute(select(Meter).where(Meter.id == meter_id, Meter.company_id == current_user.company_id))
    meter = mr.scalar_one_or_none()
    if not meter:
        raise HTTPException(404, "Meter tidak ditemukan")
    q = select(MeterReading).where(MeterReading.meter_id == meter_id)
    if start_date:
        q = q.where(MeterReading.reading_date >= start_date)
    if end_date:
        q = q.where(MeterReading.reading_date <= end_date)
    r = await db.execute(q.order_by(MeterReading.reading_date))
    return [{"id": u(rd.id), "reading_value": rd.reading_value,
             "reading_date": dt(rd.reading_date), "source": rd.source} for rd in r.scalars().all()]


@app.post("/api/v1/billing/tariffs", tags=["Billing"], status_code=201)
async def create_tariff(
    data: TariffCreate,
    current_user: User = Depends(require_role(UserRole.BUILDING_ADMIN, UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    await get_building_or_404(db, data.building_id, current_user.company_id)
    t = TariffConfig(company_id=current_user.company_id, **data.model_dump())
    db.add(t)
    await db.flush()
    return {"id": u(t.id), "message": "Tarif berhasil dibuat"}


@app.get("/api/v1/billing/tariffs", tags=["Billing"])
async def list_tariffs(
    building_id: Optional[uuid.UUID] = None,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    bld = building_id or get_building_id_for_user(current_user)
    q = select(TariffConfig).where(TariffConfig.company_id == current_user.company_id, TariffConfig.is_active == True)
    if bld:
        q = q.where(TariffConfig.building_id == bld)
    r = await db.execute(q)
    return [{"id": u(t.id), "meter_type": t.meter_type.value, "rate_per_unit": t.rate_per_unit,
             "admin_fee": t.admin_fee, "ppn_percent": t.ppn_percent} for t in r.scalars().all()]


@app.post("/api/v1/billing/invoices/generate", tags=["Billing"])
async def generate_invoice_preview(
    data: GenerateInvoiceReq,
    current_user: User = Depends(require_role(UserRole.BUILDING_ADMIN, UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    await get_building_or_404(db, data.building_id, current_user.company_id)
    # Get meters
    mq = select(Meter).where(Meter.company_id == current_user.company_id, Meter.building_id == data.building_id, Meter.is_active == True)
    if data.tenant_name:
        mq = mq.where(Meter.tenant_name == data.tenant_name)
    mr = await db.execute(mq)
    meters = mr.scalars().all()
    if not meters:
        raise HTTPException(404, "Tidak ada meter ditemukan untuk tenant ini")

    tq = select(TariffConfig).where(
        TariffConfig.company_id == current_user.company_id,
        TariffConfig.building_id == data.building_id,
        TariffConfig.is_active == True,
    )
    tr = await db.execute(tq)
    tariffs = {t.meter_type: t for t in tr.scalars().all()}

    line_items = []
    subtotal = 0.0
    admin_fee_total = 0.0
    ppn_pct = 11.0

    for meter in meters:
        tariff = tariffs.get(meter.meter_type)
        if not tariff:
            continue
        # Start reading
        sq = await db.execute(
            select(MeterReading)
            .where(MeterReading.meter_id == meter.id, MeterReading.reading_date <= data.period_start)
            .order_by(MeterReading.reading_date.desc()).limit(1)
        )
        start_r = sq.scalar_one_or_none()
        # End reading
        eq = await db.execute(
            select(MeterReading)
            .where(MeterReading.meter_id == meter.id, MeterReading.reading_date <= data.period_end)
            .order_by(MeterReading.reading_date.desc()).limit(1)
        )
        end_r = eq.scalar_one_or_none()
        if not start_r or not end_r:
            continue
        consumption = max(0, (end_r.reading_value - start_r.reading_value) * meter.multiplier)
        amount = consumption * tariff.rate_per_unit
        subtotal += amount
        admin_fee_total += tariff.admin_fee
        ppn_pct = tariff.ppn_percent
        line_items.append({
            "meter_id": u(meter.id), "meter_number": meter.meter_number,
            "meter_type": meter.meter_type.value,
            "description": f"{meter.meter_type.value.title()} — {meter.tenant_name or meter.meter_number}",
            "reading_start": start_r.reading_value, "reading_end": end_r.reading_value,
            "consumption": round(consumption, 3), "unit": meter.unit,
            "rate_per_unit": tariff.rate_per_unit, "amount": round(amount, 2),
        })

    ppn_amount = (subtotal + admin_fee_total) * (ppn_pct / 100)
    total = subtotal + admin_fee_total + ppn_amount

    return {
        "preview": True,
        "invoice_number": gen_inv_number(data.period_start),
        "building_id": u(data.building_id),
        "tenant_name": data.tenant_name,
        "period_start": dt(data.period_start),
        "period_end": dt(data.period_end),
        "line_items": line_items,
        "subtotal": round(subtotal, 2),
        "admin_fee": round(admin_fee_total, 2),
        "ppn_percent": ppn_pct,
        "ppn_amount": round(ppn_amount, 2),
        "total_amount": round(total, 2),
    }


@app.post("/api/v1/billing/invoices/issue", tags=["Billing"], status_code=201)
async def issue_invoice(
    preview: Dict[str, Any],
    current_user: User = Depends(require_role(UserRole.BUILDING_ADMIN, UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    bld_id = uuid.UUID(preview["building_id"]) if preview.get("building_id") else None
    if bld_id:
        await get_building_or_404(db, bld_id, current_user.company_id)
    inv = Invoice(
        company_id=current_user.company_id,
        building_id=bld_id,
        invoice_number=preview.get("invoice_number"),
        tenant_name=preview.get("tenant_name"),
        period_start=datetime.fromisoformat(preview["period_start"]),
        period_end=datetime.fromisoformat(preview["period_end"]),
        subtotal=preview.get("subtotal", 0),
        admin_fee=preview.get("admin_fee", 0),
        ppn_amount=preview.get("ppn_amount", 0),
        total_amount=preview.get("total_amount", 0),
        line_items=preview.get("line_items", []),
        status=InvoiceStatus.ISSUED,
        issued_at=datetime.utcnow(),
        created_by_id=current_user.id,
    )
    db.add(inv)
    await db.flush()
    return {"id": u(inv.id), "invoice_number": inv.invoice_number, "message": "Invoice berhasil diterbitkan"}


@app.get("/api/v1/billing/invoices", tags=["Billing"])
async def list_invoices(
    building_id: Optional[uuid.UUID] = None,
    status: Optional[str] = None,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    bld = building_id or get_building_id_for_user(current_user)
    q = select(Invoice).where(Invoice.company_id == current_user.company_id)
    if bld:
        q = q.where(Invoice.building_id == bld)
    if status:
        q = q.where(Invoice.status == InvoiceStatus(status))
    r = await db.execute(q.order_by(Invoice.created_at.desc()))
    invs = r.scalars().all()
    return [{"id": u(inv.id), "invoice_number": inv.invoice_number, "tenant_name": inv.tenant_name,
             "period_start": dt(inv.period_start), "period_end": dt(inv.period_end),
             "total_amount": inv.total_amount, "status": inv.status.value,
             "line_items": inv.line_items, "created_at": dt(inv.created_at)} for inv in invs]


# ─────────────────────────────────────────────────────────────
# ALARMS
# ─────────────────────────────────────────────────────────────

class AlarmCreate(BaseModel):
    building_id: uuid.UUID
    alarm_type: str
    severity: AlarmSeverity
    title: str
    message: Optional[str] = None
    location: Optional[str] = None
    floor: Optional[str] = None
    device_id: Optional[str] = None
    asset_id: Optional[uuid.UUID] = None
    source: str = "manual"


def alarm_dict(a: Alarm):
    return {
        "id": u(a.id), "building_id": u(a.building_id),
        "alarm_type": a.alarm_type, "severity": a.severity.value,
        "title": a.title, "message": a.message,
        "location": a.location, "floor": a.floor, "device_id": a.device_id,
        "status": a.status.value, "acked": a.acked,
        "acked_at": dt(a.acked_at), "resolved_at": dt(a.resolved_at),
        "source": a.source, "asset_id": u(a.asset_id),
        "created_at": dt(a.created_at),
    }


@app.post("/api/v1/alarms", tags=["Alarms"], status_code=201)
async def create_alarm(
    data: AlarmCreate,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    await get_building_or_404(db, data.building_id, current_user.company_id)
    alarm = Alarm(company_id=current_user.company_id, **data.model_dump())
    db.add(alarm)
    await db.flush()
    return alarm_dict(alarm)


@app.get("/api/v1/alarms", tags=["Alarms"])
async def list_alarms(
    building_id: Optional[uuid.UUID] = None,
    severity: Optional[str] = None,
    status: Optional[str] = None,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    bld = building_id or get_building_id_for_user(current_user)
    q = select(Alarm).where(Alarm.company_id == current_user.company_id)
    if bld:
        q = q.where(Alarm.building_id == bld)
    if severity:
        q = q.where(Alarm.severity == AlarmSeverity(severity))
    if status:
        q = q.where(Alarm.status == AlarmStatus(status))
    else:
        q = q.where(Alarm.status.in_([AlarmStatus.ACTIVE, AlarmStatus.ACKED]))
    r = await db.execute(q.order_by(Alarm.created_at.desc()))
    return [alarm_dict(a) for a in r.scalars().all()]


@app.put("/api/v1/alarms/{alarm_id}/ack", tags=["Alarms"])
async def ack_alarm(
    alarm_id: uuid.UUID,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(Alarm).where(Alarm.id == alarm_id, Alarm.company_id == current_user.company_id))
    a = r.scalar_one_or_none()
    if not a:
        raise HTTPException(404, "Alarm tidak ditemukan")
    a.acked = True
    a.acked_by_id = current_user.id
    a.acked_at = datetime.utcnow()
    a.status = AlarmStatus.ACKED
    await db.flush()
    return {"message": "Alarm di-acknowledge"}


@app.put("/api/v1/alarms/{alarm_id}/resolve", tags=["Alarms"])
async def resolve_alarm(
    alarm_id: uuid.UUID,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(Alarm).where(Alarm.id == alarm_id, Alarm.company_id == current_user.company_id))
    a = r.scalar_one_or_none()
    if not a:
        raise HTTPException(404, "Alarm tidak ditemukan")
    a.status = AlarmStatus.RESOLVED
    a.resolved_at = datetime.utcnow()
    await db.flush()
    return {"message": "Alarm diselesaikan"}


# ─────────────────────────────────────────────────────────────
# VISITORS (TRO)
# ─────────────────────────────────────────────────────────────

class VisitorData(BaseModel):
    full_name: str
    id_type: str = "KTP"
    id_number: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    is_vip: bool = False
    plate_number: Optional[str] = None

class VisitCreate(BaseModel):
    building_id: uuid.UUID
    visitor_data: VisitorData
    host_name: Optional[str] = None
    host_tenant: Optional[str] = None
    host_floor: Optional[str] = None
    purpose: Optional[str] = None
    scheduled_start: Optional[datetime] = None
    scheduled_end: Optional[datetime] = None
    plate_number: Optional[str] = None
    notes: Optional[str] = None


def visit_dict(v: Visit, visitor: Optional[Visitor] = None):
    d = {
        "id": u(v.id), "building_id": u(v.building_id), "visitor_id": u(v.visitor_id),
        "host_name": v.host_name, "host_tenant": v.host_tenant, "host_floor": v.host_floor,
        "purpose": v.purpose, "qr_code_uuid": v.qr_code_uuid, "status": v.status.value,
        "scheduled_start": dt(v.scheduled_start), "scheduled_end": dt(v.scheduled_end),
        "actual_checkin": dt(v.actual_checkin), "actual_checkout": dt(v.actual_checkout),
        "plate_number": v.plate_number, "notes": v.notes, "created_at": dt(v.created_at),
    }
    if visitor:
        d["visitor"] = {
            "id": u(visitor.id), "full_name": visitor.full_name,
            "phone": visitor.phone, "email": visitor.email,
            "is_vip": visitor.is_vip, "plate_number": visitor.plate_number,
        }
    return d


@app.post("/api/v1/visitors", tags=["Visitors"], status_code=201)
async def register_visit(
    data: VisitCreate,
    current_user: User = Depends(require_role(UserRole.TRO, UserRole.BUILDING_ADMIN, UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    await get_building_or_404(db, data.building_id, current_user.company_id)
    vd = data.visitor_data
    visitor = Visitor(
        company_id=current_user.company_id, building_id=data.building_id,
        full_name=vd.full_name, id_type=vd.id_type, id_number=vd.id_number,
        phone=vd.phone, email=vd.email, is_vip=vd.is_vip,
        plate_number=vd.plate_number or data.plate_number,
    )
    db.add(visitor)
    await db.flush()

    qr = str(uuid.uuid4())
    visit = Visit(
        company_id=current_user.company_id, building_id=data.building_id,
        visitor_id=visitor.id,
        host_name=data.host_name, host_tenant=data.host_tenant, host_floor=data.host_floor,
        purpose=data.purpose, qr_code_uuid=qr,
        scheduled_start=data.scheduled_start or datetime.utcnow(),
        scheduled_end=data.scheduled_end,
        plate_number=data.plate_number or vd.plate_number,
        status=VisitStatus.SCHEDULED, registered_by_id=current_user.id,
        notes=data.notes,
    )
    db.add(visit)
    await db.flush()
    return {**visit_dict(visit, visitor), "qr_code_uuid": qr}


@app.get("/api/v1/visitors/active", tags=["Visitors"])
async def active_visits(
    building_id: Optional[uuid.UUID] = None,
    current_user: User = Depends(require_role(UserRole.TRO, UserRole.BUILDING_ADMIN, UserRole.SUPER_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    bld = building_id or get_building_id_for_user(current_user)
    q = select(Visit).where(
        Visit.company_id == current_user.company_id,
        Visit.status.in_([VisitStatus.SCHEDULED, VisitStatus.ON_PREMISE]),
    )
    if bld:
        q = q.where(Visit.building_id == bld)
    r = await db.execute(q.order_by(Visit.created_at.desc()))
    visits = r.scalars().all()
    result = []
    for v in visits:
        vr = await db.execute(select(Visitor).where(Visitor.id == v.visitor_id))
        visitor = vr.scalar_one_or_none()
        result.append(visit_dict(v, visitor))
    return result


@app.post("/api/v1/visitors/validate-access", tags=["Visitors"])
async def validate_access(
    device_id: str,
    qr_code_uuid: str,
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(Visit).where(Visit.qr_code_uuid == qr_code_uuid))
    visit = r.scalar_one_or_none()
    if not visit:
        return {"decision": "denied", "reason": "invalid_qr", "message": "QR Code tidak valid"}
    now = datetime.utcnow()
    if visit.scheduled_end and now > visit.scheduled_end:
        return {"decision": "denied", "reason": "expired", "message": "QR Code kedaluwarsa"}
    if visit.status == VisitStatus.CANCELLED:
        return {"decision": "denied", "reason": "cancelled", "message": "Kunjungan dibatalkan"}

    if visit.status == VisitStatus.SCHEDULED:
        visit.status = VisitStatus.ON_PREMISE
        visit.actual_checkin = now
        log = AccessLog(
            company_id=visit.company_id, building_id=visit.building_id,
            visit_id=visit.id, device_id=device_id, event="granted", timestamp=now,
        )
        db.add(log)
        await db.commit()

    vr = await db.execute(select(Visitor).where(Visitor.id == visit.visitor_id))
    visitor = vr.scalar_one_or_none()
    return {
        "decision": "allowed",
        "visitor_name": visitor.full_name if visitor else "Tamu",
        "is_vip": visitor.is_vip if visitor else False,
        "host": f"{visit.host_tenant} (Lt.{visit.host_floor})" if visit.host_floor else visit.host_tenant,
        "message": f"Selamat datang, {visitor.full_name if visitor else 'Tamu'}!",
    }


@app.put("/api/v1/visitors/{visit_id}/checkout", tags=["Visitors"])
async def checkout_visitor(
    visit_id: uuid.UUID,
    current_user: User = Depends(require_role(UserRole.TRO, UserRole.BUILDING_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(Visit).where(Visit.id == visit_id, Visit.company_id == current_user.company_id))
    visit = r.scalar_one_or_none()
    if not visit:
        raise HTTPException(404, "Kunjungan tidak ditemukan")
    visit.status = VisitStatus.COMPLETED
    visit.actual_checkout = datetime.utcnow()
    await db.flush()
    return {"message": "Checkout berhasil"}


@app.post("/api/v1/visitors/parking/webhook", tags=["Visitors"])
async def parking_webhook(payload: Dict[str, Any], db: AsyncSession = Depends(get_db)):
    plate = (payload.get("plate_number") or "").replace(" ", "").upper()
    if not plate:
        return {"status": "ignored"}
    # Try to match with active visit
    vr = await db.execute(
        select(Visit).where(
            Visit.plate_number.ilike(f"%{plate}%"),
            Visit.status.in_([VisitStatus.SCHEDULED, VisitStatus.ON_PREMISE]),
        )
    )
    visit = vr.scalar_one_or_none()
    pe = ParkingEvent(
        company_id=visit.company_id if visit else None,
        building_id=visit.building_id if visit else None,
        visit_id=visit.id if visit else None,
        gate_id=payload.get("gate_id"),
        plate_number=plate,
        entry_time=datetime.utcnow(),
        ticket_number=payload.get("ticket_number"),
    )
    db.add(pe)
    await db.commit()
    return {"status": "received", "matched": visit is not None, "parking_event_id": u(pe.id)}


@app.put("/api/v1/visitors/parking/{event_id}/validate", tags=["Visitors"])
async def validate_parking(
    event_id: uuid.UUID,
    current_user: User = Depends(require_role(UserRole.TRO, UserRole.BUILDING_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(ParkingEvent).where(ParkingEvent.id == event_id))
    pe = r.scalar_one_or_none()
    if not pe:
        raise HTTPException(404, "Event parkir tidak ditemukan")
    pe.is_validated = True
    pe.validated_by_id = current_user.id
    await db.flush()
    return {"message": "Parkir bebas biaya berhasil", "plate_number": pe.plate_number}


# ─────────────────────────────────────────────────────────────
# DASHBOARD STATS
# ─────────────────────────────────────────────────────────────

@app.get("/api/v1/dashboard/admin/stats", tags=["Dashboard"])
async def admin_stats(
    building_id: Optional[uuid.UUID] = None,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    bld = building_id or get_building_id_for_user(current_user)
    today_start = datetime.combine(date.today(), datetime.min.time())
    today_end = today_start + timedelta(days=1)

    def bld_filter(model):
        f = [model.company_id == current_user.company_id]
        if bld:
            f.append(model.building_id == bld)
        return and_(*f)

    wo_open = await db.scalar(select(func.count(WorkOrder.id)).where(bld_filter(WorkOrder), WorkOrder.status.in_([WOStatus.OPEN, WOStatus.ASSIGNED, WOStatus.IN_PROGRESS]))) or 0
    wo_done_today = await db.scalar(select(func.count(WorkOrder.id)).where(bld_filter(WorkOrder), WorkOrder.status == WOStatus.COMPLETED, WorkOrder.completed_at >= today_start, WorkOrder.completed_at < today_end)) or 0
    wo_emergency = await db.scalar(select(func.count(WorkOrder.id)).where(bld_filter(WorkOrder), WorkOrder.priority == WOPriority.EMERGENCY, WorkOrder.status.in_([WOStatus.OPEN, WOStatus.ASSIGNED, WOStatus.IN_PROGRESS]))) or 0

    tasks_today = await db.scalar(select(func.count(TaskInstance.id)).where(bld_filter(TaskInstance), TaskInstance.due_date >= today_start, TaskInstance.due_date < today_end)) or 0
    tasks_done = await db.scalar(select(func.count(TaskInstance.id)).where(bld_filter(TaskInstance), TaskInstance.due_date >= today_start, TaskInstance.due_date < today_end, TaskInstance.status == TaskStatus.COMPLETED)) or 0
    tasks_overdue = await db.scalar(select(func.count(TaskInstance.id)).where(bld_filter(TaskInstance), TaskInstance.status == TaskStatus.OVERDUE)) or 0

    alarms_active = await db.scalar(select(func.count(Alarm.id)).where(bld_filter(Alarm), Alarm.status.in_([AlarmStatus.ACTIVE, AlarmStatus.ACKED]))) or 0
    alarms_critical = await db.scalar(select(func.count(Alarm.id)).where(bld_filter(Alarm), Alarm.severity.in_([AlarmSeverity.EMERGENCY, AlarmSeverity.CRITICAL]), Alarm.status.in_([AlarmStatus.ACTIVE, AlarmStatus.ACKED]))) or 0

    assets_total = await db.scalar(select(func.count(Asset.id)).where(bld_filter(Asset), Asset.is_active == True)) or 0
    visitors_onpremise = await db.scalar(select(func.count(Visit.id)).where(bld_filter(Visit), Visit.status == VisitStatus.ON_PREMISE)) or 0
    mat_requests = await db.scalar(select(func.count(MaterialRequest.id)).where(bld_filter(MaterialRequest), MaterialRequest.status == "pending")) or 0

    return {
        "work_orders": {"open": wo_open, "completed_today": wo_done_today, "emergency": wo_emergency},
        "tasks": {
            "total_today": tasks_today, "completed": tasks_done,
            "overdue": tasks_overdue,
            "compliance_percent": round(tasks_done / tasks_today * 100) if tasks_today else 100,
        },
        "alarms": {"active": alarms_active, "critical": alarms_critical},
        "assets": {"total": assets_total},
        "visitors": {"on_premise": visitors_onpremise},
        "material_requests": {"pending": mat_requests},
    }


@app.get("/api/v1/dashboard/my-stats", tags=["Dashboard"])
async def my_stats(
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    today_start = datetime.combine(date.today(), datetime.min.time())
    today_end = today_start + timedelta(days=1)

    tasks_today = await db.scalar(select(func.count(TaskInstance.id)).where(
        TaskInstance.company_id == current_user.company_id,
        TaskInstance.assigned_user_id == current_user.id,
        TaskInstance.due_date >= today_start, TaskInstance.due_date < today_end,
    )) or 0
    tasks_done = await db.scalar(select(func.count(TaskInstance.id)).where(
        TaskInstance.company_id == current_user.company_id,
        TaskInstance.assigned_user_id == current_user.id,
        TaskInstance.due_date >= today_start, TaskInstance.due_date < today_end,
        TaskInstance.status == TaskStatus.COMPLETED,
    )) or 0
    wo_active = await db.scalar(select(func.count(WorkOrder.id)).where(
        WorkOrder.company_id == current_user.company_id,
        WorkOrder.assigned_to_id == current_user.id,
        WorkOrder.status.in_([WOStatus.ASSIGNED, WOStatus.IN_PROGRESS]),
    )) or 0
    alarms = await db.scalar(select(func.count(Alarm.id)).where(
        Alarm.company_id == current_user.company_id,
        Alarm.building_id == current_user.building_id,
        Alarm.status == AlarmStatus.ACTIVE,
    )) or 0
    mat_reqs_pending = await db.scalar(select(func.count(MaterialRequest.id)).where(
        MaterialRequest.company_id == current_user.company_id,
        MaterialRequest.requested_by_id == current_user.id,
        MaterialRequest.status == "pending",
    )) or 0

    return {
        "tasks_today": tasks_today, "tasks_completed": tasks_done,
        "tasks_pending": tasks_today - tasks_done,
        "wo_active": wo_active, "alarms_active": alarms,
        "mat_requests_pending": mat_reqs_pending,
        "progress_percent": round(tasks_done / tasks_today * 100) if tasks_today else 0,
        "user_name": current_user.full_name,
        "user_role": current_user.role.value,
    }


@app.get("/api/v1/buildings/{building_id}", tags=["Buildings"])
async def get_building(
    building_id: uuid.UUID,
    current_user: User = Depends(require_auth),
    db: AsyncSession = Depends(get_db),
):
    b = await get_building_or_404(db, building_id, current_user.company_id)
    return bld_dict(b)


@app.put("/api/v1/buildings/{building_id}", tags=["Buildings"])
async def update_building(
    building_id: uuid.UUID,
    data: BuildingCreate,
    current_user: User = Depends(require_role(UserRole.SUPER_ADMIN, UserRole.COMPANY_ADMIN, UserRole.BUILDING_ADMIN)),
    db: AsyncSession = Depends(get_db),
):
    b = await get_building_or_404(db, building_id, current_user.company_id)
    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(b, k, v)
    await db.flush()
    return bld_dict(b)
