from typing import Optional
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.core.security import decode_token
from app.models.models import User, UserRole, Building
import uuid

security = HTTPBearer(auto_error=False)


async def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
    db: AsyncSession = Depends(get_db),
) -> Optional[User]:
    if not credentials:
        return None
    payload = decode_token(credentials.credentials)
    if not payload:
        return None
    user_id = payload.get("sub")
    if not user_id:
        return None
    result = await db.execute(select(User).where(User.id == user_id, User.is_active == True))
    return result.scalar_one_or_none()


async def require_auth(current_user: Optional[User] = Depends(get_current_user)) -> User:
    if not current_user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Autentikasi diperlukan")
    return current_user


def require_role(*roles: UserRole):
    async def checker(current_user: User = Depends(require_auth)) -> User:
        if current_user.role not in roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Role tidak diizinkan. Diperlukan: {[r.value for r in roles]}"
            )
        return current_user
    return checker


async def verify_building_access(
    building_id: uuid.UUID,
    current_user: User,
    db: AsyncSession,
) -> Building:
    """
    Verify that the building belongs to the user's company AND
    the user has access to it (either company-wide admin or assigned to this building).
    This prevents data leakage between buildings.
    """
    result = await db.execute(
        select(Building).where(
            Building.id == building_id,
            Building.company_id == current_user.company_id,
            Building.is_active == True,
        )
    )
    building = result.scalar_one_or_none()
    if not building:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Gedung tidak ditemukan atau akses ditolak"
        )
    # Non-admin users can only access their assigned building
    if current_user.role not in [UserRole.SUPER_ADMIN, UserRole.COMPANY_ADMIN]:
        if current_user.building_id and str(current_user.building_id) != str(building_id):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Anda tidak memiliki akses ke gedung ini"
            )
    return building


def get_building_id_for_user(current_user: User) -> Optional[uuid.UUID]:
    """Return the building_id filter for a user based on their role."""
    if current_user.role in [UserRole.SUPER_ADMIN, UserRole.COMPANY_ADMIN]:
        return None  # Can access all buildings in company
    return current_user.building_id
